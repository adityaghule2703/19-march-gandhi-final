import{r as _,g as hr,j as e,m as ne,n as gr,l as fr,v as se,C as tn,S as Pe,F as pr}from"./index-Cfk6U4ai.js";import{F as nn}from"./index-ChWfGIeU.js";import{f as vr,b as xr}from"./index-C3Vny5Su.js";import"./jspdf.plugin.autotable-CcBflfI0.js";import{g as br}from"./tableFilters-D5Nvh8tG.js";/* empty css                *//* empty css              *//* empty css                *//* empty css             */import{r as Cr,h as W,T as ie,A as X,P as Z,M as ee,C as rn,a as on,b as sn,c as an,j as yr,i as Ar}from"./DefaultLayout-BYbqrtWi.js";import{C as On,a as _n,b as Un,c as Vn,d as Hn}from"./CModalTitle-D7a9Oq2d.js";import{C as xe}from"./CAlert-Ci2RaY4b.js";import{C as tt,a as re}from"./CRow-DSxYtJa5.js";import{C as fe}from"./CFormInput-C3iMIJ3z.js";import{C as Nr}from"./CForm-CUm9eYzF.js";import{C as ft}from"./CFormSelect-DFRRIfuo.js";import{a as Ie,c as nt}from"./index.esm-CJ5kKkrQ.js";import{C as wr,a as Er}from"./CCardBody-Bp4Ke_pg.js";import{C as Tr}from"./CNav-3K62Umcy.js";import{b as rt,a as ot}from"./CNavItem-BLD6OWrT.js";import{C as Rr}from"./CFormControlWrapper-BVMFmCcZ.js";import{C as Sr,a as st}from"./CTabPane-CeKYQKoo.js";import{L as jr,e as Pr,A as Ir}from"./en-IN-DWeHwiTJ.js";import{D as cn}from"./DatePicker-D8HE2NVs.js";import{T as yt}from"./TextField-DkN1X2mh.js";import{C as it,a as at,b as te,c as D,d as ct,e as E}from"./CTable-8ufbGJ0H.js";import{c as ln}from"./cil-print-CPAcfqxC.js";import{M as Dr}from"./Menu-wdXN0-3Y.js";import{M as Br}from"./MenuItem-CvWv6D9n.js";import{c as Mr}from"./cil-plus-D8mtC-W5.js";import{c as Lr}from"./cil-check-circle-BlU9eaow.js";import"./slicedToArray-Dby63wcm.js";import"./extends-CF3RwP-h.js";import"./setPrototypeOf-C3V6guyq.js";import"./DefaultPropsProvider-D7dpE5xT.js";import"./emotion-element-f0de968e.browser.esm-Dj81gQ1A.js";import"./clsx-B-dksMZM.js";import"./isWithinInterval-DaYQ2mcw.js";import"./format-BZUhodlP.js";import"./TransitionGroup-17K8f3FQ.js";import"./emotion-react.browser.esm-Co-N4TkP.js";import"./Transition-CnacRa-l.js";import"./createSvgIcon-Cfwtdy2A.js";const kr=({show:s,onClose:i,bookingData:a,canCreateReceipts:o,cashLocations:r})=>{const[t,c]=_.useState({bookingId:a?._id||"",totalAmount:a?.discountedAmount||0,balanceAmount:a?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:a?.payment?.gcAmount||0,transactionReference:"",amountToBeCredited:0}),[d,l]=_.useState(r||[]),[u,p]=_.useState([]),[S,b]=_.useState([]),[f,j]=_.useState(!1),[M,U]=_.useState(null),[P,L]=_.useState(null);hr();const R=m=>{const{name:x,value:v}=m.target;c(g=>{const C={...g,[x]:v};if(x==="amount"){const N=parseFloat(v)||0,T=parseFloat(g.gcAmount)||0;C.amountToBeCredited=N-T}return C})},B=async m=>{if(m.preventDefault(),!o){U("You do not have permission to create receipts");return}j(!0),U(null),L(null);try{let x={bookingId:t.bookingId,paymentMode:t.modeOfPayment,amount:parseFloat(parseFloat(t.amount).toFixed(2)),remark:t.remark,transactionReference:t.transactionReference};switch(t.modeOfPayment){case"Cash":x.cashLocation=t.cashLocation;break;case"Bank":x.bank=t.bank,x.subPaymentMode=t.subPaymentMode;break;case"Finance Disbursement":x.financer=a?.payment?.financer?._id||a?.payment?.financer,x.gcAmount=parseFloat(parseFloat(t.gcAmount).toFixed(2)),x.amountToBeCredited=parseFloat(parseFloat(t.amountToBeCredited).toFixed(2));break;case"Exchange":case"Pay Order":x.bank=t.bank;break;default:break}const v=await ne.post("/ledger/receipt",x);console.log("Payment response:",v.data);let g=v.data.data?.ledger||v.data.data?.receipt||v.data.data;if(!g)throw new Error("No receipt data returned from server");const C=g._id||g.id;if(!C)throw new Error("Receipt ID not returned from server");console.log("New receipt ID:",C);const N={_id:g._id,id:g.id||g._id,receiptNumber:g.receiptNumber,amount:g.amount,receiptDate:g.receiptDate||g.createdAt,paymentMode:g.paymentMode,transactionReference:g.transactionReference,display:{amount:g.display?.amount||`₹${g.amount}`,date:g.display?.date||(g.receiptDate?new Date(g.receiptDate).toLocaleDateString("en-GB"):new Date().toLocaleDateString("en-GB"))}};L("Payment successfully recorded! Opening receipt..."),c({bookingId:a?._id||"",totalAmount:a?.discountedAmount||0,balanceAmount:a?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:a?.payment?.gcAmount||0,transactionReference:"",amountToBeCredited:0}),setTimeout(async()=>{try{const A=(await ne.get(`/ledger/booking/${t.bookingId}`)).data.data.allReceipts||[];console.log("All receipts:",A);const I=A.findIndex(K=>K._id===C||K.id===C);console.log("New receipt index:",I);const Y=A.length===1;console.log("Total receipts:",A.length,"Is first receipt ever:",Y),typeof window.printReceiptCallback=="function"?(console.log("Calling printReceiptCallback with:",C,t.bookingId,Y?0:1),window.printReceiptCallback(C,t.bookingId,Y?0:1)):console.error("printReceiptCallback is not defined on window!")}catch(T){console.error("Error fetching receipts:",T),typeof window.printReceiptCallback=="function"&&window.printReceiptCallback(C,t.bookingId,1)}},1500),setTimeout(()=>{i()},1e3)}catch(x){console.error("Payment error:",x),U(x.response?.data?.error||x.response?.data?.message||x.message||"Failed to process payment. Please try again.")}finally{j(!1)}};_.useEffect(()=>{const m=async()=>{try{const v=await ne.get("/banks");p(v.data.data.banks)}catch(v){console.error("Error fetching bank locations:",v)}},x=async()=>{try{const v=await ne.get("/banksubpaymentmodes");b(v.data.data||[])}catch(v){console.error("Error fetching payment sub-modes:",v),b([])}};if(s){r&&r.length>0?l(r):(async()=>{try{const C=await ne.get("/cash-locations");l(C.data.data.cashLocations)}catch(C){console.error("Error fetching cash locations:",C)}})(),m(),x();const v=a?.payment?.gcAmount||0;c({bookingId:a?._id||"",totalAmount:a?.discountedAmount||0,balanceAmount:a?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:v,transactionReference:"",amountToBeCredited:0-v}),U(null),L(null)}},[s,a,r]);const q=()=>{switch(t.modeOfPayment){case"Cash":return e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Cash Location"}),e.jsxs(ft,{name:"cashLocation",value:t.cashLocation,onChange:R,required:!0,disabled:f,children:[e.jsx("option",{value:"",children:"Select Cash Location"}),d.map(m=>e.jsx("option",{value:m.id||m._id,children:m.name||m.locationName||"Unnamed Location"},m.id||m._id))]})]});case"Bank":return e.jsxs(e.Fragment,{children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Payment Sub Mode"}),e.jsxs(ft,{name:"subPaymentMode",value:t.subPaymentMode,onChange:R,required:!0,disabled:f,children:[e.jsx("option",{value:"",children:"Select Payment Sub Mode"}),S.map(m=>e.jsx("option",{value:m.id||m._id,children:m.payment_mode||m.name},m.id||m._id))]})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Bank Location"}),e.jsxs(ft,{name:"bank",value:t.bank,onChange:R,required:!0,disabled:f,children:[e.jsx("option",{value:"",children:"Select Bank Location"}),u.map(m=>e.jsx("option",{value:m.id||m._id,children:m.name},m.id||m._id))]})]})]});case"Finance Disbursement":return e.jsxs(e.Fragment,{children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Financer Name"}),e.jsx(fe,{type:"text",value:a?.payment?.financer?.name||"N/A",readOnly:!0,className:"bg-light"})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"GC Amount (₹)"}),e.jsx(fe,{type:"number",name:"gcAmount",value:t.gcAmount?parseFloat(t.gcAmount).toFixed(2):"0.00",readOnly:!0,className:"bg-light"})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label mt-3",children:"Amount Credited To Customer Ledger (₹)"}),e.jsx(fe,{type:"number",name:"amountToBeCredited",value:t.amountToBeCredited?parseFloat(t.amountToBeCredited).toFixed(2):"0.00",readOnly:!0,className:"bg-light"})]})]});default:return null}};return e.jsxs(e.Fragment,{children:[e.jsx(Cr,{visible:s,className:"modal-backdrop",style:{backgroundColor:"rgba(0, 0, 0, 0.5)"}}),e.jsxs(On,{visible:s,onClose:i,size:"lg",alignment:"center",children:[e.jsx(_n,{children:e.jsx(Un,{children:"Account Receipt"})}),e.jsxs(Vn,{children:[M&&e.jsx(xe,{color:"danger",children:M}),P&&e.jsxs(xe,{color:"success",children:[P,f&&e.jsx("div",{className:"mt-2",children:e.jsx("small",{children:"Processing payment and generating receipt..."})})]}),e.jsxs(tt,{className:"mb-3",children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Customer Name"}),e.jsx(fe,{type:"text",value:a?.customerDetails?.name||"",readOnly:!0,className:"bg-light"})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Chassis Number"}),e.jsx(fe,{type:"text",value:a?.chassisNumber||"",readOnly:!0,className:"bg-light"})]})]}),e.jsxs(tt,{className:"mb-3",children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Total Amount (₹)"}),e.jsx(fe,{type:"number",name:"totalAmount",value:t.totalAmount?parseFloat(t.totalAmount).toFixed(2):"0.00",readOnly:!0,className:"bg-light font-weight-bold"})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Balance Amount (₹)"}),e.jsx(fe,{type:"number",name:"balanceAmount",value:t.balanceAmount?parseFloat(t.balanceAmount).toFixed(2):"0.00",readOnly:!0,className:`bg-light font-weight-bold ${parseFloat(t.balanceAmount)>0?"text-danger":"text-success"}`})]})]}),e.jsxs(Nr,{onSubmit:B,children:[e.jsxs(tt,{className:"mb-3",children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Amount (₹)"}),e.jsx(fe,{type:"number",name:"amount",value:t.amount,onChange:R,required:!0,min:"0",step:"0.01",disabled:f})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Mode of Payment"}),e.jsxs(ft,{name:"modeOfPayment",value:t.modeOfPayment,onChange:R,required:!0,disabled:f,children:[e.jsx("option",{value:"",children:"--Select--"}),e.jsx("option",{value:"Cash",children:"Cash"}),e.jsx("option",{value:"Bank",children:"Bank"}),e.jsx("option",{value:"Finance Disbursement",children:"Finance Disbursement"}),e.jsx("option",{value:"Exchange",children:"Exchange"}),e.jsx("option",{value:"Pay Order",children:"Pay Order"})]})]})]}),e.jsx(tt,{className:"mb-3",children:q()}),e.jsxs(tt,{className:"mb-3",children:[e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Reference Number"}),e.jsx(fe,{type:"text",name:"transactionReference",value:t.transactionReference,onChange:R,disabled:f})]}),e.jsxs(re,{md:6,children:[e.jsx("label",{className:"form-label",children:"Remark"}),e.jsx(fe,{type:"text",name:"remark",value:t.remark,onChange:R,placeholder:"Enter any remarks...",disabled:f})]})]})]})]}),e.jsxs(Hn,{children:[e.jsx("div",{children:e.jsx(Ie,{color:"primary",onClick:B,className:"me-2 submit-button",disabled:f||!o,children:f?"Processing...":"Save Payment & Print Receipt"})}),e.jsx(Ie,{color:"secondary",onClick:i,disabled:f,children:"Close"})]})]})]})},Fr=s=>{if(s===0)return"Zero";const i=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"],a=["Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"],o=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"],r=u=>{let p="";return u>=100&&(p+=i[Math.floor(u/100)]+" Hundred",u%=100,u>0&&(p+=" and ")),u>=20?(p+=o[Math.floor(u/10)],u%=10,u>0&&(p+=" "+i[u])):u>=10?p+=a[u-10]:u>0&&(p+=i[u]),p},t=u=>{if(u===0)return"";let p="";const S=Math.floor(u/1e7),b=Math.floor(u%1e7/1e5),f=Math.floor(u%1e5/1e3),j=u%1e3;return S>0&&(p+=r(S)+" Crore",(b>0||f>0||j>0)&&(p+=" ")),b>0&&(p+=r(b)+" Lakh",(f>0||j>0)&&(p+=" ")),f>0&&(p+=r(f)+" Thousand",j>0&&(p+=" ")),j>0&&(p+=r(j)),p},c=Math.floor(s),d=Math.round((s-c)*100);let l="";return c>0?l=t(c)+" Rupees":l="Zero Rupees",d>0&&(c>0&&(l+=" and "),l+=t(d)+" Paise"),l.trim()};var Ue={},At,dn;function Or(){return dn||(dn=1,At=function(){return typeof Promise=="function"&&Promise.prototype&&Promise.prototype.then}),At}var Nt={},Ae={},un;function De(){if(un)return Ae;un=1;let s;const i=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];return Ae.getSymbolSize=function(o){if(!o)throw new Error('"version" cannot be null or undefined');if(o<1||o>40)throw new Error('"version" should be in range from 1 to 40');return o*4+17},Ae.getSymbolTotalCodewords=function(o){return i[o]},Ae.getBCHDigit=function(a){let o=0;for(;a!==0;)o++,a>>>=1;return o},Ae.setToSJISFunction=function(o){if(typeof o!="function")throw new Error('"toSJISFunc" is not a valid function.');s=o},Ae.isKanjiModeEnabled=function(){return typeof s<"u"},Ae.toSJIS=function(o){return s(o)},Ae}var wt={},mn;function $t(){return mn||(mn=1,(function(s){s.L={bit:1},s.M={bit:0},s.Q={bit:3},s.H={bit:2};function i(a){if(typeof a!="string")throw new Error("Param is not a string");switch(a.toLowerCase()){case"l":case"low":return s.L;case"m":case"medium":return s.M;case"q":case"quartile":return s.Q;case"h":case"high":return s.H;default:throw new Error("Unknown EC Level: "+a)}}s.isValid=function(o){return o&&typeof o.bit<"u"&&o.bit>=0&&o.bit<4},s.from=function(o,r){if(s.isValid(o))return o;try{return i(o)}catch{return r}}})(wt)),wt}var Et,hn;function _r(){if(hn)return Et;hn=1;function s(){this.buffer=[],this.length=0}return s.prototype={get:function(i){const a=Math.floor(i/8);return(this.buffer[a]>>>7-i%8&1)===1},put:function(i,a){for(let o=0;o<a;o++)this.putBit((i>>>a-o-1&1)===1)},getLengthInBits:function(){return this.length},putBit:function(i){const a=Math.floor(this.length/8);this.buffer.length<=a&&this.buffer.push(0),i&&(this.buffer[a]|=128>>>this.length%8),this.length++}},Et=s,Et}var Tt,gn;function Ur(){if(gn)return Tt;gn=1;function s(i){if(!i||i<1)throw new Error("BitMatrix size must be defined and greater than 0");this.size=i,this.data=new Uint8Array(i*i),this.reservedBit=new Uint8Array(i*i)}return s.prototype.set=function(i,a,o,r){const t=i*this.size+a;this.data[t]=o,r&&(this.reservedBit[t]=!0)},s.prototype.get=function(i,a){return this.data[i*this.size+a]},s.prototype.xor=function(i,a,o){this.data[i*this.size+a]^=o},s.prototype.isReserved=function(i,a){return this.reservedBit[i*this.size+a]},Tt=s,Tt}var Rt={},fn;function Vr(){return fn||(fn=1,(function(s){const i=De().getSymbolSize;s.getRowColCoords=function(o){if(o===1)return[];const r=Math.floor(o/7)+2,t=i(o),c=t===145?26:Math.ceil((t-13)/(2*r-2))*2,d=[t-7];for(let l=1;l<r-1;l++)d[l]=d[l-1]-c;return d.push(6),d.reverse()},s.getPositions=function(o){const r=[],t=s.getRowColCoords(o),c=t.length;for(let d=0;d<c;d++)for(let l=0;l<c;l++)d===0&&l===0||d===0&&l===c-1||d===c-1&&l===0||r.push([t[d],t[l]]);return r}})(Rt)),Rt}var St={},pn;function Hr(){if(pn)return St;pn=1;const s=De().getSymbolSize,i=7;return St.getPositions=function(o){const r=s(o);return[[0,0],[r-i,0],[0,r-i]]},St}var jt={},vn;function qr(){return vn||(vn=1,(function(s){s.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};const i={N1:3,N2:3,N3:40,N4:10};s.isValid=function(r){return r!=null&&r!==""&&!isNaN(r)&&r>=0&&r<=7},s.from=function(r){return s.isValid(r)?parseInt(r,10):void 0},s.getPenaltyN1=function(r){const t=r.size;let c=0,d=0,l=0,u=null,p=null;for(let S=0;S<t;S++){d=l=0,u=p=null;for(let b=0;b<t;b++){let f=r.get(S,b);f===u?d++:(d>=5&&(c+=i.N1+(d-5)),u=f,d=1),f=r.get(b,S),f===p?l++:(l>=5&&(c+=i.N1+(l-5)),p=f,l=1)}d>=5&&(c+=i.N1+(d-5)),l>=5&&(c+=i.N1+(l-5))}return c},s.getPenaltyN2=function(r){const t=r.size;let c=0;for(let d=0;d<t-1;d++)for(let l=0;l<t-1;l++){const u=r.get(d,l)+r.get(d,l+1)+r.get(d+1,l)+r.get(d+1,l+1);(u===4||u===0)&&c++}return c*i.N2},s.getPenaltyN3=function(r){const t=r.size;let c=0,d=0,l=0;for(let u=0;u<t;u++){d=l=0;for(let p=0;p<t;p++)d=d<<1&2047|r.get(u,p),p>=10&&(d===1488||d===93)&&c++,l=l<<1&2047|r.get(p,u),p>=10&&(l===1488||l===93)&&c++}return c*i.N3},s.getPenaltyN4=function(r){let t=0;const c=r.data.length;for(let l=0;l<c;l++)t+=r.data[l];return Math.abs(Math.ceil(t*100/c/5)-10)*i.N4};function a(o,r,t){switch(o){case s.Patterns.PATTERN000:return(r+t)%2===0;case s.Patterns.PATTERN001:return r%2===0;case s.Patterns.PATTERN010:return t%3===0;case s.Patterns.PATTERN011:return(r+t)%3===0;case s.Patterns.PATTERN100:return(Math.floor(r/2)+Math.floor(t/3))%2===0;case s.Patterns.PATTERN101:return r*t%2+r*t%3===0;case s.Patterns.PATTERN110:return(r*t%2+r*t%3)%2===0;case s.Patterns.PATTERN111:return(r*t%3+(r+t)%2)%2===0;default:throw new Error("bad maskPattern:"+o)}}s.applyMask=function(r,t){const c=t.size;for(let d=0;d<c;d++)for(let l=0;l<c;l++)t.isReserved(l,d)||t.xor(l,d,a(r,l,d))},s.getBestMask=function(r,t){const c=Object.keys(s.Patterns).length;let d=0,l=1/0;for(let u=0;u<c;u++){t(u),s.applyMask(u,r);const p=s.getPenaltyN1(r)+s.getPenaltyN2(r)+s.getPenaltyN3(r)+s.getPenaltyN4(r);s.applyMask(u,r),p<l&&(l=p,d=u)}return d}})(jt)),jt}var pt={},xn;function qn(){if(xn)return pt;xn=1;const s=$t(),i=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],a=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];return pt.getBlocksCount=function(r,t){switch(t){case s.L:return i[(r-1)*4+0];case s.M:return i[(r-1)*4+1];case s.Q:return i[(r-1)*4+2];case s.H:return i[(r-1)*4+3];default:return}},pt.getTotalCodewordsCount=function(r,t){switch(t){case s.L:return a[(r-1)*4+0];case s.M:return a[(r-1)*4+1];case s.Q:return a[(r-1)*4+2];case s.H:return a[(r-1)*4+3];default:return}},pt}var Pt={},lt={},bn;function zr(){if(bn)return lt;bn=1;const s=new Uint8Array(512),i=new Uint8Array(256);return(function(){let o=1;for(let r=0;r<255;r++)s[r]=o,i[o]=r,o<<=1,o&256&&(o^=285);for(let r=255;r<512;r++)s[r]=s[r-255]})(),lt.log=function(o){if(o<1)throw new Error("log("+o+")");return i[o]},lt.exp=function(o){return s[o]},lt.mul=function(o,r){return o===0||r===0?0:s[i[o]+i[r]]},lt}var Cn;function $r(){return Cn||(Cn=1,(function(s){const i=zr();s.mul=function(o,r){const t=new Uint8Array(o.length+r.length-1);for(let c=0;c<o.length;c++)for(let d=0;d<r.length;d++)t[c+d]^=i.mul(o[c],r[d]);return t},s.mod=function(o,r){let t=new Uint8Array(o);for(;t.length-r.length>=0;){const c=t[0];for(let l=0;l<r.length;l++)t[l]^=i.mul(r[l],c);let d=0;for(;d<t.length&&t[d]===0;)d++;t=t.slice(d)}return t},s.generateECPolynomial=function(o){let r=new Uint8Array([1]);for(let t=0;t<o;t++)r=s.mul(r,new Uint8Array([1,i.exp(t)]));return r}})(Pt)),Pt}var It,yn;function Gr(){if(yn)return It;yn=1;const s=$r();function i(a){this.genPoly=void 0,this.degree=a,this.degree&&this.initialize(this.degree)}return i.prototype.initialize=function(o){this.degree=o,this.genPoly=s.generateECPolynomial(this.degree)},i.prototype.encode=function(o){if(!this.genPoly)throw new Error("Encoder not initialized");const r=new Uint8Array(o.length+this.degree);r.set(o);const t=s.mod(r,this.genPoly),c=this.degree-t.length;if(c>0){const d=new Uint8Array(this.degree);return d.set(t,c),d}return t},It=i,It}var Dt={},Bt={},Mt={},An;function zn(){return An||(An=1,Mt.isValid=function(i){return!isNaN(i)&&i>=1&&i<=40}),Mt}var ve={},Nn;function $n(){if(Nn)return ve;Nn=1;const s="[0-9]+",i="[A-Z $%*+\\-./:]+";let a="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";a=a.replace(/u/g,"\\u");const o="(?:(?![A-Z0-9 $%*+\\-./:]|"+a+`)(?:.|[\r
]))+`;ve.KANJI=new RegExp(a,"g"),ve.BYTE_KANJI=new RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),ve.BYTE=new RegExp(o,"g"),ve.NUMERIC=new RegExp(s,"g"),ve.ALPHANUMERIC=new RegExp(i,"g");const r=new RegExp("^"+a+"$"),t=new RegExp("^"+s+"$"),c=new RegExp("^[A-Z0-9 $%*+\\-./:]+$");return ve.testKanji=function(l){return r.test(l)},ve.testNumeric=function(l){return t.test(l)},ve.testAlphanumeric=function(l){return c.test(l)},ve}var wn;function Be(){return wn||(wn=1,(function(s){const i=zn(),a=$n();s.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},s.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},s.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},s.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},s.MIXED={bit:-1},s.getCharCountIndicator=function(t,c){if(!t.ccBits)throw new Error("Invalid mode: "+t);if(!i.isValid(c))throw new Error("Invalid version: "+c);return c>=1&&c<10?t.ccBits[0]:c<27?t.ccBits[1]:t.ccBits[2]},s.getBestModeForData=function(t){return a.testNumeric(t)?s.NUMERIC:a.testAlphanumeric(t)?s.ALPHANUMERIC:a.testKanji(t)?s.KANJI:s.BYTE},s.toString=function(t){if(t&&t.id)return t.id;throw new Error("Invalid mode")},s.isValid=function(t){return t&&t.bit&&t.ccBits};function o(r){if(typeof r!="string")throw new Error("Param is not a string");switch(r.toLowerCase()){case"numeric":return s.NUMERIC;case"alphanumeric":return s.ALPHANUMERIC;case"kanji":return s.KANJI;case"byte":return s.BYTE;default:throw new Error("Unknown mode: "+r)}}s.from=function(t,c){if(s.isValid(t))return t;try{return o(t)}catch{return c}}})(Bt)),Bt}var En;function Yr(){return En||(En=1,(function(s){const i=De(),a=qn(),o=$t(),r=Be(),t=zn(),c=7973,d=i.getBCHDigit(c);function l(b,f,j){for(let M=1;M<=40;M++)if(f<=s.getCapacity(M,j,b))return M}function u(b,f){return r.getCharCountIndicator(b,f)+4}function p(b,f){let j=0;return b.forEach(function(M){const U=u(M.mode,f);j+=U+M.getBitsLength()}),j}function S(b,f){for(let j=1;j<=40;j++)if(p(b,j)<=s.getCapacity(j,f,r.MIXED))return j}s.from=function(f,j){return t.isValid(f)?parseInt(f,10):j},s.getCapacity=function(f,j,M){if(!t.isValid(f))throw new Error("Invalid QR Code version");typeof M>"u"&&(M=r.BYTE);const U=i.getSymbolTotalCodewords(f),P=a.getTotalCodewordsCount(f,j),L=(U-P)*8;if(M===r.MIXED)return L;const R=L-u(M,f);switch(M){case r.NUMERIC:return Math.floor(R/10*3);case r.ALPHANUMERIC:return Math.floor(R/11*2);case r.KANJI:return Math.floor(R/13);case r.BYTE:default:return Math.floor(R/8)}},s.getBestVersionForData=function(f,j){let M;const U=o.from(j,o.M);if(Array.isArray(f)){if(f.length>1)return S(f,U);if(f.length===0)return 1;M=f[0]}else M=f;return l(M.mode,M.getLength(),U)},s.getEncodedBits=function(f){if(!t.isValid(f)||f<7)throw new Error("Invalid QR Code version");let j=f<<12;for(;i.getBCHDigit(j)-d>=0;)j^=c<<i.getBCHDigit(j)-d;return f<<12|j}})(Dt)),Dt}var Lt={},Tn;function Kr(){if(Tn)return Lt;Tn=1;const s=De(),i=1335,a=21522,o=s.getBCHDigit(i);return Lt.getEncodedBits=function(t,c){const d=t.bit<<3|c;let l=d<<10;for(;s.getBCHDigit(l)-o>=0;)l^=i<<s.getBCHDigit(l)-o;return(d<<10|l)^a},Lt}var kt={},Ft,Rn;function Jr(){if(Rn)return Ft;Rn=1;const s=Be();function i(a){this.mode=s.NUMERIC,this.data=a.toString()}return i.getBitsLength=function(o){return 10*Math.floor(o/3)+(o%3?o%3*3+1:0)},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(o){let r,t,c;for(r=0;r+3<=this.data.length;r+=3)t=this.data.substr(r,3),c=parseInt(t,10),o.put(c,10);const d=this.data.length-r;d>0&&(t=this.data.substr(r),c=parseInt(t,10),o.put(c,d*3+1))},Ft=i,Ft}var Ot,Sn;function Qr(){if(Sn)return Ot;Sn=1;const s=Be(),i=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function a(o){this.mode=s.ALPHANUMERIC,this.data=o}return a.getBitsLength=function(r){return 11*Math.floor(r/2)+6*(r%2)},a.prototype.getLength=function(){return this.data.length},a.prototype.getBitsLength=function(){return a.getBitsLength(this.data.length)},a.prototype.write=function(r){let t;for(t=0;t+2<=this.data.length;t+=2){let c=i.indexOf(this.data[t])*45;c+=i.indexOf(this.data[t+1]),r.put(c,11)}this.data.length%2&&r.put(i.indexOf(this.data[t]),6)},Ot=a,Ot}var _t,jn;function Wr(){if(jn)return _t;jn=1;const s=Be();function i(a){this.mode=s.BYTE,typeof a=="string"?this.data=new TextEncoder().encode(a):this.data=new Uint8Array(a)}return i.getBitsLength=function(o){return o*8},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(a){for(let o=0,r=this.data.length;o<r;o++)a.put(this.data[o],8)},_t=i,_t}var Ut,Pn;function Xr(){if(Pn)return Ut;Pn=1;const s=Be(),i=De();function a(o){this.mode=s.KANJI,this.data=o}return a.getBitsLength=function(r){return r*13},a.prototype.getLength=function(){return this.data.length},a.prototype.getBitsLength=function(){return a.getBitsLength(this.data.length)},a.prototype.write=function(o){let r;for(r=0;r<this.data.length;r++){let t=i.toSJIS(this.data[r]);if(t>=33088&&t<=40956)t-=33088;else if(t>=57408&&t<=60351)t-=49472;else throw new Error("Invalid SJIS character: "+this.data[r]+`
Make sure your charset is UTF-8`);t=(t>>>8&255)*192+(t&255),o.put(t,13)}},Ut=a,Ut}var Vt={exports:{}},In;function Zr(){return In||(In=1,(function(s){var i={single_source_shortest_paths:function(a,o,r){var t={},c={};c[o]=0;var d=i.PriorityQueue.make();d.push(o,0);for(var l,u,p,S,b,f,j,M,U;!d.empty();){l=d.pop(),u=l.value,S=l.cost,b=a[u]||{};for(p in b)b.hasOwnProperty(p)&&(f=b[p],j=S+f,M=c[p],U=typeof c[p]>"u",(U||M>j)&&(c[p]=j,d.push(p,j),t[p]=u))}if(typeof r<"u"&&typeof c[r]>"u"){var P=["Could not find a path from ",o," to ",r,"."].join("");throw new Error(P)}return t},extract_shortest_path_from_predecessor_list:function(a,o){for(var r=[],t=o;t;)r.push(t),a[t],t=a[t];return r.reverse(),r},find_path:function(a,o,r){var t=i.single_source_shortest_paths(a,o,r);return i.extract_shortest_path_from_predecessor_list(t,r)},PriorityQueue:{make:function(a){var o=i.PriorityQueue,r={},t;a=a||{};for(t in o)o.hasOwnProperty(t)&&(r[t]=o[t]);return r.queue=[],r.sorter=a.sorter||o.default_sorter,r},default_sorter:function(a,o){return a.cost-o.cost},push:function(a,o){var r={value:a,cost:o};this.queue.push(r),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};s.exports=i})(Vt)),Vt.exports}var Dn;function eo(){return Dn||(Dn=1,(function(s){const i=Be(),a=Jr(),o=Qr(),r=Wr(),t=Xr(),c=$n(),d=De(),l=Zr();function u(P){return unescape(encodeURIComponent(P)).length}function p(P,L,R){const B=[];let q;for(;(q=P.exec(R))!==null;)B.push({data:q[0],index:q.index,mode:L,length:q[0].length});return B}function S(P){const L=p(c.NUMERIC,i.NUMERIC,P),R=p(c.ALPHANUMERIC,i.ALPHANUMERIC,P);let B,q;return d.isKanjiModeEnabled()?(B=p(c.BYTE,i.BYTE,P),q=p(c.KANJI,i.KANJI,P)):(B=p(c.BYTE_KANJI,i.BYTE,P),q=[]),L.concat(R,B,q).sort(function(x,v){return x.index-v.index}).map(function(x){return{data:x.data,mode:x.mode,length:x.length}})}function b(P,L){switch(L){case i.NUMERIC:return a.getBitsLength(P);case i.ALPHANUMERIC:return o.getBitsLength(P);case i.KANJI:return t.getBitsLength(P);case i.BYTE:return r.getBitsLength(P)}}function f(P){return P.reduce(function(L,R){const B=L.length-1>=0?L[L.length-1]:null;return B&&B.mode===R.mode?(L[L.length-1].data+=R.data,L):(L.push(R),L)},[])}function j(P){const L=[];for(let R=0;R<P.length;R++){const B=P[R];switch(B.mode){case i.NUMERIC:L.push([B,{data:B.data,mode:i.ALPHANUMERIC,length:B.length},{data:B.data,mode:i.BYTE,length:B.length}]);break;case i.ALPHANUMERIC:L.push([B,{data:B.data,mode:i.BYTE,length:B.length}]);break;case i.KANJI:L.push([B,{data:B.data,mode:i.BYTE,length:u(B.data)}]);break;case i.BYTE:L.push([{data:B.data,mode:i.BYTE,length:u(B.data)}])}}return L}function M(P,L){const R={},B={start:{}};let q=["start"];for(let m=0;m<P.length;m++){const x=P[m],v=[];for(let g=0;g<x.length;g++){const C=x[g],N=""+m+g;v.push(N),R[N]={node:C,lastCount:0},B[N]={};for(let T=0;T<q.length;T++){const A=q[T];R[A]&&R[A].node.mode===C.mode?(B[A][N]=b(R[A].lastCount+C.length,C.mode)-b(R[A].lastCount,C.mode),R[A].lastCount+=C.length):(R[A]&&(R[A].lastCount=C.length),B[A][N]=b(C.length,C.mode)+4+i.getCharCountIndicator(C.mode,L))}}q=v}for(let m=0;m<q.length;m++)B[q[m]].end=0;return{map:B,table:R}}function U(P,L){let R;const B=i.getBestModeForData(P);if(R=i.from(L,B),R!==i.BYTE&&R.bit<B.bit)throw new Error('"'+P+'" cannot be encoded with mode '+i.toString(R)+`.
 Suggested mode is: `+i.toString(B));switch(R===i.KANJI&&!d.isKanjiModeEnabled()&&(R=i.BYTE),R){case i.NUMERIC:return new a(P);case i.ALPHANUMERIC:return new o(P);case i.KANJI:return new t(P);case i.BYTE:return new r(P)}}s.fromArray=function(L){return L.reduce(function(R,B){return typeof B=="string"?R.push(U(B,null)):B.data&&R.push(U(B.data,B.mode)),R},[])},s.fromString=function(L,R){const B=S(L,d.isKanjiModeEnabled()),q=j(B),m=M(q,R),x=l.find_path(m.map,"start","end"),v=[];for(let g=1;g<x.length-1;g++)v.push(m.table[x[g]].node);return s.fromArray(f(v))},s.rawSplit=function(L){return s.fromArray(S(L,d.isKanjiModeEnabled()))}})(kt)),kt}var Bn;function to(){if(Bn)return Nt;Bn=1;const s=De(),i=$t(),a=_r(),o=Ur(),r=Vr(),t=Hr(),c=qr(),d=qn(),l=Gr(),u=Yr(),p=Kr(),S=Be(),b=eo();function f(m,x){const v=m.size,g=t.getPositions(x);for(let C=0;C<g.length;C++){const N=g[C][0],T=g[C][1];for(let A=-1;A<=7;A++)if(!(N+A<=-1||v<=N+A))for(let I=-1;I<=7;I++)T+I<=-1||v<=T+I||(A>=0&&A<=6&&(I===0||I===6)||I>=0&&I<=6&&(A===0||A===6)||A>=2&&A<=4&&I>=2&&I<=4?m.set(N+A,T+I,!0,!0):m.set(N+A,T+I,!1,!0))}}function j(m){const x=m.size;for(let v=8;v<x-8;v++){const g=v%2===0;m.set(v,6,g,!0),m.set(6,v,g,!0)}}function M(m,x){const v=r.getPositions(x);for(let g=0;g<v.length;g++){const C=v[g][0],N=v[g][1];for(let T=-2;T<=2;T++)for(let A=-2;A<=2;A++)T===-2||T===2||A===-2||A===2||T===0&&A===0?m.set(C+T,N+A,!0,!0):m.set(C+T,N+A,!1,!0)}}function U(m,x){const v=m.size,g=u.getEncodedBits(x);let C,N,T;for(let A=0;A<18;A++)C=Math.floor(A/3),N=A%3+v-8-3,T=(g>>A&1)===1,m.set(C,N,T,!0),m.set(N,C,T,!0)}function P(m,x,v){const g=m.size,C=p.getEncodedBits(x,v);let N,T;for(N=0;N<15;N++)T=(C>>N&1)===1,N<6?m.set(N,8,T,!0):N<8?m.set(N+1,8,T,!0):m.set(g-15+N,8,T,!0),N<8?m.set(8,g-N-1,T,!0):N<9?m.set(8,15-N-1+1,T,!0):m.set(8,15-N-1,T,!0);m.set(g-8,8,1,!0)}function L(m,x){const v=m.size;let g=-1,C=v-1,N=7,T=0;for(let A=v-1;A>0;A-=2)for(A===6&&A--;;){for(let I=0;I<2;I++)if(!m.isReserved(C,A-I)){let Y=!1;T<x.length&&(Y=(x[T]>>>N&1)===1),m.set(C,A-I,Y),N--,N===-1&&(T++,N=7)}if(C+=g,C<0||v<=C){C-=g,g=-g;break}}}function R(m,x,v){const g=new a;v.forEach(function(I){g.put(I.mode.bit,4),g.put(I.getLength(),S.getCharCountIndicator(I.mode,m)),I.write(g)});const C=s.getSymbolTotalCodewords(m),N=d.getTotalCodewordsCount(m,x),T=(C-N)*8;for(g.getLengthInBits()+4<=T&&g.put(0,4);g.getLengthInBits()%8!==0;)g.putBit(0);const A=(T-g.getLengthInBits())/8;for(let I=0;I<A;I++)g.put(I%2?17:236,8);return B(g,m,x)}function B(m,x,v){const g=s.getSymbolTotalCodewords(x),C=d.getTotalCodewordsCount(x,v),N=g-C,T=d.getBlocksCount(x,v),A=g%T,I=T-A,Y=Math.floor(g/T),K=Math.floor(N/T),dt=K+1,Ce=Y-K,ut=new l(Ce);let Me=0;const Ne=new Array(T),Ve=new Array(T);let $=0;const mt=new Uint8Array(m.buffer);for(let ae=0;ae<T;ae++){const de=ae<I?K:dt;Ne[ae]=mt.slice(Me,Me+de),Ve[ae]=ut.encode(Ne[ae]),Me+=de,$=Math.max($,de)}const He=new Uint8Array(g);let G=0,ce,le;for(ce=0;ce<$;ce++)for(le=0;le<T;le++)ce<Ne[le].length&&(He[G++]=Ne[le][ce]);for(ce=0;ce<Ce;ce++)for(le=0;le<T;le++)He[G++]=Ve[le][ce];return He}function q(m,x,v,g){let C;if(Array.isArray(m))C=b.fromArray(m);else if(typeof m=="string"){let Y=x;if(!Y){const K=b.rawSplit(m);Y=u.getBestVersionForData(K,v)}C=b.fromString(m,Y||40)}else throw new Error("Invalid data");const N=u.getBestVersionForData(C,v);if(!N)throw new Error("The amount of data is too big to be stored in a QR Code");if(!x)x=N;else if(x<N)throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+N+`.
`);const T=R(x,v,C),A=s.getSymbolSize(x),I=new o(A);return f(I,x),j(I),M(I,x),P(I,v,0),x>=7&&U(I,x),L(I,T),isNaN(g)&&(g=c.getBestMask(I,P.bind(null,I,v))),c.applyMask(g,I),P(I,v,g),{modules:I,version:x,errorCorrectionLevel:v,maskPattern:g,segments:C}}return Nt.create=function(x,v){if(typeof x>"u"||x==="")throw new Error("No input text");let g=i.M,C,N;return typeof v<"u"&&(g=i.from(v.errorCorrectionLevel,i.M),C=u.from(v.version),N=c.from(v.maskPattern),v.toSJISFunc&&s.setToSJISFunction(v.toSJISFunc)),q(x,C,g,N)},Nt}var Ht={},qt={},Mn;function Gn(){return Mn||(Mn=1,(function(s){function i(a){if(typeof a=="number"&&(a=a.toString()),typeof a!="string")throw new Error("Color should be defined as hex string");let o=a.slice().replace("#","").split("");if(o.length<3||o.length===5||o.length>8)throw new Error("Invalid hex color: "+a);(o.length===3||o.length===4)&&(o=Array.prototype.concat.apply([],o.map(function(t){return[t,t]}))),o.length===6&&o.push("F","F");const r=parseInt(o.join(""),16);return{r:r>>24&255,g:r>>16&255,b:r>>8&255,a:r&255,hex:"#"+o.slice(0,6).join("")}}s.getOptions=function(o){o||(o={}),o.color||(o.color={});const r=typeof o.margin>"u"||o.margin===null||o.margin<0?4:o.margin,t=o.width&&o.width>=21?o.width:void 0,c=o.scale||4;return{width:t,scale:t?4:c,margin:r,color:{dark:i(o.color.dark||"#000000ff"),light:i(o.color.light||"#ffffffff")},type:o.type,rendererOpts:o.rendererOpts||{}}},s.getScale=function(o,r){return r.width&&r.width>=o+r.margin*2?r.width/(o+r.margin*2):r.scale},s.getImageWidth=function(o,r){const t=s.getScale(o,r);return Math.floor((o+r.margin*2)*t)},s.qrToImageData=function(o,r,t){const c=r.modules.size,d=r.modules.data,l=s.getScale(c,t),u=Math.floor((c+t.margin*2)*l),p=t.margin*l,S=[t.color.light,t.color.dark];for(let b=0;b<u;b++)for(let f=0;f<u;f++){let j=(b*u+f)*4,M=t.color.light;if(b>=p&&f>=p&&b<u-p&&f<u-p){const U=Math.floor((b-p)/l),P=Math.floor((f-p)/l);M=S[d[U*c+P]?1:0]}o[j++]=M.r,o[j++]=M.g,o[j++]=M.b,o[j]=M.a}}})(qt)),qt}var Ln;function no(){return Ln||(Ln=1,(function(s){const i=Gn();function a(r,t,c){r.clearRect(0,0,t.width,t.height),t.style||(t.style={}),t.height=c,t.width=c,t.style.height=c+"px",t.style.width=c+"px"}function o(){try{return document.createElement("canvas")}catch{throw new Error("You need to specify a canvas element")}}s.render=function(t,c,d){let l=d,u=c;typeof l>"u"&&(!c||!c.getContext)&&(l=c,c=void 0),c||(u=o()),l=i.getOptions(l);const p=i.getImageWidth(t.modules.size,l),S=u.getContext("2d"),b=S.createImageData(p,p);return i.qrToImageData(b.data,t,l),a(S,u,p),S.putImageData(b,0,0),u},s.renderToDataURL=function(t,c,d){let l=d;typeof l>"u"&&(!c||!c.getContext)&&(l=c,c=void 0),l||(l={});const u=s.render(t,c,l),p=l.type||"image/png",S=l.rendererOpts||{};return u.toDataURL(p,S.quality)}})(Ht)),Ht}var zt={},kn;function ro(){if(kn)return zt;kn=1;const s=Gn();function i(r,t){const c=r.a/255,d=t+'="'+r.hex+'"';return c<1?d+" "+t+'-opacity="'+c.toFixed(2).slice(1)+'"':d}function a(r,t,c){let d=r+t;return typeof c<"u"&&(d+=" "+c),d}function o(r,t,c){let d="",l=0,u=!1,p=0;for(let S=0;S<r.length;S++){const b=Math.floor(S%t),f=Math.floor(S/t);!b&&!u&&(u=!0),r[S]?(p++,S>0&&b>0&&r[S-1]||(d+=u?a("M",b+c,.5+f+c):a("m",l,0),l=0,u=!1),b+1<t&&r[S+1]||(d+=a("h",p),p=0)):l++}return d}return zt.render=function(t,c,d){const l=s.getOptions(c),u=t.modules.size,p=t.modules.data,S=u+l.margin*2,b=l.color.light.a?"<path "+i(l.color.light,"fill")+' d="M0 0h'+S+"v"+S+'H0z"/>':"",f="<path "+i(l.color.dark,"stroke")+' d="'+o(p,u,l.margin)+'"/>',j='viewBox="0 0 '+S+" "+S+'"',U='<svg xmlns="http://www.w3.org/2000/svg" '+(l.width?'width="'+l.width+'" height="'+l.width+'" ':"")+j+' shape-rendering="crispEdges">'+b+f+`</svg>
`;return typeof d=="function"&&d(null,U),U},zt}var Fn;function oo(){if(Fn)return Ue;Fn=1;const s=Or(),i=to(),a=no(),o=ro();function r(t,c,d,l,u){const p=[].slice.call(arguments,1),S=p.length,b=typeof p[S-1]=="function";if(!b&&!s())throw new Error("Callback required as last argument");if(b){if(S<2)throw new Error("Too few arguments provided");S===2?(u=d,d=c,c=l=void 0):S===3&&(c.getContext&&typeof u>"u"?(u=l,l=void 0):(u=l,l=d,d=c,c=void 0))}else{if(S<1)throw new Error("Too few arguments provided");return S===1?(d=c,c=l=void 0):S===2&&!c.getContext&&(l=d,d=c,c=void 0),new Promise(function(f,j){try{const M=i.create(d,l);f(t(M,c,l))}catch(M){j(M)}})}try{const f=i.create(d,l);u(null,t(f,c,l))}catch(f){u(f)}}return Ue.create=i.create,Ue.toCanvas=r.bind(null,a.render),Ue.toDataURL=r.bind(null,a.renderToDataURL),Ue.toString=r.bind(null,function(t,c,d){return o.render(t,d)}),Ue}var so=oo();const io=gr(so);function Wo(){const[s,i]=_.useState(0),[a,o]=_.useState(!1),[r,t]=_.useState(null),[c,d]=_.useState([]),[l,u]=_.useState([]),[p,S]=_.useState([]),[b,f]=_.useState(""),[j,M]=_.useState(!0),[U,P]=_.useState(null),[L,R]=_.useState(null),[B,q]=_.useState(null),[m,x]=_.useState(""),[v,g]=_.useState({}),[C,N]=_.useState([]),[T,A]=_.useState(!1),[I,Y]=_.useState(null),[K,dt]=_.useState(null),[Ce,ut]=_.useState(""),[Me,Ne]=_.useState(!1),[Ve,$]=_.useState(""),[mt,He]=_.useState([]),{permissions:G=[],user:ce}=fr(),le=ce?.branchAccess==="ALL",ae=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW),de=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE),we=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.CUSTOMER),Ee=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.PAYMENT_VERIFICATION),Le=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.COMPLETE_PAYMENT),ke=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.PENDING_LIST),Te=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.VERIFIED_LIST),qe=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE,ie.RECEIPTS.CUSTOMER),ze=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE,ie.RECEIPTS.PAYMENT_VERIFICATION),Yn=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE,ie.RECEIPTS.COMPLETE_PAYMENT),Kn=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE,ie.RECEIPTS.PENDING_LIST),Jn=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.CREATE,ie.RECEIPTS.VERIFIED_LIST);W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.UPDATE,ie.RECEIPTS.CUSTOMER),W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.UPDATE,ie.RECEIPTS.PAYMENT_VERIFICATION);const ht=W(G,ee.ACCOUNT,Z.ACCOUNT.RECEIPTS,X.VIEW,ie.RECEIPTS.CUSTOMER)||we,ye=we||Ee||Le||ke||Te;_.useEffect(()=>{if(!ye)return;const n=[];we&&n.push(0),Ee&&n.push(1),Le&&n.push(2),ke&&n.push(3),Te&&n.push(4),n.length>0&&!n.includes(s)&&i(n[0])},[ye,we,Ee,Le,ke,Te,s]),_.useEffect(()=>{if(!ae){se("You do not have permission to view Receipts"),M(!1);return}if(!ye){se("You do not have permission to view any Receipt tabs"),M(!1);return}Xn(),Gt(),Yt(),Qn(),Wn()},[ae,ye]),_.useEffect(()=>(window.printReceiptCallback=Ct,()=>{delete window.printReceiptCallback}),[]);const Qn=async()=>{try{const n=["/cash-locations","/cashlocations","/settings/cash-locations","/master/cash-locations"];for(const y of n)try{const k=await ne.get(y);if(k.data.success&&k.data.data){N(k.data.data),console.log("Cash locations loaded:",k.data.data);return}}catch{console.log(`Endpoint ${y} not available`)}console.warn("Could not fetch cash locations from any endpoint"),N([])}catch(n){console.error("Error fetching cash locations:",n),N([])}},Wn=async()=>{try{const n=await ne.get("/branches");He(n.data.data)}catch(n){const y=se(n);y&&P(y)}},Xn=async()=>{try{M(!0);const y=(await ne.get("/bookings")).data.data.bookings.filter(F=>F.bookingType==="BRANCH");d(y);const k=y.map(async F=>{try{const h=await ne.get(`/ledger/booking/${F._id}`);return{bookingId:F._id,receipts:h.data.data.allReceipts||[]}}catch(h){return console.error(`Error fetching receipts for booking ${F._id}:`,h),{bookingId:F._id,receipts:[]}}}),w=await Promise.all(k),V={};w.forEach(F=>{V[F.bookingId]=F.receipts}),g(V)}catch(n){const y=se(n);y&&P(y)}finally{M(!1)}},Gt=async()=>{if(!(!ae||!Ee))try{const n=await ne.get("/ledger/pending");u(n.data.data.ledgerEntries)}catch(n){const y=se(n);y&&P(y)}},Yt=async()=>{if(!(!ae||!Te))try{const n=await ne.get("/payment/verified/bank/ledger");S(n.data.data.ledgerEntries)}catch(n){const y=se(n);y&&P(y)}},Kt=n=>{if(!n)return"";const y=String(n.getDate()).padStart(2,"0"),k=String(n.getMonth()+1).padStart(2,"0"),w=n.getFullYear();return`${y}-${k}-${w}`},Jt=n=>{if(!n)return"";const y=n.getFullYear(),k=String(n.getMonth()+1).padStart(2,"0"),w=String(n.getDate()).padStart(2,"0");return`${y}-${k}-${w}`},vt=(n,y)=>{if(!y)return n;const k=br("receipts"),w=y.toLowerCase();return n.filter(V=>k.some(F=>{const h=F.split(".").reduce((O,H)=>O?H.match(/^\d+$/)?O[parseInt(H)]:O[H]:"",V);return h==null?!1:typeof h=="boolean"?(h?"yes":"no").includes(w):F==="createdAt"&&h instanceof Date?h.toLocaleDateString("en-GB").includes(w):typeof h=="number"?String(h).includes(w):String(h).toLowerCase().includes(w)}))},Zn=(n,y)=>{if(!y)return n;const k=y.toLowerCase();return n.filter(w=>(w.bookingDetails?.bookingNumber||"").toLowerCase().includes(k)||(w.bookingDetails?.customerDetails?.name||"").toLowerCase().includes(k)||(w.paymentMode||"").toLowerCase().includes(k)||String(w.amount||"").includes(k)||(w.transactionReference||"").toLowerCase().includes(k))},er=(n,y)=>{if(!y)return n;const k=y.toLowerCase();return n.filter(w=>(w.booking||"").toLowerCase().includes(k)||(w.bookingDetails?.customerDetails?.name||"").toLowerCase().includes(k)||(w.paymentMode||"").toLowerCase().includes(k)||String(w.amount||"").includes(k)||(w.transactionReference||"").toLowerCase().includes(k)||(w.receivedByDetails?.name||"").toLowerCase().includes(k))},Qt=vt(c,b),Wt=vt(c.filter(n=>parseFloat(n.balanceAmount||0)===0),b),Xt=vt(c.filter(n=>parseFloat(n.balanceAmount||0)!==0),b),Zt=Zn(l,b),en=er(p,b),tr=(n,y)=>{R(n.currentTarget),q(y)},xt=()=>{R(null),q(null)},nr=n=>{if(!qe){se("You do not have permission to add payments");return}t(n),o(!0),xt()},rr=async n=>{if(!ze){se("You do not have permission to verify payments");return}try{(await pr({title:"Confirm Payment Verification",text:`Are you sure you want to verify the payment of ₹${n.amount} for booking ${n.bookingDetails?.bookingNumber||n.booking}?`,confirmButtonText:"Yes, verify it!"})).isConfirmed&&(await ne.patch(`/ledger/approve/${n._id}`,{remark:""}),x("Payment verified successfully!"),setTimeout(()=>x(""),3e3),Gt(),Yt())}catch(y){console.error("Error verifying payment:",y),se(y,"Failed to verify payment")}},$e=n=>{ye&&(i(n),f(""))},or=()=>{if(!de){se("You do not have permission to export data");return}A(!0),$("")},bt=()=>{A(!1),Y(null),dt(null),ut(""),$("")},sr=async()=>{if(!de){se("You do not have permission to export data");return}if($(""),!Ce){$("Please select a branch");return}if(!I||!K){$("Please select both start and end dates");return}if(I>K){$("Start date cannot be after end date");return}try{Ne(!0);const n=Jt(I),y=Jt(K),k=new URLSearchParams({branchId:Ce,startDate:n,endDate:y,format:"excel"}),w=await ne.get(`/reports/receipts?${k.toString()}`,{responseType:"blob"}),V=w.headers["content-type"];if(V&&V.includes("application/json")){const Re=await new Promise((Fe,Se)=>{const me=new FileReader;me.onload=()=>Fe(me.result),me.onerror=Se,me.readAsText(w.data)}),be=JSON.parse(Re);if(!be.success&&be.message){$(be.message),Pe.fire({icon:"error",title:"Export Failed",text:be.message});return}}const F=new Blob([w.data],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),h=window.URL.createObjectURL(F),O=document.createElement("a");O.href=h;const H=mt.find(Re=>Re._id===Ce)?.name||"Branch",J=Kt(I),Q=Kt(K),ue=`Receipts_${H}_${J}_to_${Q}.xlsx`;O.setAttribute("download",ue),document.body.appendChild(O),O.click(),O.remove(),window.URL.revokeObjectURL(h),Pe.fire({toast:!0,position:"top-end",icon:"success",title:"Excel exported successfully!",showConfirmButton:!1,timer:3e3,timerProgressBar:!0}),bt()}catch(n){if(console.error("Error exporting report:",n),n.response&&n.response.data instanceof Blob)try{const y=await new Promise((w,V)=>{const F=new FileReader;F.onload=()=>w(F.result),F.onerror=V,F.readAsText(n.response.data)}),k=JSON.parse(y);k.message&&($(k.message),Pe.fire({icon:"error",title:"Export Failed",text:k.message}))}catch(y){console.error("Error parsing error response:",y),$("Failed to export report"),Pe.fire({icon:"error",title:"Export Failed",text:"Failed to export report"})}else n.response?.data?.message?($(n.response.data.message),Pe.fire({icon:"error",title:"Export Failed",text:n.response.data.message})):n.message?($(n.message),Pe.fire({icon:"error",title:"Export Failed",text:n.message})):($("Failed to export report"),Pe.fire({icon:"error",title:"Export Failed",text:"Failed to export report"}))}finally{Ne(!1)}},Ct=async(n,y,k=0)=>{if(!ht){se("You do not have permission to print invoices");return}try{const V=(await ne.get(`/ledger/receipt/${n}`)).data.data.receipt,F=await ne.get(`/bookings/booking-payment-status/${y}`),h=F.data.data.bookingDetails,O=F.data.data.finalStatus||"",H=V.qrCodeData||{},J=h.subsidyAmount||0,Q=h.model?.type==="EV",ue=h.priceComponents||[],be=ue.filter(oe=>{const pe=oe.header?.header_key?.toUpperCase()||"",Oe=/INSURANCE|INSURCANCE|INSUR|COVER|PREMIUM|INSURANCE CHARGES/i.test(pe),_e=/RTO|ROAD TAX|RTO TAX & REGISTRATION CHARGES/i.test(pe),gt=/HYPOTHECATION|HPA|HP CHARGES|HPA (if applicable)|HYPOTHECATION CHARGES (IF APPLICABLE)/i.test(pe);return!(Oe||_e||gt)}).reduce((oe,pe)=>oe+(pe.discountedValue||0),0),Fe=oe=>ue.find(pe=>{const Oe=pe.header?.header_key?.toUpperCase()||"";return oe.some(_e=>Oe.includes(_e))}),Se=Fe(["INSURANCE","INSURCANCE","INSURANCE CHARGES","INSURANCE 4+1 INCLUSIVE OF ADDITIONAL COVERS"]),me=Se?Se.originalValue:0,Ge=Fe(["RTO","RTO TAX & REGISTRATION CHARGES"]),Ye=Ge?Ge.originalValue:0,Ke=Fe(["HYPOTHECATION","HPA","HPA (if applicable)"]),Je=Ke?Ke.originalValue:h.hypothecationCharges||0,Qe=me+Ye+Je,We=Q&&J>0?J:0,Xe=be+Qe-We,Ze=`GANDHI MOTORS PVT LTD
Booking Number: ${H.bookingNumber||h.bookingNumber}
Customer: ${H.customerName||h.customerDetails?.name}
Mobile: ${H.mobileNo||h.customerDetails?.mobile1}
Model: ${H.modelName||h.model?.model_name}
Type: ${h.model?.type||"N/A"}
Chassis: ${H.chassisNo||h.chassisNumber||"Not allocated"}
Payment Type: ${H.paymentType||h.payment?.type}
Total Amount: ₹${Xe.toFixed(2)}
${Q&&J>0?`Subsidy: -₹${J.toFixed(2)}`:""}
Receipt: ${V.receiptNumber||"N/A"}
Amount: ${V.display?.amount||`₹${V.amount?.toFixed(2)||"0"}`}
Payment Mode: ${V.paymentMode||"Cash"}
Reference: ${V.transactionReference||"N/A"}
Date: ${new Date(V.receiptDate).toLocaleDateString("en-GB")}`;let et="";try{et=await io.toDataURL(Ze,{width:250,margin:3,color:{dark:"#000000",light:"#FFFFFF"},errorCorrectionLevel:"H"})}catch(oe){console.error("Error generating QR code:",oe),et="data:image/svg+xml;base64,"+btoa(`
        <svg xmlns="http://www.w3.org/2000/svg" width="250" height="250">
          <rect width="250" height="250" fill="white"/>
          <rect x="20" y="20" width="210" height="210" fill="#f0f0f0" stroke="#ccc" stroke-width="2"/>
          <text x="125" y="115" text-anchor="middle" font-family="Arial" font-size="16" fill="#333">QR CODE</text>
          <text x="125" y="140" text-anchor="middle" font-family="Arial" font-size="12" fill="#666">Receipt: ${V.receiptNumber}</text>
          <text x="125" y="160" text-anchor="middle" font-family="Arial" font-size="10" fill="#999">Scan for details</text>
        </svg>
      `)}const z={bookingNumber:h.bookingNumber,bookingType:h.bookingType,rto:h.rto,hpa:h.hpa,hypothecationCharges:h.hypothecationCharges||0,gstin:h.gstin||"",model:{model_name:h.model?.model_name||"N/A",type:h.model?.type||"N/A"},chassisNumber:H.chassisNo||h.chassisNumber,engineNumber:h.vehicle?.engineNumber||h.engineNumber,batteryNumber:h.vehicle?.batteryNumber||"",keyNumber:h.vehicle?.keyNumber||"",color:{name:h.color?.name||""},customerDetails:{name:h.customerDetails?.name||"N/A",address:h.customerDetails?.address||"",taluka:h.customerDetails?.taluka||"",district:h.customerDetails?.district||"",pincode:h.customerDetails?.pincode||"",mobile1:h.customerDetails?.mobile1||"",dob:h.customerDetails?.dob||"",aadharNumber:h.customerDetails?.aadharNumber||""},exchange:h.exchange,exchangeDetails:h.exchangeDetails,payment:{type:h.payment?.type||"CASH",financer:h.payment?.financer},salesExecutive:h.salesExecutive,branch:{gst_number:h.branch?.gst_number||""},accessories:h.accessories||[],priceComponents:h.priceComponents||[],subdealer:h.subdealer||"",receivedAmount:h.receivedAmount||0,finalStatus:O||"",recentPayment:V,qrCodeData:H,qrCodeImage:et,qrCodeText:Ze,recentPaymentAmount:V.amount||0,bookingDetails:h,subsidyAmount:J,calculatedTotals:{totalA:be,totalB:Qe,grandTotal:Xe,insuranceCharges:me,rtoCharges:Ye,hpCharges:Je,subsidyDisplay:We}},je=ir(z,k===0),ge=window.open("","_blank");ge.document.write(je),ge.document.close(),ge.onload=function(){ge.focus(),ge.print()}}catch(w){console.error("Error generating receipt invoice:",w),se(w,"Failed to generate receipt invoice")}},ir=(n,y=!0)=>{const k=n.exchange&&n.exchangeDetails?.broker?.name||"",w=n.exchange&&n.exchangeDetails?.vehicleNumber||"",V=new Date().toLocaleDateString("en-GB"),F=n.recentPayment?.receiptDate?new Date(n.recentPayment.receiptDate).toLocaleDateString("en-GB"):V,h=n.recentPaymentAmount||0,O=n.recentPayment?.transactionReference||"-",H=Fr(h),J=n.recentPayment?.paymentMode||"-",Q=n.recentPayment?.receiptNumber||"-";n.qrCodeData;const ue=n.qrCodeImage||"",Re=n.bookingDetails?.subsidyAmount||n.subsidyAmount||0,be=n.bookingDetails?.model?.type==="EV"||n.model?.type==="EV";if(y){const Se=n.priceComponents.filter(z=>{const he=z.header?.header_key?.toUpperCase()||"",je=/INSURANCE|INSURCANCE|INSUR|COVER|PREMIUM|INSURANCE CHARGES/i.test(he),ge=/RTO|ROAD TAX|RTO TAX & REGISTRATION CHARGES/i.test(he),oe=/HYPOTHECATION|HPA|HP CHARGES|HPA (if applicable)|HYPOTHECATION CHARGES (IF APPLICABLE)/i.test(he);return!(je||ge||oe)}).map(z=>{const he=parseFloat(z.header?.metadata?.gst_rate)||0,je=z.originalValue,ge=0,oe=z.originalValue,pe=oe*100/(100+he),Oe=oe-pe,_e=Oe/2,gt=Oe/2,mr=_e+gt;return{...z,unitCost:je,taxableValue:pe,cgstAmount:_e,sgstAmount:gt,gstAmount:mr,gstRatePercentage:he,discount:ge,lineTotal:oe}}),me=z=>n.priceComponents.find(he=>{const je=he.header?.header_key?.toUpperCase()||"";return z.some(ge=>je.includes(ge))}),Ge=me(["INSURANCE","INSURCANCE","INSURANCE CHARGES","INSURANCE 4+1 INCLUSIVE OF ADDITIONAL COVERS"]),Ye=Ge?Ge.originalValue:0,Ke=me(["RTO","RTO TAX & REGISTRATION CHARGES"]),Je=Ke?Ke.originalValue:0,Qe=me(["HYPOTHECATION","HPA","HPA (if applicable)"]),We=Qe?Qe.originalValue:n.hypothecationCharges||0,Xe=Se.reduce((z,he)=>z+he.lineTotal,0),Ze=Ye+Je+We,et=Xe+Ze;return`
<!DOCTYPE html>
<html>
<head>
  <title>Payment Receipt - ${Q}</title>
  <style>
    body {
      font-family: "Courier New", Courier, monospace;
      margin: 0;
      padding: 10mm;
      font-size: 14px;
      color: #555555;
    }
    .page {
      width: 210mm;
      height: 297mm;
      margin: 0 auto;
    }
    .header-container {
      display: flex;
      justify-content: space-between;
      margin-bottom: 2mm;
      align-items: flex-start;
    }
    .header-left {
      width: 60%;
    }
    .header-right {
      width: 40%;
      text-align: right;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    .logo-qr-container {
      display: flex;
      align-items: center;
      gap: 20px;
      justify-content: flex-end;
      margin-bottom: 10px;
      width: 100%;
    }
    .logo {
      height: 80px;
    }
    .qr-code-extra-big {
      width: 150px;
      height: 150px;
      border: 1px solid #ccc;
    }
    .dealer-info {
      text-align: left;
      font-size: 14px;
      line-height: 1.2;
    }
    .customer-info-container {
      display: flex;
      font-size:14px;
    }

    .customer-info-left {
      width: 50%;
    }
    .customer-info-right {
      width: 50%;
    }
    .customer-info-row {
      margin: 1mm 0;
      line-height: 1.2;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 9pt;
      margin: 2mm 0;
    }
    th, td {
      padding: 1mm;
      border: 1px solid #000;
      vertical-align: top;
    }
    .no-border { 
      border: none !important; 
      font-size:14px;
    }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .bold { 
      font-weight: bold; 
    }
    .section-title {
      font-weight: bold;
      margin: 1mm 0;
    }
    .signature-box {
      margin-top: 5mm;
      font-size: 9pt;
    }
    .signature-line {
      border-top: 1px dashed #000;
      width: 40mm;
      display: inline-block;
      margin: 0 5mm;
    }
    .footer {
      font-size: 8pt;
      text-align: justify;
      line-height: 1.2;
      margin-top: 3mm;
    }
    .divider {
      border-top: 2px solid #AAAAAA;
    }
    .totals-table {
      width: 100%;
      border-collapse: collapse;
      margin: 2mm 0;
    }
    .totals-table td {
      border: none;
      padding: 1mm;
    }
    .total-divider {
      border-top: 2px solid #AAAAAA;
      height: 1px;
      margin: 2px 0;
    }
    .broker-info{
      display:flex;
      justify-content:space-between;
      padding:1px;
    }
    .status-box {
      background-color: #e8f5e8;
      border: 2px solid #c3e6c3;
      border-radius: 4px;
      padding: 15px;
      margin: 10px 0;
      text-align: center;
      font-weight: bold;
      font-size: 20px;
      color: #495057;
    }
    .payment-info-title {
      font-weight: bold;
      margin-bottom: 5px;
      color: #155724;
      font-size: 16px;
    }
    .amount-in-words {
      font-style: italic;
      margin-top: 5px;
      color: #333;
      padding: 5px;
    }

    .note{
      padding:1px;
      margin:2px;
    }
    
    /* QR Code at bottom - even bigger */
    .qr-bottom-section {
      margin-top: 10mm;
      text-align: center;
      page-break-inside: avoid;
    }
    .qr-bottom-big {
      width: 180px;
      height: 180px;
      border: 1px solid #ccc;
      margin: 0 auto;
      display: block;
    }
    .qr-scan-text {
      font-size: 10pt;
      color: #777;
      margin-top: 3mm;
    }
    
    .receipt-info {
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 4px;
      padding: 10px;
      margin: 10px 0;
    }
    
    @page {
      size: A4;
      margin: 0;
    }
    @media print {
      body {
        padding: 5mm;
      }
      .qr-bottom-section {
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- Header Section with QR Code -->
    <div class="header-container">
      <div class="header-left">
        <h2 style="margin:3;font-size:15pt;">GANDHI MOTORS PVT LTD</h2>
        <div class="dealer-info">
          Authorized Main Dealer: TVS Motor Company Ltd.<br>
          Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
          Upnagar, Nashik Road, Nashik, 7498993672<br>
          GSTIN: ${n.branch?.gst_number||""}<br>
          GANDHI TVS PIMPALGAON
        </div>
      </div>
      <div class="header-right">
        <!-- Logo and QR code side by side -->
        <div class="logo-qr-container">
          <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
          ${ue?`<img src="${ue}" class="qr-code-extra-big" alt="QR Code" />`:""}
        </div>
        
        <div style="margin-top: 5px; font-size: 13px;">Date: ${F}</div>
        <div style="margin-top: 5px; font-size: 13px;"><strong>Receipt No:</strong> ${Q}</div>

        ${n.bookingType==="SUBDEALER"?`<div style="font-size: 12px;"><b>Subdealer:</b> ${n.subdealer?.name||""}</div>
        <div style="font-size: 11px;"><b>Address:</b> ${n.subdealer?.location||""}</div>
          
          `:""}
        
      </div>
    </div>
    <div class="divider"></div>

    <!-- Receipt Information -->
    <div class="receipt-info">
      <div><strong>Payment Receipt</strong></div>
      <div><strong>Booking Number:</strong> ${n.bookingNumber}</div>
      <div><strong>Receipt Date:</strong> ${F}</div>
    </div>

    <!-- Customer Information -->
    <div class="customer-info-container">
      <div class="customer-info-left">
        <div class="customer-info-row"><strong>Booking Number:</strong> ${n.bookingNumber}</div>
        <div class="customer-info-row"><strong>Customer Name:</strong> ${n.customerDetails.name}</div>
        <div class="customer-info-row"><strong>Address:</strong> ${n.customerDetails.address}, ${n.customerDetails.taluka},${n.customerDetails.pincode||""}</div>
        <div class="customer-info-row"><strong>Mobile No.:</strong> ${n.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${n.hpa?"YES":"NO"}</div>
      </div>
      <div class="customer-info-right">
        <div class="customer-info-row"><strong>Model Name:</strong> ${n.model.model_name}</div>
       <div class="customer-info-row"><strong>Chassis No:</strong> ${n.chassisNumber}</div>
        <div class="customer-info-row"><strong>Payment Type:</strong> ${n.payment?.type||"CASH"}</div>
         <div class="customer-info-row"><strong>Financer:</strong> ${n.payment?.financer?.name||""}</div>
        <div class="customer-info-row"><strong>Sales Executive:</strong> ${n.salesExecutive?.name||"N/A"}</div>
      </div>
    </div>

    <!-- Received Amount Section -->
    <div class="payment-info-box">
      <div class="receipt-info">
        <div><strong>Receipt Amount (Rs):</strong> ₹${n.recentPaymentAmount.toFixed(2)}</div>
        <div><strong>Receipt Number:</strong> ${Q}</div>
        <div><strong>Reference No:</strong> ${O}</div>
        <div><strong>Payment Mode:</strong> ${J}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>
      <div class="amount-in-words">
        <strong>(In Words):</strong> ${H} Only
      </div>
    </div>
    <!-- Price Breakdown Table -->
    <table>
      <tr>
        <th style="width:25%">Particulars</th>
        <th style="width:8%">HSN CODE</th>
        <th style="width:8%">Unit Cost</th>
        <th style="width:8%">Taxable</th>
        <th style="width:5%">CGST</th>
        <th style="width:8%">CGST AMOUNT</th>
        <th style="width:5%">SGST</th>
        <th style="width:8%">SGST AMOUNT</th>
        <th style="width:7%">DISCOUNT</th>
        <th style="width:10%">LINE TOTAL</th>
      </tr>

      ${Se.map(z=>`
        <tr>
          <td>${z.header?.header_key||""}</td>
          <td>${z.header?.metadata?.hsn_code||""}</td>
          <td >${z.unitCost.toFixed(2)}</td>
          <td >${z.taxableValue.toFixed(2)}</td>
          <td >${(z.gstRatePercentage/2).toFixed(2)}%</td>
          <td >${z.cgstAmount.toFixed(2)}</td>
          <td >${(z.gstRatePercentage/2).toFixed(2)}%</td>
          <td >${z.sgstAmount.toFixed(2)}</td>
          <td >${z.discount.toFixed(2)}</td>
          <td >${z.lineTotal.toFixed(2)}</td>
        </tr>
      `).join("")}
    </table>

    <!-- Totals Section - No Borders -->
     <table class="totals-table">
      <tr>
        <td class="no-border" style="width:80%"><strong>Total(A)</strong></td>
        <td class="no-border text-right"><strong>${Xe.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td colspan="2" class="no-border"><div class="total-divider"></div></td>
      </tr>
      <tr>
        <td class="no-border"><strong>INSURANCE CHARGES</strong></td>
        <td class="no-border text-right"><strong>${Ye.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>RTO TAX,REGISTRATION SMART CARD CHARGES AGENT FEES</strong></td>
        <td class="no-border text-right"><strong>${Je.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>HP CHARGES</strong></td>
        <td class="no-border text-right"><strong>${We.toFixed(2)}</strong></td>
      </tr>
        ${be&&Re>0?`
      <tr>
        <td class="no-border"><strong>SUBSIDY AMOUNT</strong></td>
        <td class="no-border text-right" style="color: green;"><strong>-${Re.toFixed(2)}</strong></td>
      </tr>
      `:""}
      <tr>
        <td colspan="2" class="no-border"><div class="total-divider"></div></td>
      </tr>
      <tr>
        <td class="no-border"><strong>TOTAL(B)</strong></td>
        <td class="no-border text-right"><strong>${Ze.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>GRAND TOTAL(A) + (B)</strong></td>
        <td class="no-border text-right"><strong>${et.toFixed(2)}</strong></td>
      </tr>
    </table>
    <div class="broker-info">
      <div><strong>Ex. Broker/ Sub Dealer:</strong>${k}</div>
      <div><strong>Ex. Veh No:</strong>${w}</div>
    </div>
    <div class="note"><strong>Notes:Booking Awaiting approval as discount exceed</strong></div>
    <div class="divider"></div>
    <div style="margin-top:2mm;">
      <div><strong>Booking Status: </strong>
      </div>
      <div class="status-box">
        ${n.finalStatus||"Status: Not Available"}
      </div>
    </div>
    <div class="divider"></div>

    <!-- BIG QR Code at Bottom -->
    
    <div class="divider" style="margin-top: 5mm;"></div>

    <!-- Signature Section - Adjusted to fit properly -->
    <div class="signature-box">
      <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Customer's Signature</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Sales Executive</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Manager</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Accountant</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  `}else return`
<!DOCTYPE html>
<html>
<head>
  <title>Payment Receipt - ${Q}</title>
  <style>
    body {
      font-family: "Courier New", Courier, monospace;
      margin: 0;
      padding: 10mm;
      font-size: 14px;
      color: #555555;
    }
    .page {
      width: 210mm;
      height: 297mm;
      margin: 0 auto;
    }
    .receipt-copy {
      height: 138mm; /* Half of A4 page */
      page-break-inside: avoid;
    }
    .header-container {
      display: flex;
      justify-content: space-between;
      margin-bottom: 2mm;
      align-items: flex-start;
    }
    .header-left {
      width: 60%;
    }
    .header-right {
      width: 40%;
      text-align: right;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    .logo-qr-container {
      display: flex;
      align-items: center;
      gap: 10px;
      justify-content: flex-end;
      margin-bottom: 5px;
      width: 100%;
    }
    .logo {
      height: 60px;
    }
    .qr-code-small {
      width: 100px;
      height: 100px;
      border: 1px solid #ccc;
    }
    .dealer-info {
      text-align: left;
      font-size: 12px;
      line-height: 1.1;
    }
    .customer-info-container {
      display: flex;
      font-size:12px;
    }
    .customer-info-left {
      width: 50%;
    }
    .customer-info-right {
      width: 50%;
    }
    .customer-info-row {
      margin: 0.5mm 0;
      line-height: 1.1;
    }
    .divider {
      border-top: 1px solid #AAAAAA;
      margin: 2mm 0;
    }
    .receipt-info {
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 4px;
      padding: 8px;
      margin: 8px 0;
      font-size: 12px;
    }
    .payment-info-box {
      margin: 5px 0;
    }
    .signature-box {
      margin-top: 3mm;
      font-size: 8pt;
    }
    .signature-line {
      border-top: 1px dashed #000;
      width: 35mm;
      display: inline-block;
      margin: 0 3mm;
    }
    .cutting-line {
      border-top: 2px dashed #333;
      margin: 10mm 0;
      text-align: center;
      position: relative;
    }
    .cutting-line::before {
      content: "✂ Cut Here ✂";
      position: absolute;
      top: -10px;
      left: 50%;
      transform: translateX(-50%);
      background: white;
      padding: 0 10px;
      font-size: 10px;
      color: #666;
    }
    .note{
      padding:1px;
      margin:2px;
      font-size: 11px;
    }
    
    @page {
      size: A4;
      margin: 0;
    }
    @media print {
      body {
        padding: 5mm;
      }
      .receipt-copy {
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- First Copy -->
    <div class="receipt-copy">
      <!-- Header Section with QR Code -->
      <div class="header-container">
        <div class="header-left">
          <h2 style="margin:2;font-size:12pt;">GANDHI MOTORS PVT LTD</h2>
          <div class="dealer-info">
            Authorized Main Dealer: TVS Motor Company Ltd.<br>
            Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
            Upnagar, Nashik Road, Nashik, 7498993672<br>
            GSTIN: ${n.branch?.gst_number||""}<br>
            GANDHI TVS PIMPALGAON
          </div>
        </div>
        <div class="header-right">
          <!-- Logo and QR code side by side -->
          <div class="logo-qr-container">
            <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
            ${ue?`<img src="${ue}" class="qr-code-small" alt="QR Code" />`:""}
          </div>
          
          <div style="margin-top: 3px; font-size: 11px;">Date: ${F}</div>
          <div style="margin-top: 3px; font-size: 11px;"><strong>Receipt No:</strong> ${Q}</div>

          ${n.bookingType==="SUBDEALER"?`<div style="font-size: 10px;"><b>Subdealer:</b> ${n.subdealer?.name||""}</div>
          <div style="font-size: 9px;"><b>Address:</b> ${n.subdealer?.location||""}</div>`:""}
        </div>
      </div>
      <div class="divider"></div>

      <!-- Receipt Information -->
      <div class="receipt-info">
        <div><strong>Payment Receipt</strong></div>
        <div><strong>Booking Number:</strong> ${n.bookingNumber}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>

      <!-- Customer Information -->
      <div class="customer-info-container">
        <div class="customer-info-left">
          <div class="customer-info-row"><strong>Booking Number:</strong> ${n.bookingNumber}</div>
          <div class="customer-info-row"><strong>Customer Name:</strong> ${n.customerDetails.name}</div>
          <div class="customer-info-row"><strong>Address:</strong> ${n.customerDetails.address}, ${n.customerDetails.taluka}</div>
          <div class="customer-info-row"><strong>Mobile No.:</strong> ${n.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${n.hpa?"YES":"NO"}</div>
        </div>
        <div class="customer-info-right">
          <div class="customer-info-row"><strong>Model Name:</strong> ${n.model.model_name}</div>
          <div class="customer-info-row"><strong>Chassis No:</strong> ${n.chassisNumber}</div>
          <div class="customer-info-row"><strong>Payment Type:</strong> ${n.payment?.type||"CASH"}</div>
          <div class="customer-info-row"><strong>Financer:</strong> ${n.payment?.financer?.name||""}</div>
          <div class="customer-info-row"><strong>Sales Executive:</strong> ${n.salesExecutive?.name||"N/A"}</div>
        </div>
      </div>

      <!-- Received Amount Section -->
      <div class="payment-info-box">
        <div class="receipt-info">
          <div><strong>Receipt Amount (Rs):</strong> ₹${n.recentPaymentAmount.toFixed(2)}</div>
          <div><strong>Receipt Number:</strong> ${Q}</div>
          <div><strong>Reference No:</strong> ${O}</div>
          <div><strong>Payment Mode:</strong> ${J}</div>
          <div><strong>Receipt Date:</strong> ${F}</div>
        </div>
      </div>

      <div class="note"><strong>Notes:</strong></div>
      <div class="divider"></div>

      <!-- Signature Section -->
      <div class="signature-box">
        <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Customer's Signature</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Sales Executive</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Manager</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Accountant</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Cutting Line -->
    <div class="cutting-line"></div>

    <!-- Second Copy (Duplicate) -->
    <div class="receipt-copy">
      <!-- Header Section with QR Code -->
      <div class="header-container">
        <div class="header-left">
          <h2 style="margin:2;font-size:12pt;">GANDHI MOTORS PVT LTD</h2>
          <div class="dealer-info">
            Authorized Main Dealer: TVS Motor Company Ltd.<br>
            Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
            Upnagar, Nashik Road, Nashik, 7498993672<br>
            GSTIN: ${n.branch?.gst_number||""}<br>
            GANDHI TVS PIMPALGAON
          </div>
        </div>
        <div class="header-right">
          <!-- Logo and QR code side by side -->
          <div class="logo-qr-container">
            <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
            ${ue?`<img src="${ue}" class="qr-code-small" alt="QR Code" />`:""}
          </div>
          
          <div style="margin-top: 3px; font-size: 11px;">Date: ${F}</div>
          <div style="margin-top: 3px; font-size: 11px;"><strong>Receipt No:</strong> ${Q}</div>

          ${n.bookingType==="SUBDEALER"?`<div style="font-size: 10px;"><b>Subdealer:</b> ${n.subdealer?.name||""}</div>
          <div style="font-size: 9px;"><b>Address:</b> ${n.subdealer?.location||""}</div>`:""}
        </div>
      </div>
      <div class="divider"></div>

      <!-- Receipt Information -->
      <div class="receipt-info">
        <div><strong>Payment Receipt (DUPLICATE)</strong></div>
        <div><strong>Booking Number:</strong> ${n.bookingNumber}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>

      <!-- Customer Information -->
      <div class="customer-info-container">
        <div class="customer-info-left">
          <div class="customer-info-row"><strong>Booking Number:</strong> ${n.bookingNumber}</div>
          <div class="customer-info-row"><strong>Customer Name:</strong> ${n.customerDetails.name}</div>
          <div class="customer-info-row"><strong>Address:</strong> ${n.customerDetails.address}, ${n.customerDetails.taluka}</div>
          <div class="customer-info-row"><strong>Mobile No.:</strong> ${n.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${n.hpa?"YES":"NO"}</div>
        </div>
        <div class="customer-info-right">
          <div class="customer-info-row"><strong>Model Name:</strong> ${n.model.model_name}</div>
          <div class="customer-info-row"><strong>Chassis No:</strong> ${n.chassisNumber}</div>
          <div class="customer-info-row"><strong>Payment Type:</strong> ${n.payment?.type||"CASH"}</div>
          <div class="customer-info-row"><strong>Financer:</strong> ${n.payment?.financer?.name||""}</div>
          <div class="customer-info-row"><strong>Sales Executive:</strong> ${n.salesExecutive?.name||"N/A"}</div>
        </div>
      </div>

      <!-- Received Amount Section -->
      <div class="payment-info-box">
        <div class="receipt-info">
          <div><strong>Receipt Amount (Rs):</strong> ₹${n.recentPaymentAmount.toFixed(2)}</div>
          <div><strong>Receipt Number:</strong> ${Q}</div>
          <div><strong>Reference No:</strong> ${O}</div>
          <div><strong>Payment Mode:</strong> ${J}</div>
          <div><strong>Receipt Date:</strong> ${F}</div>
        </div>
      </div>

      <div class="note"><strong>Notes:</strong></div>
      <div class="divider"></div>

      <!-- Signature Section -->
      <div class="signature-box">
        <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Customer's Signature</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Sales Executive</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Manager</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Accountant</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  `},ar=()=>{if(!we)return e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Customer tab."})});const n=qe||ht,y=qe,k=ht;return e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(it,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(at,{children:e.jsxs(te,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"}),e.jsx(D,{scope:"col",children:"Receipts"}),n&&e.jsx(D,{scope:"col",children:"Action"})]})}),e.jsx(ct,{children:Qt.length===0?e.jsx(te,{children:e.jsx(E,{colSpan:n?"12":"11",style:{color:"red",textAlign:"center"},children:b?"No matching bookings found":"No booking available"})}):Qt.map((w,V)=>{const h=[...v[w._id]||[]].sort((O,H)=>{const J=new Date(O.receiptDate||O.createdAt||0),Q=new Date(H.receiptDate||H.createdAt||0);return J-Q});return e.jsxs(te,{children:[e.jsx(E,{children:V+1}),e.jsx(E,{children:w.bookingNumber}),e.jsx(E,{children:w.model?.model_name||"N/A"}),e.jsx(E,{children:w.createdAt?new Date(w.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(E,{children:w.customerDetails?.name||"N/A"}),e.jsx(E,{children:w.customerDetails?.mobile1||"N/A"}),e.jsx(E,{children:w.chassisAllocationStatus==="ALLOCATED"&&w.status==="ALLOCATED"&&w.chassisNumber||""}),e.jsx(E,{children:Math.round(w.discountedAmount)||"0"}),e.jsx(E,{children:Math.round(w.receivedAmount)||"0"}),e.jsx(E,{children:Math.round(w.balanceAmount)||"0"}),e.jsx(E,{children:h.length>0?e.jsxs(rn,{children:[e.jsxs(on,{size:"sm",color:"info",variant:"outline",disabled:!k,children:[h.length," Receipt",h.length>1?"s":""]}),e.jsx(sn,{children:h.map((O,H)=>e.jsx(an,{onClick:()=>Ct(O.id,w._id,H),children:e.jsxs("div",{className:"d-flex align-items-center",children:[e.jsx(nt,{icon:ln,className:"me-2"}),e.jsxs("div",{children:[e.jsx("div",{children:e.jsxs("strong",{children:["Receipt #",H+1]})}),e.jsxs("small",{children:[O.display?.amount||`₹${O.amount}`," -",O.display?.date||new Date(O.receiptDate).toLocaleDateString("en-GB")]})]})]})},O.id))})]}):e.jsx("span",{className:"text-muted",children:"No receipts"})}),n&&e.jsxs(E,{children:[e.jsxs(Ie,{size:"sm",className:"option-button btn-sm",onClick:O=>tr(O,w._id),disabled:!y,children:[e.jsx(nt,{icon:yr}),"Options"]}),e.jsx(Dr,{id:`action-menu-${w._id}`,anchorEl:L,open:B===w._id,onClose:xt,anchorOrigin:{vertical:"bottom",horizontal:"right"},transformOrigin:{vertical:"top",horizontal:"right"},children:y&&e.jsxs(Br,{onClick:()=>{nr(w),xt()},children:[e.jsx(nt,{icon:Mr,className:"me-2"}),"Add Payment"]})})]})]},V)})})]})})},cr=()=>Ee?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(it,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(at,{children:e.jsxs(te,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Payment Mode"}),e.jsx(D,{scope:"col",children:"Amount"}),e.jsx(D,{scope:"col",children:"Transaction Reference"}),e.jsx(D,{scope:"col",children:"Date"}),e.jsx(D,{scope:"col",children:"Bank Receipts"}),e.jsx(D,{scope:"col",children:"Status"}),ze&&e.jsx(D,{scope:"col",children:"Action"})]})}),e.jsx(ct,{children:Zt.length===0?e.jsx(te,{children:e.jsx(E,{colSpan:ze?"11":"10",style:{color:"red",textAlign:"center"},children:b?"No matching pending payments found":"No pending payments available"})}):Zt.map((n,y)=>{const k=n.bookingDetails?._id||n.booking,F=[...(v[k]||[]).filter(h=>h.paymentMode&&h.paymentMode.toUpperCase()==="BANK")].sort((h,O)=>{const H=new Date(h.receiptDate||h.createdAt||0),J=new Date(O.receiptDate||O.createdAt||0);return H-J});return e.jsxs(te,{children:[e.jsx(E,{children:y+1}),e.jsx(E,{children:n.bookingDetails?.bookingNumber||n.booking||""}),e.jsx(E,{children:n.bookingDetails?.customerDetails?.name||""}),e.jsx(E,{children:n.paymentMode||""}),e.jsx(E,{children:n.amount||""}),e.jsx(E,{children:n.transactionReference||""}),e.jsx(E,{children:n.updatedAt?new Date(n.updatedAt).toLocaleDateString("en-GB"):" "}),e.jsx(E,{children:F.length>0?e.jsxs(rn,{children:[e.jsxs(on,{size:"sm",color:"info",variant:"outline",children:[F.length," Bank Receipt",F.length>1?"s":""]}),e.jsx(sn,{children:F.map((h,O)=>e.jsx(an,{onClick:()=>Ct(h.id,k,O),disabled:!ht,children:e.jsxs("div",{className:"d-flex align-items-center",children:[e.jsx(nt,{icon:ln,className:"me-2"}),e.jsxs("div",{children:[e.jsx("div",{children:e.jsxs("strong",{children:["Bank Receipt #",O+1]})}),e.jsxs("small",{children:[h.display?.amount||`₹${h.amount}`," -",h.display?.date||(h.receiptDate?new Date(h.receiptDate).toLocaleDateString("en-GB"):"N/A")]})]})]})},h.id))})]}):e.jsx("span",{className:"text-muted",children:"No bank receipts"})}),e.jsx(E,{children:e.jsx(Ar,{color:n.approvalStatus==="Pending"?"danger":"success",shape:"rounded-pill",children:n.approvalStatus==="Pending"?"PENDING":"VERIFIED"})}),ze&&e.jsx(E,{children:n.approvalStatus==="Pending"?e.jsxs(Ie,{size:"sm",className:"action-btn",onClick:()=>rr(n),children:[e.jsx(nt,{icon:Lr,className:"me-1"}),"Verify"]}):e.jsx("span",{className:"text-muted",children:"Verified"})})]},y)})})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Payment Verification tab."})}),lr=()=>Le?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(it,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(at,{children:e.jsxs(te,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"})]})}),e.jsx(ct,{children:Wt.length===0?e.jsx(te,{children:e.jsx(E,{colSpan:"10",style:{color:"red",textAlign:"center"},children:b?"No matching complete payments found":"No complete payments available"})}):Wt.map((n,y)=>e.jsxs(te,{children:[e.jsx(E,{children:y+1}),e.jsx(E,{children:n.bookingNumber||""}),e.jsx(E,{children:n.model?.model_name||"N/A"}),e.jsx(E,{children:n.createdAt?new Date(n.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(E,{children:n.customerDetails?.name||"N/A"}),e.jsx(E,{children:n.customerDetails?.mobile1||"N/A"}),e.jsx(E,{children:n.chassisAllocationStatus==="ALLOCATED"&&n.status==="ALLOCATED"&&n.chassisNumber||""}),e.jsx(E,{children:Math.round(n.discountedAmount)||"0"}),e.jsx(E,{children:Math.round(n.receivedAmount)||"0"}),e.jsx(E,{style:{color:"green"},children:Math.round(n.balanceAmount)||"0"})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Complete Payment tab."})}),dr=()=>ke?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(it,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(at,{children:e.jsxs(te,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"})]})}),e.jsx(ct,{children:Xt.length===0?e.jsx(te,{children:e.jsx(E,{colSpan:"10",style:{color:"red",textAlign:"center"},children:b?"No matching pending payments found":"No pending payments available"})}):Xt.map((n,y)=>e.jsxs(te,{children:[e.jsx(E,{children:y+1}),e.jsx(E,{children:n.bookingNumber||""}),e.jsx(E,{children:n.model?.model_name||"N/A"}),e.jsx(E,{children:n.createdAt?new Date(n.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(E,{children:n.customerDetails?.name||"N/A"}),e.jsx(E,{children:n.customerDetails?.mobile1||"N/A"}),e.jsx(E,{children:n.chassisAllocationStatus==="ALLOCATED"&&n.status==="ALLOCATED"&&n.chassisNumber||""}),e.jsx(E,{children:Math.round(n.discountedAmount)||"0"}),e.jsx(E,{children:Math.round(n.receivedAmount)||"0"}),e.jsx(E,{style:{color:"red"},children:Math.round(n.balanceAmount)||"0"})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Pending List tab."})}),ur=()=>Te?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(it,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(at,{children:e.jsxs(te,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Payment Mode"}),e.jsx(D,{scope:"col",children:"Amount"}),e.jsx(D,{scope:"col",children:"Transaction Reference"}),e.jsx(D,{scope:"col",children:"Date"}),e.jsx(D,{scope:"col",children:"Verified By"})]})}),e.jsx(ct,{children:en.length===0?e.jsx(te,{children:e.jsx(E,{colSpan:"8",style:{color:"red",textAlign:"center"},children:b?"No matching verified payments found":"No verified payments available"})}):en.map((n,y)=>e.jsxs(te,{children:[e.jsx(E,{children:y+1}),e.jsx(E,{children:n.bookingDetails?.bookingNumber||""}),e.jsx(E,{children:n.bookingDetails?.customerDetails?.name||""}),e.jsx(E,{children:n.paymentMode}),e.jsx(E,{children:n.amount}),e.jsx(E,{children:n.transactionReference}),e.jsx(E,{children:n.updatedAt?new Date(n.updatedAt).toLocaleDateString("en-GB"):" "}),e.jsx(E,{children:n.receivedByDetails?.name||""})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Verified List tab."})});return ae?ye?j?e.jsx("div",{className:"d-flex justify-content-center align-items-center",style:{height:"50vh"},children:e.jsx(tn,{color:"primary"})}):U?e.jsx("div",{className:"alert alert-danger",role:"alert",children:U}):e.jsxs("div",{children:[e.jsx("div",{className:"title",children:"Receipt Management"}),m&&e.jsx(xe,{color:"success",className:"mb-3",children:m}),e.jsx(wr,{className:"table-container mt-4",children:e.jsx(Er,{children:ye?e.jsxs(e.Fragment,{children:[de&&e.jsx("div",{className:"d-flex mb-3",children:e.jsxs(Ie,{size:"sm",className:"action-btn",onClick:or,title:"Export Excel",children:[e.jsx(nn,{icon:vr,className:"me-1"}),"Export Excel"]})}),e.jsxs(Tr,{variant:"tabs",className:"mb-3 border-bottom",children:[we&&e.jsx(rt,{children:e.jsxs(ot,{active:s===0,onClick:()=>$e(0),style:{cursor:"pointer",borderTop:s===0?"4px solid #2759a2":"3px solid transparent",color:"black",borderBottom:"none"},children:["Customer",!qe&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Ee&&e.jsx(rt,{children:e.jsxs(ot,{active:s===1,onClick:()=>$e(1),style:{cursor:"pointer",borderTop:s===1?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Payment Verification",!ze&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Le&&e.jsx(rt,{children:e.jsxs(ot,{active:s===2,onClick:()=>$e(2),style:{cursor:"pointer",borderTop:s===2?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Complete Payment",!Yn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),ke&&e.jsx(rt,{children:e.jsxs(ot,{active:s===3,onClick:()=>$e(3),style:{cursor:"pointer",borderTop:s===3?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Pending List",!Kn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Te&&e.jsx(rt,{children:e.jsxs(ot,{active:s===4,onClick:()=>$e(4),style:{cursor:"pointer",borderTop:s===4?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Verified List",!Jn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})})]}),e.jsxs("div",{className:"d-flex justify-content-between mb-3",children:[e.jsx("div",{}),e.jsxs("div",{className:"d-flex",children:[e.jsx(Rr,{className:"mt-1 m-1",children:"Search:"}),e.jsx(fe,{type:"text",style:{maxWidth:"350px",height:"30px",borderRadius:"0"},className:"d-inline-block square-search",value:b,onChange:n=>f(n.target.value),disabled:!ye})]})]}),e.jsxs(Sr,{children:[we&&e.jsx(st,{visible:s===0,children:ar()}),Ee&&e.jsx(st,{visible:s===1,children:cr()}),Le&&e.jsx(st,{visible:s===2,children:lr()}),ke&&e.jsx(st,{visible:s===3,children:dr()}),Te&&e.jsx(st,{visible:s===4,children:ur()})]})]}):e.jsx(xe,{color:"warning",className:"text-center",children:"You don't have permission to view any tabs in Receipts."})})}),e.jsx(kr,{show:a,onClose:()=>o(!1),bookingData:r,canCreateReceipts:qe,cashLocations:C}),e.jsxs(On,{alignment:"center",visible:T,onClose:bt,children:[e.jsx(_n,{children:e.jsxs(Un,{children:[e.jsx(nn,{icon:xr,className:"me-2"}),"Select Date Range for Receipts Export"]})}),e.jsxs(Vn,{children:[Ve&&e.jsx(xe,{color:"warning",className:"mb-3",children:Ve}),e.jsxs(jr,{dateAdapter:Ir,adapterLocale:Pr,children:[e.jsx("div",{className:"mb-3",children:e.jsx(cn,{label:"Start Date",value:I,onChange:n=>{Y(n),$("")},renderInput:n=>e.jsx(yt,{...n,fullWidth:!0,size:"small"}),inputFormat:"dd/MM/yyyy",mask:"__/__/____",views:["day","month","year"],disabled:!de})}),e.jsx("div",{className:"mb-3",children:e.jsx(cn,{label:"End Date",value:K,onChange:n=>{dt(n),$("")},renderInput:n=>e.jsx(yt,{...n,fullWidth:!0,size:"small"}),inputFormat:"dd/MM/yyyy",mask:"__/__/____",minDate:I,views:["day","month","year"],disabled:!de})})]}),e.jsxs(yt,{select:!0,value:Ce,onChange:n=>{ut(n.target.value),$("")},fullWidth:!0,size:"small",SelectProps:{native:!0},disabled:!de,children:[e.jsx("option",{value:"",children:"-- Select Branch --"}),le&&e.jsx("option",{value:"all",children:"All Branch"}),mt.map(n=>e.jsx("option",{value:n._id,children:n.name},n._id))]})]}),e.jsxs(Hn,{children:[e.jsx(Ie,{color:"secondary",onClick:bt,children:"Cancel"}),e.jsx(Ie,{className:"submit-button",onClick:sr,disabled:!I||!K||!Ce||!de||Me,children:Me?e.jsxs(e.Fragment,{children:[e.jsx(tn,{size:"sm",className:"me-2"}),"Exporting..."]}):"Export"})]})]})]}):e.jsx("div",{className:"alert alert-danger m-3",role:"alert",children:"You do not have permission to view any tabs in Receipts."}):e.jsx("div",{className:"alert alert-danger m-3",role:"alert",children:"You do not have permission to view Receipts."})}export{Wo as default};
