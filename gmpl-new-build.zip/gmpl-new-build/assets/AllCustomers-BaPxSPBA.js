import{r as v,l as J,v as w,m as $,j as e,C as K,z as Q}from"./index-Cfk6U4ai.js";/* empty css              */import"./index-ChWfGIeU.js";import"./jspdf.plugin.autotable-CcBflfI0.js";import{u as Z,g as tt}from"./tableFilters-D5Nvh8tG.js";import{u as et}from"./pagination-BViOQK4S.js";import{t as st}from"./logo-V-f8m5nN.js";import{d as T,e as rt,f as at,g as it,P as u,M as b}from"./DefaultLayout-BYbqrtWi.js";import{C as ot}from"./CAlert-Ci2RaY4b.js";import{C as nt,a as dt}from"./CCardBody-Bp4Ke_pg.js";import{C as lt}from"./CCardHeader-CWonxzxG.js";import{a as k}from"./index.esm-CJ5kKkrQ.js";import{C as ct}from"./CFormControlWrapper-BVMFmCcZ.js";import{C as mt}from"./CFormInput-C3iMIJ3z.js";import{C as ht,a as gt,b as j,c as l,d as pt,e as d}from"./CTable-8ufbGJ0H.js";import"./slicedToArray-Dby63wcm.js";import"./createSvgIcon-Cfwtdy2A.js";import"./clsx-B-dksMZM.js";import"./DefaultPropsProvider-D7dpE5xT.js";import"./extends-CF3RwP-h.js";import"./emotion-element-f0de968e.browser.esm-Dj81gQ1A.js";import"./CNavItem-BLD6OWrT.js";const Pt=()=>{const[R,A]=v.useState(!0),[D,E]=v.useState(null),[I,M]=v.useState(""),{setData:B,filteredData:O,setFilteredData:U,handleFilter:P}=Z([]),{currentRecords:y}=et(O),{permissions:h}=J(),x=T(h,b.CUSTOMERS,u.CUSTOMERS.ALL_CUSTOMERS),L=rt(h,b.CUSTOMERS,u.CUSTOMERS.ALL_CUSTOMERS);at(h,b.CUSTOMERS,u.CUSTOMERS.ALL_CUSTOMERS),it(h,b.CUSTOMERS,u.CUSTOMERS.ALL_CUSTOMERS);const g=T(h,b.CUSTOMERS,u.CUSTOMERS.ALL_CUSTOMERS);v.useEffect(()=>{if(!x){w("You do not have permission to view Customers");return}G()},[x]);const G=async()=>{try{A(!0);const s=await $.get("/customers");B(s.data.data.customers),U(s.data.data.customers)}catch(s){const c=w(s);c&&E(c)}finally{A(!1)}},_=async s=>{if(!g){w("You do not have permission to view customer ledger");return}try{const a=(await $.get(`/ledger/customer/${s._id}`)).data.data,V=`${Q.baseURL}/ledger.html?customerId=${s._id}`,F=a.bookingWiseSummary.map(t=>{const n=t.chassisNumber&&t.chassisNumber.trim()!=="",i=t.ledgerEntries.filter(o=>o.approvalStatus==="Approved"),r=i.find(o=>o.description&&o.description.includes("Initial booking creation")),m=r?`
          <tr>
            <td>${new Date(r.date).toLocaleDateString("en-GB")}</td>
            <td>Booking: ${t.vehicleModel||"Unknown Model"}</td>
            <td>${t.bookingNumber}</td>
            <td class="text-right">-</td>
            <td class="text-right">${n?r.debit.toLocaleString("en-IN"):"-"}</td>
            <td class="text-right">${r.balance.toLocaleString("en-IN")}</td>
          </tr>
        `:"",N=i.filter(o=>o.type==="CREDIT"&&o.approvalStatus==="Approved").map(o=>`
            <tr>
              <td>${new Date(o.date).toLocaleDateString("en-GB")}</td>
              <td>${o.description}</td>
              <td>${t.bookingNumber}</td>
              <td class="text-right">${o.credit.toLocaleString("en-IN")}</td>
              <td class="text-right">-</td>
              <td class="text-right">${o.balance.toLocaleString("en-IN")}</td>
            </tr>
          `).join("");return m+N}).join(""),ut=a.transactions.filter(t=>t.approvalStatus==="Approved"),Y=a.transactions.filter(t=>!t.type.includes("EXCHANGE_CREDIT")&&!t.type.includes("ACCESSORY_BILLING")&&!t.type.includes("BOOKING_PAYMENT")).map(t=>{const n=t.netAmount||t.amount,i=t.booking?.bookingNumber||"-",r=t.receiptDate||t.createdAt,m=t.isDebit===!0,p=a.bookingWiseSummary.find(o=>o.bookingNumber===i),N=p?.chassisNumber&&p.chassisNumber.trim()!=="";return`
      <tr>
        <td>${new Date(r).toLocaleDateString("en-GB")}</td>
        <td>${t.remark||""}</td>
        <td>${i}</td>
        <td class="text-right">${m?"-":n.toLocaleString("en-IN")}</td>
        <td class="text-right">${m&&N?n.toLocaleString("en-IN"):"-"}</td>
        <td class="text-right"></td>
      </tr>
    `}).join(""),H=a.transactions.filter(t=>t.type.includes("ACCESSORY_BILLING")&&t.approvalStatus==="Approved").map(t=>{const n=t.netAmount||t.amount,i=t.booking?.bookingNumber||"-",r=a.bookingWiseSummary.find(p=>p.bookingNumber===i),m=r?.chassisNumber&&r.chassisNumber.trim()!=="";return`
          <tr>
            <td>${new Date(t.receiptDate||t.createdAt).toLocaleDateString("en-GB")}</td>
            <td>${t.type}: ${t.remark||""}</td>
            <td>${i}</td>
            <td class="text-right">-</td>
            <td class="text-right">${m?n.toLocaleString("en-IN"):"-"}</td>
            <td class="text-right"></td>
          </tr>
        `}).join(""),q=a.transactions.filter(t=>t.type.includes("EXCHANGE_CREDIT")&&t.approvalStatus==="Approved").map(t=>{const n=t.netAmount||t.amount,i=t.booking?.bookingNumber||"-";return`
          <tr>
            <td>${new Date(t.receiptDate||t.createdAt).toLocaleDateString("en-GB")}</td>
            <td>${t.type}: ${t.remark||""}</td>
            <td>${i}</td>
            <td class="text-right">${n.toLocaleString("en-IN")}</td>
            <td class="text-right">-</td>
            <td class="text-right"></td>
          </tr>
        `}).join("");let f=0,S=0,C=0;a.bookingWiseSummary.forEach(t=>{t.chassisNumber&&t.chassisNumber.trim()!==""&&t.ledgerEntries.filter(r=>r.approvalStatus==="Approved").forEach(r=>{r.type==="DEBIT"&&r.approvalStatus==="Approved"&&(f+=r.debit||0)})});const W=a.transactions.filter(t=>t.isDebit===!0&&t.approvalStatus==="Approved"),X=a.transactions.filter(t=>t.isDebit===!1&&t.approvalStatus==="Approved");W.forEach(t=>{const n=t.booking?.bookingNumber||"-",i=a.bookingWiseSummary.find(m=>m.bookingNumber===n);i?.chassisNumber&&i.chassisNumber.trim()!==""&&(f+=t.netAmount||t.amount||0)}),X.forEach(t=>{S+=t.netAmount||t.amount||0}),C=S-f,window.open("","_blank").document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Customer Ledger - Booking Summary</title>
          <style>
            @page {
              size: A4;
              margin: 15mm 10mm;
            }
            body {
              font-family: Arial;
              width: 100%;
              margin: 0;
              padding: 0;
              font-size: 14px;
              line-height: 1.3;
              font-family: Courier New;
            }
            .container {
              width: 190mm;
              margin: 0 auto;
              padding: 5mm;
            }
            .header-container {
              display: flex;
              justify-content:space-between;
              margin-bottom: 3mm;
            }
            .header-text{
              font-size:20px;
              font-weight:bold;
            }
            .logo {
              width: 30mm;
              height: auto;
              margin-right: 5mm;
            }
            .header {
              text-align: left;
            }
            .divider {
              border-top: 2px solid #AAAAAA;
              margin: 3mm 0;
            }
            .header h2 {
              margin: 2mm 0;
              font-size: 12pt;
              font-weight: bold;
            }
            .header div {
              font-size: 14px;
            }
            .customer-info {
              display: grid;
              grid-template-columns: repeat(2, 1fr);
              gap: 2mm;
              margin-bottom: 5mm;
              font-size: 14px;
            }
            .customer-info div {
              display: flex;
            }
            .customer-info strong {
              min-width: 30mm;
              display: inline-block;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 5mm;
              font-size: 14px;
              page-break-inside: avoid;
            }
            th, td {
              border: 1px solid #000;
              padding: 2mm;
              text-align: left;
            }
            th {
              background-color: #f0f0f0;
              font-weight: bold;
            }
            .footer {
              margin-top: 10mm;
              display: flex;
              justify-content: space-between;
              align-items: flex-end;
              font-size: 14px;
            }
            .footer-left {
              text-align: left;
            }
            .footer-right {
              text-align: right;
            }
            .qr-code {
              width: 35mm;
              height: 35mm;
            }
            .text-right {
              text-align: right;
            }
            .text-left {
              text-align: left;
            }
            .text-center {
              text-align: center;
            }
            @media print {
              body {
                width: 190mm;
                height: 277mm;
              }
              .no-print {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header-container">
              <img src="${st}" class="logo" alt="TVS Logo">
              <div class="header-text"> GANDHI TVS</div>
            </div>
            <div class="header">
              <div>
                Authorised Main Dealer: TVS Motor Company Ltd.<br>
                Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
                Upnagar, Nashik Road, Nashik - 422101<br>
                Phone: 7498903672
              </div>
            </div>
            <div class="divider"></div>
            <div class="customer-info">
              <div><strong>Customer ID:</strong> ${a.customerDetails?.custId||""}</div>
              <div><strong>Customer Name:</strong> ${a.customerDetails?.customerName||""}</div>
              <div><strong>Ledger Date:</strong> ${new Date().toLocaleDateString("en-GB")}</div>
              <div><strong>Aadhar No:</strong> ${a.customerDetails?.customerAadhaar||""}</div>
              <div><strong>Pan No:</strong> ${a.customerDetails?.customerPan||""}</div>
              <div><strong>Current Balance:</strong> ₹${C.toLocaleString("en-IN")}</div>
            </div>

            <table>
              <thead>
                <tr>
                  <th width="15%">Date</th>
                  <th width="25%">Description</th>
                  <th width="20%">Booking No</th>
                  <th width="10%" class="text-right">Credit (₹)</th>
                  <th width="10%" class="text-right">Debit (₹)</th>
                  <th width="20%" class="text-right">Balance (₹)</th>
                </tr>
              </thead>
              <tbody>
                ${F}
                ${H}
                ${q}
                ${Y}
                <tr>
                  <td colspan="2" class="text-left"><strong>Total</strong></td>
                  <td class="text-center"><strong>-</strong></td>
                  <td class="text-right"><strong>${S.toLocaleString("en-IN")}</strong></td>
                  <td class="text-right"><strong>${f.toLocaleString("en-IN")}</strong></td>
                  <td class="text-right"><strong>${C.toLocaleString("en-IN")}</strong></td>
                </tr>
              </tbody>
            </table>

            <div class="footer">
              <div class="footer-left">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(V)}"
                     class="qr-code"
                     alt="QR Code" />
              </div>
              <div class="footer-right">
                <p>For, Gandhi TVS</p>
                <p>Authorised Signatory</p>
              </div>
            </div>
          </div>

          <script>
            window.onload = function() {
              setTimeout(() => {
                window.print();
              }, 300);
            };
          <\/script>
        </body>
      </html>
    `)}catch(c){console.error("Error fetching ledger:",c),E("Failed to load ledger. Please try again.")}},z=s=>{M(s),P(s,tt("allCustomers"))};return x?R?e.jsx("div",{className:"d-flex justify-content-center align-items-center",style:{height:"50vh"},children:e.jsx(K,{color:"primary"})}):e.jsxs("div",{children:[e.jsx("div",{className:"title",children:"Customer Ledger"}),D&&e.jsx(ot,{color:"danger",className:"mb-3",children:D}),e.jsxs(nt,{className:"table-container mt-4",children:[e.jsx(lt,{className:"card-header d-flex justify-content-between align-items-center",children:e.jsx("div",{children:L&&e.jsx(k,{size:"sm",className:"action-btn me-1",disabled:!L,children:"New Customer"})})}),e.jsxs(dt,{children:[e.jsxs("div",{className:"d-flex justify-content-between mb-3",children:[e.jsx("div",{}),e.jsxs("div",{className:"d-flex",children:[e.jsx(ct,{className:"mt-1 m-1",children:"Search:"}),e.jsx(mt,{type:"text",className:"d-inline-block square-search",value:I,onChange:s=>z(s.target.value),disabled:!x})]})]}),e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(ht,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(gt,{children:e.jsxs(j,{children:[e.jsx(l,{children:"Sr.no"}),e.jsx(l,{children:"Customer ID"}),e.jsx(l,{children:"Customer Name"}),e.jsx(l,{children:"Address"}),e.jsx(l,{children:"Mobile1"}),e.jsx(l,{children:"Mobile2"}),e.jsx(l,{children:"Date"}),e.jsx(l,{children:"Aadhar Number"}),e.jsx(l,{children:"PAN Number"}),g&&e.jsx(l,{children:"Action"})]})}),e.jsx(pt,{children:y.length===0?e.jsx(j,{children:e.jsx(d,{colSpan:g?"10":"9",className:"text-center",children:"No ledger details available"})}):y.map((s,c)=>e.jsxs(j,{children:[e.jsx(d,{children:c+1}),e.jsx(d,{children:s.custId||""}),e.jsx(d,{children:s.name||""}),e.jsx(d,{children:s.address||""}),e.jsx(d,{children:s.mobile1||""}),e.jsx(d,{children:s.mobile2||""}),e.jsx(d,{children:s.createdAt?new Date(s.createdAt).toLocaleDateString("en-GB"):""}),e.jsx(d,{children:s.aadhaar||""}),e.jsx(d,{children:s.pan||""}),g&&e.jsx(d,{children:e.jsx(k,{size:"sm",className:"option-button btn-sm",onClick:()=>_(s),disabled:!g,children:"View Ledger"})})]},s._id||c))})]})})]})]})]}):e.jsx("div",{className:"alert alert-danger m-3",role:"alert",children:"You do not have permission to view Customers."})};export{Pt as default};
