import{r as _,g as gr,j as e,m as te,n as fr,l as pr,v as ie,C as nn,S as Ie,F as vr}from"./index-Dy5Jl7PX.js";import{F as rn}from"./index-CXzLQAWB.js";import{f as xr,b as br}from"./index-C3Vny5Su.js";import"./jspdf.plugin.autotable-e5rBIK9u.js";import{g as Cr}from"./tableFilters-BPtEQKFR.js";/* empty css                *//* empty css              *//* empty css                *//* empty css             */import{r as yr,h as Q,T as se,A as W,P as X,M as Z,C as on,a as sn,b as an,c as cn,j as Ar,i as Nr}from"./DefaultLayout-DzqDWlRw.js";import{C as _n,a as Un,b as Vn,c as Hn,d as qn}from"./CModalTitle-CFQg2W2S.js";import{C as xe}from"./CAlert-CEiTk6A1.js";import{C as nt,a as ne}from"./CRow-Dt6X1qd7.js";import{C as fe}from"./CFormInput-FclFwJKl.js";import{C as wr}from"./CForm-k3XVY-80.js";import{C as ft}from"./CFormSelect-BsD-qn0_.js";import{a as De,c as rt}from"./index.esm-MzIJoK_q.js";import{C as Er,a as Tr}from"./CCardBody-BRk8EbmY.js";import{C as Rr}from"./CNav-BQVqCffA.js";import{b as ot,a as it}from"./CNavItem-BsP9wbhN.js";import{C as Sr}from"./CFormControlWrapper-B_dY4m7j.js";import{C as jr,a as st}from"./CTabPane-DXSFEVNi.js";import{L as Pr,e as Ir,A as Dr}from"./en-IN-C9km7eTZ.js";import{D as ln}from"./DatePicker-VTFS1zh7.js";import{T as Nt}from"./TextField-B-e9xMLq.js";import{C as at,a as ct,b as ee,c as D,d as lt,e as R}from"./CTable-DNNsc05t.js";import{c as dn}from"./cil-print-CPAcfqxC.js";import{M as Br}from"./Menu-CRfCMUZh.js";import{M as Mr}from"./MenuItem-DxX0e_93.js";import{c as Lr}from"./cil-plus-D8mtC-W5.js";import{c as kr}from"./cil-check-circle-BlU9eaow.js";import"./slicedToArray-Dby63wcm.js";import"./extends-CF3RwP-h.js";import"./setPrototypeOf-C3V6guyq.js";import"./DefaultPropsProvider-De97v9EX.js";import"./emotion-element-f0de968e.browser.esm-D9wPbdvo.js";import"./clsx-B-dksMZM.js";import"./isWithinInterval-DaYQ2mcw.js";import"./format-BZUhodlP.js";import"./TransitionGroup-CF5NJ6zg.js";import"./emotion-react.browser.esm-DJcoyEw1.js";import"./Transition-D42OabZ4.js";import"./createSvgIcon-DWmuqRNn.js";const Fr=({show:i,onClose:a,bookingData:c,canCreateReceipts:r,cashLocations:n,onPaymentSuccess:o})=>{const[s,d]=_.useState({bookingId:c?._id||"",totalAmount:c?.discountedAmount||0,balanceAmount:c?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:c?.payment?.gcAmount||0,transactionReference:"",amountToBeCredited:0}),[l,u]=_.useState(n||[]),[f,I]=_.useState([]),[x,v]=_.useState([]),[A,M]=_.useState(!1),[V,P]=_.useState(null),[k,B]=_.useState(null);gr();const S=g=>{const{name:p,value:h}=g.target;d(b=>{const C={...b,[p]:h};if(p==="amount"){const w=parseFloat(h)||0,E=parseFloat(b.gcAmount)||0;C.amountToBeCredited=w-E}return C})},H=async g=>{if(g.preventDefault(),!r){P("You do not have permission to create receipts");return}M(!0),P(null),B(null);try{let p={bookingId:s.bookingId,paymentMode:s.modeOfPayment,amount:parseFloat(parseFloat(s.amount).toFixed(2)),remark:s.remark,transactionReference:s.transactionReference};switch(s.modeOfPayment){case"Cash":p.cashLocation=s.cashLocation;break;case"Bank":p.bank=s.bank,p.subPaymentMode=s.subPaymentMode;break;case"Finance Disbursement":p.financer=c?.payment?.financer?._id||c?.payment?.financer,p.gcAmount=parseFloat(parseFloat(s.gcAmount).toFixed(2)),p.amountToBeCredited=parseFloat(parseFloat(s.amountToBeCredited).toFixed(2));break;case"Exchange":case"Pay Order":p.bank=s.bank;break;default:break}const h=await te.post("/ledger/receipt",p);console.log("Payment response:",h.data);let b=h.data.data?.receipt||h.data.data?.ledger||h.data.data;if(!b)throw new Error("No receipt data returned from server");const C={_id:b._id,id:b.id||b._id,receiptNumber:b.receiptNumber,amount:b.amount,receiptDate:b.receiptDate||b.createdAt,paymentMode:b.paymentMode,transactionReference:b.transactionReference,display:{amount:b.display?.amount||`₹${b.amount}`,date:b.display?.date||(b.receiptDate?new Date(b.receiptDate).toLocaleDateString("en-GB"):new Date().toLocaleDateString("en-GB"))}},w=C._id||C.id;if(!w)throw new Error("Receipt ID not returned from server");B("Payment successfully recorded! Opening receipt..."),d({bookingId:c?._id||"",totalAmount:c?.discountedAmount||0,balanceAmount:c?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:c?.payment?.gcAmount||0,transactionReference:"",amountToBeCredited:0}),o&&o(),setTimeout(async()=>{try{const j=(await te.get(`/ledger/booking/${s.bookingId}`)).data.data.allReceipts||[];console.log("All receipts:",j);const re=j.findIndex(Ce=>Ce._id===w||Ce.id===w||Ce.receiptNumber===C.receiptNumber);console.log("New receipt index:",re);const Y=j.length===1;console.log("Total receipts:",j.length,"Is first receipt ever:",Y),typeof window.printReceiptCallback=="function"?(console.log("Calling printReceiptCallback with:",w,s.bookingId,Y?0:1),window.printReceiptCallback(w,s.bookingId,Y?0:1)):console.error("printReceiptCallback is not defined on window!")}catch(E){console.error("Error fetching receipts:",E),typeof window.printReceiptCallback=="function"&&window.printReceiptCallback(w,s.bookingId,1)}},1500),setTimeout(()=>{a()},1e3)}catch(p){console.error("Payment error:",p),P(p.response?.data?.error||p.response?.data?.message||p.message||"Failed to process payment. Please try again.")}finally{M(!1)}};_.useEffect(()=>{const g=async()=>{try{const h=await te.get("/banks");I(h.data.data.banks)}catch(h){console.error("Error fetching bank locations:",h)}},p=async()=>{try{const h=await te.get("/banksubpaymentmodes");v(h.data.data||[])}catch(h){console.error("Error fetching payment sub-modes:",h),v([])}};if(i){n&&n.length>0?u(n):(async()=>{try{const C=await te.get("/cash-locations");u(C.data.data.cashLocations)}catch(C){console.error("Error fetching cash locations:",C)}})(),g(),p();const h=c?.payment?.gcAmount||0;d({bookingId:c?._id||"",totalAmount:c?.discountedAmount||0,balanceAmount:c?.balanceAmount||0,modeOfPayment:"",amount:"",remark:"",cashLocation:"",bank:"",subPaymentMode:"",gcAmount:h,transactionReference:"",amountToBeCredited:0-h}),P(null),B(null)}},[i,c,n]);const N=()=>{switch(s.modeOfPayment){case"Cash":return e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Cash Location"}),e.jsxs(ft,{name:"cashLocation",value:s.cashLocation,onChange:S,required:!0,disabled:A,children:[e.jsx("option",{value:"",children:"Select Cash Location"}),l.map(g=>e.jsx("option",{value:g.id||g._id,children:g.name||g.locationName||"Unnamed Location"},g.id||g._id))]})]});case"Bank":return e.jsxs(e.Fragment,{children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Payment Sub Mode"}),e.jsxs(ft,{name:"subPaymentMode",value:s.subPaymentMode,onChange:S,required:!0,disabled:A,children:[e.jsx("option",{value:"",children:"Select Payment Sub Mode"}),x.map(g=>e.jsx("option",{value:g.id||g._id,children:g.payment_mode||g.name},g.id||g._id))]})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Bank Location"}),e.jsxs(ft,{name:"bank",value:s.bank,onChange:S,required:!0,disabled:A,children:[e.jsx("option",{value:"",children:"Select Bank Location"}),f.map(g=>e.jsx("option",{value:g.id||g._id,children:g.name},g.id||g._id))]})]})]});case"Finance Disbursement":return e.jsxs(e.Fragment,{children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Financer Name"}),e.jsx(fe,{type:"text",value:c?.payment?.financer?.name||"N/A",readOnly:!0,className:"bg-light"})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"GC Amount (₹)"}),e.jsx(fe,{type:"number",name:"gcAmount",value:s.gcAmount?parseFloat(s.gcAmount).toFixed(2):"0.00",readOnly:!0,className:"bg-light"})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label mt-3",children:"Amount Credited To Customer Ledger (₹)"}),e.jsx(fe,{type:"number",name:"amountToBeCredited",value:s.amountToBeCredited?parseFloat(s.amountToBeCredited).toFixed(2):"0.00",readOnly:!0,className:"bg-light"})]})]});default:return null}};return e.jsxs(e.Fragment,{children:[e.jsx(yr,{visible:i,className:"modal-backdrop",style:{backgroundColor:"rgba(0, 0, 0, 0.5)"}}),e.jsxs(_n,{visible:i,onClose:a,size:"lg",alignment:"center",children:[e.jsx(Un,{children:e.jsx(Vn,{children:"Account Receipt"})}),e.jsxs(Hn,{children:[V&&e.jsx(xe,{color:"danger",children:V}),k&&e.jsxs(xe,{color:"success",children:[k,A&&e.jsx("div",{className:"mt-2",children:e.jsx("small",{children:"Processing payment and generating receipt..."})})]}),e.jsxs(nt,{className:"mb-3",children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Customer Name"}),e.jsx(fe,{type:"text",value:c?.customerDetails?.name||"",readOnly:!0,className:"bg-light"})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Chassis Number"}),e.jsx(fe,{type:"text",value:c?.chassisNumber||"",readOnly:!0,className:"bg-light"})]})]}),e.jsxs(nt,{className:"mb-3",children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Total Amount (₹)"}),e.jsx(fe,{type:"number",name:"totalAmount",value:s.totalAmount?parseFloat(s.totalAmount).toFixed(2):"0.00",readOnly:!0,className:"bg-light font-weight-bold"})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Balance Amount (₹)"}),e.jsx(fe,{type:"number",name:"balanceAmount",value:s.balanceAmount?parseFloat(s.balanceAmount).toFixed(2):"0.00",readOnly:!0,className:`bg-light font-weight-bold ${parseFloat(s.balanceAmount)>0?"text-danger":"text-success"}`})]})]}),e.jsxs(wr,{onSubmit:H,children:[e.jsxs(nt,{className:"mb-3",children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Amount (₹)"}),e.jsx(fe,{type:"number",name:"amount",value:s.amount,onChange:S,required:!0,min:"0",step:"0.01",disabled:A})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Mode of Payment"}),e.jsxs(ft,{name:"modeOfPayment",value:s.modeOfPayment,onChange:S,required:!0,disabled:A,children:[e.jsx("option",{value:"",children:"--Select--"}),e.jsx("option",{value:"Cash",children:"Cash"}),e.jsx("option",{value:"Bank",children:"Bank"}),e.jsx("option",{value:"Finance Disbursement",children:"Finance Disbursement"}),e.jsx("option",{value:"Exchange",children:"Exchange"}),e.jsx("option",{value:"Pay Order",children:"Pay Order"})]})]})]}),e.jsx(nt,{className:"mb-3",children:N()}),e.jsxs(nt,{className:"mb-3",children:[e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Reference Number"}),e.jsx(fe,{type:"text",name:"transactionReference",value:s.transactionReference,onChange:S,disabled:A})]}),e.jsxs(ne,{md:6,children:[e.jsx("label",{className:"form-label",children:"Remark"}),e.jsx(fe,{type:"text",name:"remark",value:s.remark,onChange:S,placeholder:"Enter any remarks...",disabled:A})]})]})]})]}),e.jsxs(qn,{children:[e.jsx("div",{children:e.jsx(De,{color:"primary",onClick:H,className:"me-2 submit-button",disabled:A||!r,children:A?"Processing...":"Save Payment & Print Receipt"})}),e.jsx(De,{color:"secondary",onClick:a,disabled:A,children:"Close"})]})]})]})},Or=i=>{if(i===0)return"Zero";const a=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"],c=["Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"],r=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"],n=u=>{let f="";return u>=100&&(f+=a[Math.floor(u/100)]+" Hundred",u%=100,u>0&&(f+=" and ")),u>=20?(f+=r[Math.floor(u/10)],u%=10,u>0&&(f+=" "+a[u])):u>=10?f+=c[u-10]:u>0&&(f+=a[u]),f},o=u=>{if(u===0)return"";let f="";const I=Math.floor(u/1e7),x=Math.floor(u%1e7/1e5),v=Math.floor(u%1e5/1e3),A=u%1e3;return I>0&&(f+=n(I)+" Crore",(x>0||v>0||A>0)&&(f+=" ")),x>0&&(f+=n(x)+" Lakh",(v>0||A>0)&&(f+=" ")),v>0&&(f+=n(v)+" Thousand",A>0&&(f+=" ")),A>0&&(f+=n(A)),f},s=Math.floor(i),d=Math.round((i-s)*100);let l="";return s>0?l=o(s)+" Rupees":l="Zero Rupees",d>0&&(s>0&&(l+=" and "),l+=o(d)+" Paise"),l.trim()};var Ve={},wt,un;function _r(){return un||(un=1,wt=function(){return typeof Promise=="function"&&Promise.prototype&&Promise.prototype.then}),wt}var Et={},Ne={},mn;function Be(){if(mn)return Ne;mn=1;let i;const a=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];return Ne.getSymbolSize=function(r){if(!r)throw new Error('"version" cannot be null or undefined');if(r<1||r>40)throw new Error('"version" should be in range from 1 to 40');return r*4+17},Ne.getSymbolTotalCodewords=function(r){return a[r]},Ne.getBCHDigit=function(c){let r=0;for(;c!==0;)r++,c>>>=1;return r},Ne.setToSJISFunction=function(r){if(typeof r!="function")throw new Error('"toSJISFunc" is not a valid function.');i=r},Ne.isKanjiModeEnabled=function(){return typeof i<"u"},Ne.toSJIS=function(r){return i(r)},Ne}var Tt={},hn;function Yt(){return hn||(hn=1,(function(i){i.L={bit:1},i.M={bit:0},i.Q={bit:3},i.H={bit:2};function a(c){if(typeof c!="string")throw new Error("Param is not a string");switch(c.toLowerCase()){case"l":case"low":return i.L;case"m":case"medium":return i.M;case"q":case"quartile":return i.Q;case"h":case"high":return i.H;default:throw new Error("Unknown EC Level: "+c)}}i.isValid=function(r){return r&&typeof r.bit<"u"&&r.bit>=0&&r.bit<4},i.from=function(r,n){if(i.isValid(r))return r;try{return a(r)}catch{return n}}})(Tt)),Tt}var Rt,gn;function Ur(){if(gn)return Rt;gn=1;function i(){this.buffer=[],this.length=0}return i.prototype={get:function(a){const c=Math.floor(a/8);return(this.buffer[c]>>>7-a%8&1)===1},put:function(a,c){for(let r=0;r<c;r++)this.putBit((a>>>c-r-1&1)===1)},getLengthInBits:function(){return this.length},putBit:function(a){const c=Math.floor(this.length/8);this.buffer.length<=c&&this.buffer.push(0),a&&(this.buffer[c]|=128>>>this.length%8),this.length++}},Rt=i,Rt}var St,fn;function Vr(){if(fn)return St;fn=1;function i(a){if(!a||a<1)throw new Error("BitMatrix size must be defined and greater than 0");this.size=a,this.data=new Uint8Array(a*a),this.reservedBit=new Uint8Array(a*a)}return i.prototype.set=function(a,c,r,n){const o=a*this.size+c;this.data[o]=r,n&&(this.reservedBit[o]=!0)},i.prototype.get=function(a,c){return this.data[a*this.size+c]},i.prototype.xor=function(a,c,r){this.data[a*this.size+c]^=r},i.prototype.isReserved=function(a,c){return this.reservedBit[a*this.size+c]},St=i,St}var jt={},pn;function Hr(){return pn||(pn=1,(function(i){const a=Be().getSymbolSize;i.getRowColCoords=function(r){if(r===1)return[];const n=Math.floor(r/7)+2,o=a(r),s=o===145?26:Math.ceil((o-13)/(2*n-2))*2,d=[o-7];for(let l=1;l<n-1;l++)d[l]=d[l-1]-s;return d.push(6),d.reverse()},i.getPositions=function(r){const n=[],o=i.getRowColCoords(r),s=o.length;for(let d=0;d<s;d++)for(let l=0;l<s;l++)d===0&&l===0||d===0&&l===s-1||d===s-1&&l===0||n.push([o[d],o[l]]);return n}})(jt)),jt}var Pt={},vn;function qr(){if(vn)return Pt;vn=1;const i=Be().getSymbolSize,a=7;return Pt.getPositions=function(r){const n=i(r);return[[0,0],[n-a,0],[0,n-a]]},Pt}var It={},xn;function zr(){return xn||(xn=1,(function(i){i.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};const a={N1:3,N2:3,N3:40,N4:10};i.isValid=function(n){return n!=null&&n!==""&&!isNaN(n)&&n>=0&&n<=7},i.from=function(n){return i.isValid(n)?parseInt(n,10):void 0},i.getPenaltyN1=function(n){const o=n.size;let s=0,d=0,l=0,u=null,f=null;for(let I=0;I<o;I++){d=l=0,u=f=null;for(let x=0;x<o;x++){let v=n.get(I,x);v===u?d++:(d>=5&&(s+=a.N1+(d-5)),u=v,d=1),v=n.get(x,I),v===f?l++:(l>=5&&(s+=a.N1+(l-5)),f=v,l=1)}d>=5&&(s+=a.N1+(d-5)),l>=5&&(s+=a.N1+(l-5))}return s},i.getPenaltyN2=function(n){const o=n.size;let s=0;for(let d=0;d<o-1;d++)for(let l=0;l<o-1;l++){const u=n.get(d,l)+n.get(d,l+1)+n.get(d+1,l)+n.get(d+1,l+1);(u===4||u===0)&&s++}return s*a.N2},i.getPenaltyN3=function(n){const o=n.size;let s=0,d=0,l=0;for(let u=0;u<o;u++){d=l=0;for(let f=0;f<o;f++)d=d<<1&2047|n.get(u,f),f>=10&&(d===1488||d===93)&&s++,l=l<<1&2047|n.get(f,u),f>=10&&(l===1488||l===93)&&s++}return s*a.N3},i.getPenaltyN4=function(n){let o=0;const s=n.data.length;for(let l=0;l<s;l++)o+=n.data[l];return Math.abs(Math.ceil(o*100/s/5)-10)*a.N4};function c(r,n,o){switch(r){case i.Patterns.PATTERN000:return(n+o)%2===0;case i.Patterns.PATTERN001:return n%2===0;case i.Patterns.PATTERN010:return o%3===0;case i.Patterns.PATTERN011:return(n+o)%3===0;case i.Patterns.PATTERN100:return(Math.floor(n/2)+Math.floor(o/3))%2===0;case i.Patterns.PATTERN101:return n*o%2+n*o%3===0;case i.Patterns.PATTERN110:return(n*o%2+n*o%3)%2===0;case i.Patterns.PATTERN111:return(n*o%3+(n+o)%2)%2===0;default:throw new Error("bad maskPattern:"+r)}}i.applyMask=function(n,o){const s=o.size;for(let d=0;d<s;d++)for(let l=0;l<s;l++)o.isReserved(l,d)||o.xor(l,d,c(n,l,d))},i.getBestMask=function(n,o){const s=Object.keys(i.Patterns).length;let d=0,l=1/0;for(let u=0;u<s;u++){o(u),i.applyMask(u,n);const f=i.getPenaltyN1(n)+i.getPenaltyN2(n)+i.getPenaltyN3(n)+i.getPenaltyN4(n);i.applyMask(u,n),f<l&&(l=f,d=u)}return d}})(It)),It}var pt={},bn;function zn(){if(bn)return pt;bn=1;const i=Yt(),a=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],c=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];return pt.getBlocksCount=function(n,o){switch(o){case i.L:return a[(n-1)*4+0];case i.M:return a[(n-1)*4+1];case i.Q:return a[(n-1)*4+2];case i.H:return a[(n-1)*4+3];default:return}},pt.getTotalCodewordsCount=function(n,o){switch(o){case i.L:return c[(n-1)*4+0];case i.M:return c[(n-1)*4+1];case i.Q:return c[(n-1)*4+2];case i.H:return c[(n-1)*4+3];default:return}},pt}var Dt={},dt={},Cn;function $r(){if(Cn)return dt;Cn=1;const i=new Uint8Array(512),a=new Uint8Array(256);return(function(){let r=1;for(let n=0;n<255;n++)i[n]=r,a[r]=n,r<<=1,r&256&&(r^=285);for(let n=255;n<512;n++)i[n]=i[n-255]})(),dt.log=function(r){if(r<1)throw new Error("log("+r+")");return a[r]},dt.exp=function(r){return i[r]},dt.mul=function(r,n){return r===0||n===0?0:i[a[r]+a[n]]},dt}var yn;function Gr(){return yn||(yn=1,(function(i){const a=$r();i.mul=function(r,n){const o=new Uint8Array(r.length+n.length-1);for(let s=0;s<r.length;s++)for(let d=0;d<n.length;d++)o[s+d]^=a.mul(r[s],n[d]);return o},i.mod=function(r,n){let o=new Uint8Array(r);for(;o.length-n.length>=0;){const s=o[0];for(let l=0;l<n.length;l++)o[l]^=a.mul(n[l],s);let d=0;for(;d<o.length&&o[d]===0;)d++;o=o.slice(d)}return o},i.generateECPolynomial=function(r){let n=new Uint8Array([1]);for(let o=0;o<r;o++)n=i.mul(n,new Uint8Array([1,a.exp(o)]));return n}})(Dt)),Dt}var Bt,An;function Yr(){if(An)return Bt;An=1;const i=Gr();function a(c){this.genPoly=void 0,this.degree=c,this.degree&&this.initialize(this.degree)}return a.prototype.initialize=function(r){this.degree=r,this.genPoly=i.generateECPolynomial(this.degree)},a.prototype.encode=function(r){if(!this.genPoly)throw new Error("Encoder not initialized");const n=new Uint8Array(r.length+this.degree);n.set(r);const o=i.mod(n,this.genPoly),s=this.degree-o.length;if(s>0){const d=new Uint8Array(this.degree);return d.set(o,s),d}return o},Bt=a,Bt}var Mt={},Lt={},kt={},Nn;function $n(){return Nn||(Nn=1,kt.isValid=function(a){return!isNaN(a)&&a>=1&&a<=40}),kt}var ve={},wn;function Gn(){if(wn)return ve;wn=1;const i="[0-9]+",a="[A-Z $%*+\\-./:]+";let c="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";c=c.replace(/u/g,"\\u");const r="(?:(?![A-Z0-9 $%*+\\-./:]|"+c+`)(?:.|[\r
]))+`;ve.KANJI=new RegExp(c,"g"),ve.BYTE_KANJI=new RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),ve.BYTE=new RegExp(r,"g"),ve.NUMERIC=new RegExp(i,"g"),ve.ALPHANUMERIC=new RegExp(a,"g");const n=new RegExp("^"+c+"$"),o=new RegExp("^"+i+"$"),s=new RegExp("^[A-Z0-9 $%*+\\-./:]+$");return ve.testKanji=function(l){return n.test(l)},ve.testNumeric=function(l){return o.test(l)},ve.testAlphanumeric=function(l){return s.test(l)},ve}var En;function Me(){return En||(En=1,(function(i){const a=$n(),c=Gn();i.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},i.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},i.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},i.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},i.MIXED={bit:-1},i.getCharCountIndicator=function(o,s){if(!o.ccBits)throw new Error("Invalid mode: "+o);if(!a.isValid(s))throw new Error("Invalid version: "+s);return s>=1&&s<10?o.ccBits[0]:s<27?o.ccBits[1]:o.ccBits[2]},i.getBestModeForData=function(o){return c.testNumeric(o)?i.NUMERIC:c.testAlphanumeric(o)?i.ALPHANUMERIC:c.testKanji(o)?i.KANJI:i.BYTE},i.toString=function(o){if(o&&o.id)return o.id;throw new Error("Invalid mode")},i.isValid=function(o){return o&&o.bit&&o.ccBits};function r(n){if(typeof n!="string")throw new Error("Param is not a string");switch(n.toLowerCase()){case"numeric":return i.NUMERIC;case"alphanumeric":return i.ALPHANUMERIC;case"kanji":return i.KANJI;case"byte":return i.BYTE;default:throw new Error("Unknown mode: "+n)}}i.from=function(o,s){if(i.isValid(o))return o;try{return r(o)}catch{return s}}})(Lt)),Lt}var Tn;function Kr(){return Tn||(Tn=1,(function(i){const a=Be(),c=zn(),r=Yt(),n=Me(),o=$n(),s=7973,d=a.getBCHDigit(s);function l(x,v,A){for(let M=1;M<=40;M++)if(v<=i.getCapacity(M,A,x))return M}function u(x,v){return n.getCharCountIndicator(x,v)+4}function f(x,v){let A=0;return x.forEach(function(M){const V=u(M.mode,v);A+=V+M.getBitsLength()}),A}function I(x,v){for(let A=1;A<=40;A++)if(f(x,A)<=i.getCapacity(A,v,n.MIXED))return A}i.from=function(v,A){return o.isValid(v)?parseInt(v,10):A},i.getCapacity=function(v,A,M){if(!o.isValid(v))throw new Error("Invalid QR Code version");typeof M>"u"&&(M=n.BYTE);const V=a.getSymbolTotalCodewords(v),P=c.getTotalCodewordsCount(v,A),k=(V-P)*8;if(M===n.MIXED)return k;const B=k-u(M,v);switch(M){case n.NUMERIC:return Math.floor(B/10*3);case n.ALPHANUMERIC:return Math.floor(B/11*2);case n.KANJI:return Math.floor(B/13);case n.BYTE:default:return Math.floor(B/8)}},i.getBestVersionForData=function(v,A){let M;const V=r.from(A,r.M);if(Array.isArray(v)){if(v.length>1)return I(v,V);if(v.length===0)return 1;M=v[0]}else M=v;return l(M.mode,M.getLength(),V)},i.getEncodedBits=function(v){if(!o.isValid(v)||v<7)throw new Error("Invalid QR Code version");let A=v<<12;for(;a.getBCHDigit(A)-d>=0;)A^=s<<a.getBCHDigit(A)-d;return v<<12|A}})(Mt)),Mt}var Ft={},Rn;function Jr(){if(Rn)return Ft;Rn=1;const i=Be(),a=1335,c=21522,r=i.getBCHDigit(a);return Ft.getEncodedBits=function(o,s){const d=o.bit<<3|s;let l=d<<10;for(;i.getBCHDigit(l)-r>=0;)l^=a<<i.getBCHDigit(l)-r;return(d<<10|l)^c},Ft}var Ot={},_t,Sn;function Qr(){if(Sn)return _t;Sn=1;const i=Me();function a(c){this.mode=i.NUMERIC,this.data=c.toString()}return a.getBitsLength=function(r){return 10*Math.floor(r/3)+(r%3?r%3*3+1:0)},a.prototype.getLength=function(){return this.data.length},a.prototype.getBitsLength=function(){return a.getBitsLength(this.data.length)},a.prototype.write=function(r){let n,o,s;for(n=0;n+3<=this.data.length;n+=3)o=this.data.substr(n,3),s=parseInt(o,10),r.put(s,10);const d=this.data.length-n;d>0&&(o=this.data.substr(n),s=parseInt(o,10),r.put(s,d*3+1))},_t=a,_t}var Ut,jn;function Wr(){if(jn)return Ut;jn=1;const i=Me(),a=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function c(r){this.mode=i.ALPHANUMERIC,this.data=r}return c.getBitsLength=function(n){return 11*Math.floor(n/2)+6*(n%2)},c.prototype.getLength=function(){return this.data.length},c.prototype.getBitsLength=function(){return c.getBitsLength(this.data.length)},c.prototype.write=function(n){let o;for(o=0;o+2<=this.data.length;o+=2){let s=a.indexOf(this.data[o])*45;s+=a.indexOf(this.data[o+1]),n.put(s,11)}this.data.length%2&&n.put(a.indexOf(this.data[o]),6)},Ut=c,Ut}var Vt,Pn;function Xr(){if(Pn)return Vt;Pn=1;const i=Me();function a(c){this.mode=i.BYTE,typeof c=="string"?this.data=new TextEncoder().encode(c):this.data=new Uint8Array(c)}return a.getBitsLength=function(r){return r*8},a.prototype.getLength=function(){return this.data.length},a.prototype.getBitsLength=function(){return a.getBitsLength(this.data.length)},a.prototype.write=function(c){for(let r=0,n=this.data.length;r<n;r++)c.put(this.data[r],8)},Vt=a,Vt}var Ht,In;function Zr(){if(In)return Ht;In=1;const i=Me(),a=Be();function c(r){this.mode=i.KANJI,this.data=r}return c.getBitsLength=function(n){return n*13},c.prototype.getLength=function(){return this.data.length},c.prototype.getBitsLength=function(){return c.getBitsLength(this.data.length)},c.prototype.write=function(r){let n;for(n=0;n<this.data.length;n++){let o=a.toSJIS(this.data[n]);if(o>=33088&&o<=40956)o-=33088;else if(o>=57408&&o<=60351)o-=49472;else throw new Error("Invalid SJIS character: "+this.data[n]+`
Make sure your charset is UTF-8`);o=(o>>>8&255)*192+(o&255),r.put(o,13)}},Ht=c,Ht}var qt={exports:{}},Dn;function eo(){return Dn||(Dn=1,(function(i){var a={single_source_shortest_paths:function(c,r,n){var o={},s={};s[r]=0;var d=a.PriorityQueue.make();d.push(r,0);for(var l,u,f,I,x,v,A,M,V;!d.empty();){l=d.pop(),u=l.value,I=l.cost,x=c[u]||{};for(f in x)x.hasOwnProperty(f)&&(v=x[f],A=I+v,M=s[f],V=typeof s[f]>"u",(V||M>A)&&(s[f]=A,d.push(f,A),o[f]=u))}if(typeof n<"u"&&typeof s[n]>"u"){var P=["Could not find a path from ",r," to ",n,"."].join("");throw new Error(P)}return o},extract_shortest_path_from_predecessor_list:function(c,r){for(var n=[],o=r;o;)n.push(o),c[o],o=c[o];return n.reverse(),n},find_path:function(c,r,n){var o=a.single_source_shortest_paths(c,r,n);return a.extract_shortest_path_from_predecessor_list(o,n)},PriorityQueue:{make:function(c){var r=a.PriorityQueue,n={},o;c=c||{};for(o in r)r.hasOwnProperty(o)&&(n[o]=r[o]);return n.queue=[],n.sorter=c.sorter||r.default_sorter,n},default_sorter:function(c,r){return c.cost-r.cost},push:function(c,r){var n={value:c,cost:r};this.queue.push(n),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};i.exports=a})(qt)),qt.exports}var Bn;function to(){return Bn||(Bn=1,(function(i){const a=Me(),c=Qr(),r=Wr(),n=Xr(),o=Zr(),s=Gn(),d=Be(),l=eo();function u(P){return unescape(encodeURIComponent(P)).length}function f(P,k,B){const S=[];let H;for(;(H=P.exec(B))!==null;)S.push({data:H[0],index:H.index,mode:k,length:H[0].length});return S}function I(P){const k=f(s.NUMERIC,a.NUMERIC,P),B=f(s.ALPHANUMERIC,a.ALPHANUMERIC,P);let S,H;return d.isKanjiModeEnabled()?(S=f(s.BYTE,a.BYTE,P),H=f(s.KANJI,a.KANJI,P)):(S=f(s.BYTE_KANJI,a.BYTE,P),H=[]),k.concat(B,S,H).sort(function(g,p){return g.index-p.index}).map(function(g){return{data:g.data,mode:g.mode,length:g.length}})}function x(P,k){switch(k){case a.NUMERIC:return c.getBitsLength(P);case a.ALPHANUMERIC:return r.getBitsLength(P);case a.KANJI:return o.getBitsLength(P);case a.BYTE:return n.getBitsLength(P)}}function v(P){return P.reduce(function(k,B){const S=k.length-1>=0?k[k.length-1]:null;return S&&S.mode===B.mode?(k[k.length-1].data+=B.data,k):(k.push(B),k)},[])}function A(P){const k=[];for(let B=0;B<P.length;B++){const S=P[B];switch(S.mode){case a.NUMERIC:k.push([S,{data:S.data,mode:a.ALPHANUMERIC,length:S.length},{data:S.data,mode:a.BYTE,length:S.length}]);break;case a.ALPHANUMERIC:k.push([S,{data:S.data,mode:a.BYTE,length:S.length}]);break;case a.KANJI:k.push([S,{data:S.data,mode:a.BYTE,length:u(S.data)}]);break;case a.BYTE:k.push([{data:S.data,mode:a.BYTE,length:u(S.data)}])}}return k}function M(P,k){const B={},S={start:{}};let H=["start"];for(let N=0;N<P.length;N++){const g=P[N],p=[];for(let h=0;h<g.length;h++){const b=g[h],C=""+N+h;p.push(C),B[C]={node:b,lastCount:0},S[C]={};for(let w=0;w<H.length;w++){const E=H[w];B[E]&&B[E].node.mode===b.mode?(S[E][C]=x(B[E].lastCount+b.length,b.mode)-x(B[E].lastCount,b.mode),B[E].lastCount+=b.length):(B[E]&&(B[E].lastCount=b.length),S[E][C]=x(b.length,b.mode)+4+a.getCharCountIndicator(b.mode,k))}}H=p}for(let N=0;N<H.length;N++)S[H[N]].end=0;return{map:S,table:B}}function V(P,k){let B;const S=a.getBestModeForData(P);if(B=a.from(k,S),B!==a.BYTE&&B.bit<S.bit)throw new Error('"'+P+'" cannot be encoded with mode '+a.toString(B)+`.
 Suggested mode is: `+a.toString(S));switch(B===a.KANJI&&!d.isKanjiModeEnabled()&&(B=a.BYTE),B){case a.NUMERIC:return new c(P);case a.ALPHANUMERIC:return new r(P);case a.KANJI:return new o(P);case a.BYTE:return new n(P)}}i.fromArray=function(k){return k.reduce(function(B,S){return typeof S=="string"?B.push(V(S,null)):S.data&&B.push(V(S.data,S.mode)),B},[])},i.fromString=function(k,B){const S=I(k,d.isKanjiModeEnabled()),H=A(S),N=M(H,B),g=l.find_path(N.map,"start","end"),p=[];for(let h=1;h<g.length-1;h++)p.push(N.table[g[h]].node);return i.fromArray(v(p))},i.rawSplit=function(k){return i.fromArray(I(k,d.isKanjiModeEnabled()))}})(Ot)),Ot}var Mn;function no(){if(Mn)return Et;Mn=1;const i=Be(),a=Yt(),c=Ur(),r=Vr(),n=Hr(),o=qr(),s=zr(),d=zn(),l=Yr(),u=Kr(),f=Jr(),I=Me(),x=to();function v(N,g){const p=N.size,h=o.getPositions(g);for(let b=0;b<h.length;b++){const C=h[b][0],w=h[b][1];for(let E=-1;E<=7;E++)if(!(C+E<=-1||p<=C+E))for(let j=-1;j<=7;j++)w+j<=-1||p<=w+j||(E>=0&&E<=6&&(j===0||j===6)||j>=0&&j<=6&&(E===0||E===6)||E>=2&&E<=4&&j>=2&&j<=4?N.set(C+E,w+j,!0,!0):N.set(C+E,w+j,!1,!0))}}function A(N){const g=N.size;for(let p=8;p<g-8;p++){const h=p%2===0;N.set(p,6,h,!0),N.set(6,p,h,!0)}}function M(N,g){const p=n.getPositions(g);for(let h=0;h<p.length;h++){const b=p[h][0],C=p[h][1];for(let w=-2;w<=2;w++)for(let E=-2;E<=2;E++)w===-2||w===2||E===-2||E===2||w===0&&E===0?N.set(b+w,C+E,!0,!0):N.set(b+w,C+E,!1,!0)}}function V(N,g){const p=N.size,h=u.getEncodedBits(g);let b,C,w;for(let E=0;E<18;E++)b=Math.floor(E/3),C=E%3+p-8-3,w=(h>>E&1)===1,N.set(b,C,w,!0),N.set(C,b,w,!0)}function P(N,g,p){const h=N.size,b=f.getEncodedBits(g,p);let C,w;for(C=0;C<15;C++)w=(b>>C&1)===1,C<6?N.set(C,8,w,!0):C<8?N.set(C+1,8,w,!0):N.set(h-15+C,8,w,!0),C<8?N.set(8,h-C-1,w,!0):C<9?N.set(8,15-C-1+1,w,!0):N.set(8,15-C-1,w,!0);N.set(h-8,8,1,!0)}function k(N,g){const p=N.size;let h=-1,b=p-1,C=7,w=0;for(let E=p-1;E>0;E-=2)for(E===6&&E--;;){for(let j=0;j<2;j++)if(!N.isReserved(b,E-j)){let re=!1;w<g.length&&(re=(g[w]>>>C&1)===1),N.set(b,E-j,re),C--,C===-1&&(w++,C=7)}if(b+=h,b<0||p<=b){b-=h,h=-h;break}}}function B(N,g,p){const h=new c;p.forEach(function(j){h.put(j.mode.bit,4),h.put(j.getLength(),I.getCharCountIndicator(j.mode,N)),j.write(h)});const b=i.getSymbolTotalCodewords(N),C=d.getTotalCodewordsCount(N,g),w=(b-C)*8;for(h.getLengthInBits()+4<=w&&h.put(0,4);h.getLengthInBits()%8!==0;)h.putBit(0);const E=(w-h.getLengthInBits())/8;for(let j=0;j<E;j++)h.put(j%2?17:236,8);return S(h,N,g)}function S(N,g,p){const h=i.getSymbolTotalCodewords(g),b=d.getTotalCodewordsCount(g,p),C=h-b,w=d.getBlocksCount(g,p),E=h%w,j=w-E,re=Math.floor(h/w),Y=Math.floor(C/w),Ce=Y+1,ye=re-Y,ut=new l(ye);let Le=0;const we=new Array(w),He=new Array(w);let $=0;const mt=new Uint8Array(N.buffer);for(let ae=0;ae<w;ae++){const de=ae<j?Y:Ce;we[ae]=mt.slice(Le,Le+de),He[ae]=ut.encode(we[ae]),Le+=de,$=Math.max($,de)}const qe=new Uint8Array(h);let G=0,ce,le;for(ce=0;ce<$;ce++)for(le=0;le<w;le++)ce<we[le].length&&(qe[G++]=we[le][ce]);for(ce=0;ce<ye;ce++)for(le=0;le<w;le++)qe[G++]=He[le][ce];return qe}function H(N,g,p,h){let b;if(Array.isArray(N))b=x.fromArray(N);else if(typeof N=="string"){let re=g;if(!re){const Y=x.rawSplit(N);re=u.getBestVersionForData(Y,p)}b=x.fromString(N,re||40)}else throw new Error("Invalid data");const C=u.getBestVersionForData(b,p);if(!C)throw new Error("The amount of data is too big to be stored in a QR Code");if(!g)g=C;else if(g<C)throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+C+`.
`);const w=B(g,p,b),E=i.getSymbolSize(g),j=new r(E);return v(j,g),A(j),M(j,g),P(j,p,0),g>=7&&V(j,g),k(j,w),isNaN(h)&&(h=s.getBestMask(j,P.bind(null,j,p))),s.applyMask(h,j),P(j,p,h),{modules:j,version:g,errorCorrectionLevel:p,maskPattern:h,segments:b}}return Et.create=function(g,p){if(typeof g>"u"||g==="")throw new Error("No input text");let h=a.M,b,C;return typeof p<"u"&&(h=a.from(p.errorCorrectionLevel,a.M),b=u.from(p.version),C=s.from(p.maskPattern),p.toSJISFunc&&i.setToSJISFunction(p.toSJISFunc)),H(g,b,h,C)},Et}var zt={},$t={},Ln;function Yn(){return Ln||(Ln=1,(function(i){function a(c){if(typeof c=="number"&&(c=c.toString()),typeof c!="string")throw new Error("Color should be defined as hex string");let r=c.slice().replace("#","").split("");if(r.length<3||r.length===5||r.length>8)throw new Error("Invalid hex color: "+c);(r.length===3||r.length===4)&&(r=Array.prototype.concat.apply([],r.map(function(o){return[o,o]}))),r.length===6&&r.push("F","F");const n=parseInt(r.join(""),16);return{r:n>>24&255,g:n>>16&255,b:n>>8&255,a:n&255,hex:"#"+r.slice(0,6).join("")}}i.getOptions=function(r){r||(r={}),r.color||(r.color={});const n=typeof r.margin>"u"||r.margin===null||r.margin<0?4:r.margin,o=r.width&&r.width>=21?r.width:void 0,s=r.scale||4;return{width:o,scale:o?4:s,margin:n,color:{dark:a(r.color.dark||"#000000ff"),light:a(r.color.light||"#ffffffff")},type:r.type,rendererOpts:r.rendererOpts||{}}},i.getScale=function(r,n){return n.width&&n.width>=r+n.margin*2?n.width/(r+n.margin*2):n.scale},i.getImageWidth=function(r,n){const o=i.getScale(r,n);return Math.floor((r+n.margin*2)*o)},i.qrToImageData=function(r,n,o){const s=n.modules.size,d=n.modules.data,l=i.getScale(s,o),u=Math.floor((s+o.margin*2)*l),f=o.margin*l,I=[o.color.light,o.color.dark];for(let x=0;x<u;x++)for(let v=0;v<u;v++){let A=(x*u+v)*4,M=o.color.light;if(x>=f&&v>=f&&x<u-f&&v<u-f){const V=Math.floor((x-f)/l),P=Math.floor((v-f)/l);M=I[d[V*s+P]?1:0]}r[A++]=M.r,r[A++]=M.g,r[A++]=M.b,r[A]=M.a}}})($t)),$t}var kn;function ro(){return kn||(kn=1,(function(i){const a=Yn();function c(n,o,s){n.clearRect(0,0,o.width,o.height),o.style||(o.style={}),o.height=s,o.width=s,o.style.height=s+"px",o.style.width=s+"px"}function r(){try{return document.createElement("canvas")}catch{throw new Error("You need to specify a canvas element")}}i.render=function(o,s,d){let l=d,u=s;typeof l>"u"&&(!s||!s.getContext)&&(l=s,s=void 0),s||(u=r()),l=a.getOptions(l);const f=a.getImageWidth(o.modules.size,l),I=u.getContext("2d"),x=I.createImageData(f,f);return a.qrToImageData(x.data,o,l),c(I,u,f),I.putImageData(x,0,0),u},i.renderToDataURL=function(o,s,d){let l=d;typeof l>"u"&&(!s||!s.getContext)&&(l=s,s=void 0),l||(l={});const u=i.render(o,s,l),f=l.type||"image/png",I=l.rendererOpts||{};return u.toDataURL(f,I.quality)}})(zt)),zt}var Gt={},Fn;function oo(){if(Fn)return Gt;Fn=1;const i=Yn();function a(n,o){const s=n.a/255,d=o+'="'+n.hex+'"';return s<1?d+" "+o+'-opacity="'+s.toFixed(2).slice(1)+'"':d}function c(n,o,s){let d=n+o;return typeof s<"u"&&(d+=" "+s),d}function r(n,o,s){let d="",l=0,u=!1,f=0;for(let I=0;I<n.length;I++){const x=Math.floor(I%o),v=Math.floor(I/o);!x&&!u&&(u=!0),n[I]?(f++,I>0&&x>0&&n[I-1]||(d+=u?c("M",x+s,.5+v+s):c("m",l,0),l=0,u=!1),x+1<o&&n[I+1]||(d+=c("h",f),f=0)):l++}return d}return Gt.render=function(o,s,d){const l=i.getOptions(s),u=o.modules.size,f=o.modules.data,I=u+l.margin*2,x=l.color.light.a?"<path "+a(l.color.light,"fill")+' d="M0 0h'+I+"v"+I+'H0z"/>':"",v="<path "+a(l.color.dark,"stroke")+' d="'+r(f,u,l.margin)+'"/>',A='viewBox="0 0 '+I+" "+I+'"',V='<svg xmlns="http://www.w3.org/2000/svg" '+(l.width?'width="'+l.width+'" height="'+l.width+'" ':"")+A+' shape-rendering="crispEdges">'+x+v+`</svg>
`;return typeof d=="function"&&d(null,V),V},Gt}var On;function io(){if(On)return Ve;On=1;const i=_r(),a=no(),c=ro(),r=oo();function n(o,s,d,l,u){const f=[].slice.call(arguments,1),I=f.length,x=typeof f[I-1]=="function";if(!x&&!i())throw new Error("Callback required as last argument");if(x){if(I<2)throw new Error("Too few arguments provided");I===2?(u=d,d=s,s=l=void 0):I===3&&(s.getContext&&typeof u>"u"?(u=l,l=void 0):(u=l,l=d,d=s,s=void 0))}else{if(I<1)throw new Error("Too few arguments provided");return I===1?(d=s,s=l=void 0):I===2&&!s.getContext&&(l=d,d=s,s=void 0),new Promise(function(v,A){try{const M=a.create(d,l);v(o(M,s,l))}catch(M){A(M)}})}try{const v=a.create(d,l);u(null,o(v,s,l))}catch(v){u(v)}}return Ve.create=a.create,Ve.toCanvas=n.bind(null,c.render),Ve.toDataURL=n.bind(null,c.renderToDataURL),Ve.toString=n.bind(null,function(o,s,d){return r.render(o,d)}),Ve}var so=io();const ao=fr(so);function Xo(){const[i,a]=_.useState(0),[c,r]=_.useState(!1),[n,o]=_.useState(null),[s,d]=_.useState([]),[l,u]=_.useState([]),[f,I]=_.useState([]),[x,v]=_.useState(""),[A,M]=_.useState(!0),[V,P]=_.useState(null),[k,B]=_.useState(null),[S,H]=_.useState(null),[N,g]=_.useState(""),[p,h]=_.useState({}),[b,C]=_.useState([]),[w,E]=_.useState(!1),[j,re]=_.useState(null),[Y,Ce]=_.useState(null),[ye,ut]=_.useState(""),[Le,we]=_.useState(!1),[He,$]=_.useState(""),[mt,qe]=_.useState([]),{permissions:G=[],user:ce}=pr(),le=ce?.branchAccess==="ALL",ae=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW),de=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE),Ee=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.CUSTOMER),Te=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.PAYMENT_VERIFICATION),ke=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.COMPLETE_PAYMENT),Fe=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.PENDING_LIST),Re=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.VERIFIED_LIST),ze=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE,se.RECEIPTS.CUSTOMER),$e=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE,se.RECEIPTS.PAYMENT_VERIFICATION),Kn=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE,se.RECEIPTS.COMPLETE_PAYMENT),Jn=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE,se.RECEIPTS.PENDING_LIST),Qn=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.CREATE,se.RECEIPTS.VERIFIED_LIST);Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.UPDATE,se.RECEIPTS.CUSTOMER),Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.UPDATE,se.RECEIPTS.PAYMENT_VERIFICATION);const ht=Q(G,Z.ACCOUNT,X.ACCOUNT.RECEIPTS,W.VIEW,se.RECEIPTS.CUSTOMER)||Ee,Ae=Ee||Te||ke||Fe||Re;_.useEffect(()=>{if(!Ae)return;const t=[];Ee&&t.push(0),Te&&t.push(1),ke&&t.push(2),Fe&&t.push(3),Re&&t.push(4),t.length>0&&!t.includes(i)&&a(t[0])},[Ae,Ee,Te,ke,Fe,Re,i]),_.useEffect(()=>{if(!ae){ie("You do not have permission to view Receipts"),M(!1);return}if(!Ae){ie("You do not have permission to view any Receipt tabs"),M(!1);return}Kt(),vt(),xt(),Wn(),Xn()},[ae,Ae]),_.useEffect(()=>(window.printReceiptCallback=At,()=>{delete window.printReceiptCallback}),[]);const Wn=async()=>{try{const t=["/settings/cash-locations","/master/cash-locations"];for(const y of t)try{const L=await te.get(y);if(L.data.success&&L.data.data){C(L.data.data),console.log("Cash locations loaded:",L.data.data);return}}catch{console.log(`Endpoint ${y} not available`)}console.warn("Could not fetch cash locations from any endpoint"),C([])}catch(t){console.error("Error fetching cash locations:",t),C([])}},Xn=async()=>{try{const t=await te.get("/branches");qe(t.data.data)}catch(t){const y=ie(t);y&&P(y)}},Kt=async()=>{try{M(!0);const y=(await te.get("/bookings")).data.data.bookings.filter(F=>F.bookingType==="BRANCH");d(y);const L=y.map(async F=>{try{const m=await te.get(`/ledger/booking/${F._id}`);return{bookingId:F._id,receipts:m.data.data.allReceipts||[]}}catch(m){return console.error(`Error fetching receipts for booking ${F._id}:`,m),{bookingId:F._id,receipts:[]}}}),T=await Promise.all(L),U={};T.forEach(F=>{U[F.bookingId]=F.receipts}),h(U)}catch(t){const y=ie(t);y&&P(y)}finally{M(!1)}},vt=async()=>{if(!(!ae||!Te))try{const t=await te.get("/ledger/pending");u(t.data.data.ledgerEntries)}catch(t){const y=ie(t);y&&P(y)}},xt=async()=>{if(!(!ae||!Re))try{const t=await te.get("/payment/verified/bank/ledger");I(t.data.data.ledgerEntries)}catch(t){const y=ie(t);y&&P(y)}},Jt=t=>{if(!t)return"";const y=String(t.getDate()).padStart(2,"0"),L=String(t.getMonth()+1).padStart(2,"0"),T=t.getFullYear();return`${y}-${L}-${T}`},Qt=t=>{if(!t)return"";const y=t.getFullYear(),L=String(t.getMonth()+1).padStart(2,"0"),T=String(t.getDate()).padStart(2,"0");return`${y}-${L}-${T}`},bt=(t,y)=>{if(!y)return t;const L=Cr("receipts"),T=y.toLowerCase();return t.filter(U=>L.some(F=>{const m=F.split(".").reduce((O,q)=>O?q.match(/^\d+$/)?O[parseInt(q)]:O[q]:"",U);return m==null?!1:typeof m=="boolean"?(m?"yes":"no").includes(T):F==="createdAt"&&m instanceof Date?m.toLocaleDateString("en-GB").includes(T):typeof m=="number"?String(m).includes(T):String(m).toLowerCase().includes(T)}))},Zn=(t,y)=>{if(!y)return t;const L=y.toLowerCase();return t.filter(T=>(T.bookingDetails?.bookingNumber||"").toLowerCase().includes(L)||(T.bookingDetails?.customerDetails?.name||"").toLowerCase().includes(L)||(T.paymentMode||"").toLowerCase().includes(L)||String(T.amount||"").includes(L)||(T.transactionReference||"").toLowerCase().includes(L))},er=(t,y)=>{if(!y)return t;const L=y.toLowerCase();return t.filter(T=>(T.booking||"").toLowerCase().includes(L)||(T.bookingDetails?.customerDetails?.name||"").toLowerCase().includes(L)||(T.paymentMode||"").toLowerCase().includes(L)||String(T.amount||"").includes(L)||(T.transactionReference||"").toLowerCase().includes(L)||(T.receivedByDetails?.name||"").toLowerCase().includes(L))},Wt=bt(s,x),Xt=bt(s.filter(t=>parseFloat(t.balanceAmount||0)===0),x),Zt=bt(s.filter(t=>parseFloat(t.balanceAmount||0)!==0),x),en=Zn(l,x),tn=er(f,x),tr=(t,y)=>{B(t.currentTarget),H(y)},Ct=()=>{B(null),H(null)},nr=t=>{if(!ze){ie("You do not have permission to add payments");return}o(t),r(!0),Ct()},rr=async t=>{if(!$e){ie("You do not have permission to verify payments");return}try{(await vr({title:"Confirm Payment Verification",text:`Are you sure you want to verify the payment of ₹${t.amount} for booking ${t.bookingDetails?.bookingNumber||t.booking}?`,confirmButtonText:"Yes, verify it!"})).isConfirmed&&(await te.patch(`/ledger/approve/${t._id}`,{remark:""}),g("Payment verified successfully!"),setTimeout(()=>g(""),3e3),vt(),xt())}catch(y){console.error("Error verifying payment:",y),ie(y,"Failed to verify payment")}},Ge=t=>{Ae&&(a(t),v(""))},or=()=>{if(!de){ie("You do not have permission to export data");return}E(!0),$("")},yt=()=>{E(!1),re(null),Ce(null),ut(""),$("")},ir=async()=>{if(!de){ie("You do not have permission to export data");return}if($(""),!ye){$("Please select a branch");return}if(!j||!Y){$("Please select both start and end dates");return}if(j>Y){$("Start date cannot be after end date");return}try{we(!0);const t=Qt(j),y=Qt(Y),L=new URLSearchParams({branchId:ye,startDate:t,endDate:y,format:"excel"}),T=await te.get(`/reports/receipts?${L.toString()}`,{responseType:"blob"}),U=T.headers["content-type"];if(U&&U.includes("application/json")){const Se=await new Promise((Oe,je)=>{const me=new FileReader;me.onload=()=>Oe(me.result),me.onerror=je,me.readAsText(T.data)}),be=JSON.parse(Se);if(!be.success&&be.message){$(be.message),Ie.fire({icon:"error",title:"Export Failed",text:be.message});return}}const F=new Blob([T.data],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),m=window.URL.createObjectURL(F),O=document.createElement("a");O.href=m;const q=mt.find(Se=>Se._id===ye)?.name||"Branch",K=Jt(j),J=Jt(Y),ue=`Receipts_${q}_${K}_to_${J}.xlsx`;O.setAttribute("download",ue),document.body.appendChild(O),O.click(),O.remove(),window.URL.revokeObjectURL(m),Ie.fire({toast:!0,position:"top-end",icon:"success",title:"Excel exported successfully!",showConfirmButton:!1,timer:3e3,timerProgressBar:!0}),yt()}catch(t){if(console.error("Error exporting report:",t),t.response&&t.response.data instanceof Blob)try{const y=await new Promise((T,U)=>{const F=new FileReader;F.onload=()=>T(F.result),F.onerror=U,F.readAsText(t.response.data)}),L=JSON.parse(y);L.message&&($(L.message),Ie.fire({icon:"error",title:"Export Failed",text:L.message}))}catch(y){console.error("Error parsing error response:",y),$("Failed to export report"),Ie.fire({icon:"error",title:"Export Failed",text:"Failed to export report"})}else t.response?.data?.message?($(t.response.data.message),Ie.fire({icon:"error",title:"Export Failed",text:t.response.data.message})):t.message?($(t.message),Ie.fire({icon:"error",title:"Export Failed",text:t.message})):($("Failed to export report"),Ie.fire({icon:"error",title:"Export Failed",text:"Failed to export report"}))}finally{we(!1)}},sr=()=>{Kt(),vt(),xt()},At=async(t,y,L=0)=>{if(!ht){ie("You do not have permission to print invoices");return}try{const U=(await te.get(`/ledger/receipt/${t}`)).data.data.receipt,F=await te.get(`/bookings/booking-payment-status/${y}`),m=F.data.data.bookingDetails,O=F.data.data.finalStatus||"",q=U.qrCodeData||{},K=m.subsidyAmount||0,J=m.model?.type==="EV",ue=m.priceComponents||[],be=ue.filter(oe=>{const pe=oe.header?.header_key?.toUpperCase()||"",_e=/INSURANCE|INSURCANCE|INSUR|COVER|PREMIUM|INSURANCE CHARGES/i.test(pe),Ue=/RTO|ROAD TAX|RTO TAX & REGISTRATION CHARGES/i.test(pe),gt=/HYPOTHECATION|HPA|HP CHARGES|HPA (if applicable)|HYPOTHECATION CHARGES (IF APPLICABLE)/i.test(pe);return!(_e||Ue||gt)}).reduce((oe,pe)=>oe+(pe.discountedValue||0),0),Oe=oe=>ue.find(pe=>{const _e=pe.header?.header_key?.toUpperCase()||"";return oe.some(Ue=>_e.includes(Ue))}),je=Oe(["INSURANCE","INSURCANCE","INSURANCE CHARGES","INSURANCE 4+1 INCLUSIVE OF ADDITIONAL COVERS"]),me=je?je.originalValue:0,Ye=Oe(["RTO","RTO TAX & REGISTRATION CHARGES"]),Ke=Ye?Ye.originalValue:0,Je=Oe(["HYPOTHECATION","HPA","HPA (if applicable)"]),Qe=Je?Je.originalValue:m.hypothecationCharges||0,We=me+Ke+Qe,Xe=J&&K>0?K:0,Ze=be+We-Xe,et=`GANDHI MOTORS PVT LTD
Booking Number: ${q.bookingNumber||m.bookingNumber}
Customer: ${q.customerName||m.customerDetails?.name}
Mobile: ${q.mobileNo||m.customerDetails?.mobile1}
Model: ${q.modelName||m.model?.model_name}
Type: ${m.model?.type||"N/A"}
Chassis: ${q.chassisNo||m.chassisNumber||"Not allocated"}
Payment Type: ${q.paymentType||m.payment?.type}
Total Amount: ₹${Ze.toFixed(2)}
${J&&K>0?`Subsidy: -₹${K.toFixed(2)}`:""}
Receipt: ${U.receiptNumber||"N/A"}
Amount: ${U.display?.amount||`₹${U.amount?.toFixed(2)||"0"}`}
Payment Mode: ${U.paymentMode||"Cash"}
Reference: ${U.transactionReference||"N/A"}
Date: ${new Date(U.receiptDate).toLocaleDateString("en-GB")}`;let tt="";try{tt=await ao.toDataURL(et,{width:250,margin:3,color:{dark:"#000000",light:"#FFFFFF"},errorCorrectionLevel:"H"})}catch(oe){console.error("Error generating QR code:",oe),tt="data:image/svg+xml;base64,"+btoa(`
        <svg xmlns="http://www.w3.org/2000/svg" width="250" height="250">
          <rect width="250" height="250" fill="white"/>
          <rect x="20" y="20" width="210" height="210" fill="#f0f0f0" stroke="#ccc" stroke-width="2"/>
          <text x="125" y="115" text-anchor="middle" font-family="Arial" font-size="16" fill="#333">QR CODE</text>
          <text x="125" y="140" text-anchor="middle" font-family="Arial" font-size="12" fill="#666">Receipt: ${U.receiptNumber}</text>
          <text x="125" y="160" text-anchor="middle" font-family="Arial" font-size="10" fill="#999">Scan for details</text>
        </svg>
      `)}const z={bookingNumber:m.bookingNumber,bookingType:m.bookingType,rto:m.rto,hpa:m.hpa,hypothecationCharges:m.hypothecationCharges||0,gstin:m.gstin||"",model:{model_name:m.model?.model_name||"N/A",type:m.model?.type||"N/A"},chassisNumber:q.chassisNo||m.chassisNumber,engineNumber:m.vehicle?.engineNumber||m.engineNumber,batteryNumber:m.vehicle?.batteryNumber||"",keyNumber:m.vehicle?.keyNumber||"",color:{name:m.color?.name||""},customerDetails:{name:m.customerDetails?.name||"N/A",address:m.customerDetails?.address||"",taluka:m.customerDetails?.taluka||"",district:m.customerDetails?.district||"",pincode:m.customerDetails?.pincode||"",mobile1:m.customerDetails?.mobile1||"",dob:m.customerDetails?.dob||"",aadharNumber:m.customerDetails?.aadharNumber||""},exchange:m.exchange,exchangeDetails:m.exchangeDetails,payment:{type:m.payment?.type||"CASH",financer:m.payment?.financer},salesExecutive:m.salesExecutive,branch:{gst_number:m.branch?.gst_number||""},accessories:m.accessories||[],priceComponents:m.priceComponents||[],subdealer:m.subdealer||"",receivedAmount:m.receivedAmount||0,finalStatus:O||"",recentPayment:U,qrCodeData:q,qrCodeImage:tt,qrCodeText:et,recentPaymentAmount:U.amount||0,bookingDetails:m,subsidyAmount:K,calculatedTotals:{totalA:be,totalB:We,grandTotal:Ze,insuranceCharges:me,rtoCharges:Ke,hpCharges:Qe,subsidyDisplay:Xe}},Pe=ar(z,L===0),ge=window.open("","_blank");ge.document.write(Pe),ge.document.close(),ge.onload=function(){ge.focus(),ge.print()}}catch(T){console.error("Error generating receipt invoice:",T),ie(T,"Failed to generate receipt invoice")}},ar=(t,y=!0)=>{const L=t.exchange&&t.exchangeDetails?.broker?.name||"",T=t.exchange&&t.exchangeDetails?.vehicleNumber||"",U=new Date().toLocaleDateString("en-GB"),F=t.recentPayment?.receiptDate?new Date(t.recentPayment.receiptDate).toLocaleDateString("en-GB"):U,m=t.recentPaymentAmount||0,O=t.recentPayment?.transactionReference||"-",q=Or(m),K=t.recentPayment?.paymentMode||"-",J=t.recentPayment?.receiptNumber||"-";t.qrCodeData;const ue=t.qrCodeImage||"",Se=t.bookingDetails?.subsidyAmount||t.subsidyAmount||0,be=t.bookingDetails?.model?.type==="EV"||t.model?.type==="EV";if(y){const je=t.priceComponents.filter(z=>{const he=z.header?.header_key?.toUpperCase()||"",Pe=/INSURANCE|INSURCANCE|INSUR|COVER|PREMIUM|INSURANCE CHARGES/i.test(he),ge=/RTO|ROAD TAX|RTO TAX & REGISTRATION CHARGES/i.test(he),oe=/HYPOTHECATION|HPA|HP CHARGES|HPA (if applicable)|HYPOTHECATION CHARGES (IF APPLICABLE)/i.test(he);return!(Pe||ge||oe)}).map(z=>{const he=parseFloat(z.header?.metadata?.gst_rate)||0,Pe=z.originalValue,ge=0,oe=z.originalValue,pe=oe*100/(100+he),_e=oe-pe,Ue=_e/2,gt=_e/2,hr=Ue+gt;return{...z,unitCost:Pe,taxableValue:pe,cgstAmount:Ue,sgstAmount:gt,gstAmount:hr,gstRatePercentage:he,discount:ge,lineTotal:oe}}),me=z=>t.priceComponents.find(he=>{const Pe=he.header?.header_key?.toUpperCase()||"";return z.some(ge=>Pe.includes(ge))}),Ye=me(["INSURANCE","INSURCANCE","INSURANCE CHARGES","INSURANCE 4+1 INCLUSIVE OF ADDITIONAL COVERS"]),Ke=Ye?Ye.originalValue:0,Je=me(["RTO","RTO TAX & REGISTRATION CHARGES"]),Qe=Je?Je.originalValue:0,We=me(["HYPOTHECATION","HPA","HPA (if applicable)"]),Xe=We?We.originalValue:t.hypothecationCharges||0,Ze=je.reduce((z,he)=>z+he.lineTotal,0),et=Ke+Qe+Xe,tt=Ze+et;return`
<!DOCTYPE html>
<html>
<head>
  <title>Payment Receipt - ${J}</title>
  <style>
    body {
      font-family: "Courier New", Courier, monospace;
      margin: 0;
      padding: 10mm;
      font-size: 14px;
      color: #555555;
    }
    .page {
      width: 210mm;
      height: 297mm;
      margin: 0 auto;
    }
    .header-container {
      display: flex;
      justify-content: space-between;
      margin-bottom: 2mm;
      align-items: flex-start;
    }
    .header-left {
      width: 60%;
    }
    .header-right {
      width: 40%;
      text-align: right;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    .logo-qr-container {
      display: flex;
      align-items: center;
      gap: 20px;
      justify-content: flex-end;
      margin-bottom: 10px;
      width: 100%;
    }
    .logo {
      height: 80px;
    }
    .qr-code-extra-big {
      width: 150px;
      height: 150px;
      border: 1px solid #ccc;
    }
    .dealer-info {
      text-align: left;
      font-size: 14px;
      line-height: 1.2;
    }
    .customer-info-container {
      display: flex;
      font-size:14px;
    }

    .customer-info-left {
      width: 50%;
    }
    .customer-info-right {
      width: 50%;
    }
    .customer-info-row {
      margin: 1mm 0;
      line-height: 1.2;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 9pt;
      margin: 2mm 0;
    }
    th, td {
      padding: 1mm;
      border: 1px solid #000;
      vertical-align: top;
    }
    .no-border { 
      border: none !important; 
      font-size:14px;
    }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .bold { 
      font-weight: bold; 
    }
    .section-title {
      font-weight: bold;
      margin: 1mm 0;
    }
    .signature-box {
      margin-top: 5mm;
      font-size: 9pt;
    }
    .signature-line {
      border-top: 1px dashed #000;
      width: 40mm;
      display: inline-block;
      margin: 0 5mm;
    }
    .footer {
      font-size: 8pt;
      text-align: justify;
      line-height: 1.2;
      margin-top: 3mm;
    }
    .divider {
      border-top: 2px solid #AAAAAA;
    }
    .totals-table {
      width: 100%;
      border-collapse: collapse;
      margin: 2mm 0;
    }
    .totals-table td {
      border: none;
      padding: 1mm;
    }
    .total-divider {
      border-top: 2px solid #AAAAAA;
      height: 1px;
      margin: 2px 0;
    }
    .broker-info{
      display:flex;
      justify-content:space-between;
      padding:1px;
    }
    .status-box {
      background-color: #e8f5e8;
      border: 2px solid #c3e6c3;
      border-radius: 4px;
      padding: 15px;
      margin: 10px 0;
      text-align: center;
      font-weight: bold;
      font-size: 20px;
      color: #495057;
    }
    .payment-info-title {
      font-weight: bold;
      margin-bottom: 5px;
      color: #155724;
      font-size: 16px;
    }
    .amount-in-words {
      font-style: italic;
      margin-top: 5px;
      color: #333;
      padding: 5px;
    }

    .note{
      padding:1px;
      margin:2px;
    }
    
    /* QR Code at bottom - even bigger */
    .qr-bottom-section {
      margin-top: 10mm;
      text-align: center;
      page-break-inside: avoid;
    }
    .qr-bottom-big {
      width: 180px;
      height: 180px;
      border: 1px solid #ccc;
      margin: 0 auto;
      display: block;
    }
    .qr-scan-text {
      font-size: 10pt;
      color: #777;
      margin-top: 3mm;
    }
    
    .receipt-info {
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 4px;
      padding: 10px;
      margin: 10px 0;
    }
    
    @page {
      size: A4;
      margin: 0;
    }
    @media print {
      body {
        padding: 5mm;
      }
      .qr-bottom-section {
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- Header Section with QR Code -->
    <div class="header-container">
      <div class="header-left">
        <h2 style="margin:3;font-size:15pt;">GANDHI MOTORS PVT LTD</h2>
        <div class="dealer-info">
          Authorized Main Dealer: TVS Motor Company Ltd.<br>
          Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
          Upnagar, Nashik Road, Nashik, 7498993672<br>
          GSTIN: ${t.branch?.gst_number||""}<br>
          GANDHI TVS PIMPALGAON
        </div>
      </div>
      <div class="header-right">
        <!-- Logo and QR code side by side -->
        <div class="logo-qr-container">
          <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
          ${ue?`<img src="${ue}" class="qr-code-extra-big" alt="QR Code" />`:""}
        </div>
        
        <div style="margin-top: 5px; font-size: 13px;">Date: ${F}</div>
        <div style="margin-top: 5px; font-size: 13px;"><strong>Receipt No:</strong> ${J}</div>

        ${t.bookingType==="SUBDEALER"?`<div style="font-size: 12px;"><b>Subdealer:</b> ${t.subdealer?.name||""}</div>
        <div style="font-size: 11px;"><b>Address:</b> ${t.subdealer?.location||""}</div>
          
          `:""}
        
      </div>
    </div>
    <div class="divider"></div>

    <!-- Receipt Information -->
    <div class="receipt-info">
      <div><strong>Payment Receipt</strong></div>
      <div><strong>Booking Number:</strong> ${t.bookingNumber}</div>
      <div><strong>Receipt Date:</strong> ${F}</div>
    </div>

    <!-- Customer Information -->
    <div class="customer-info-container">
      <div class="customer-info-left">
        <div class="customer-info-row"><strong>Booking Number:</strong> ${t.bookingNumber}</div>
        <div class="customer-info-row"><strong>Customer Name:</strong> ${t.customerDetails.name}</div>
        <div class="customer-info-row"><strong>Address:</strong> ${t.customerDetails.address}, ${t.customerDetails.taluka},${t.customerDetails.pincode||""}</div>
        <div class="customer-info-row"><strong>Mobile No.:</strong> ${t.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${t.hpa?"YES":"NO"}</div>
      </div>
      <div class="customer-info-right">
        <div class="customer-info-row"><strong>Model Name:</strong> ${t.model.model_name}</div>
       <div class="customer-info-row"><strong>Chassis No:</strong> ${t.chassisNumber}</div>
        <div class="customer-info-row"><strong>Payment Type:</strong> ${t.payment?.type||"CASH"}</div>
         <div class="customer-info-row"><strong>Financer:</strong> ${t.payment?.financer?.name||""}</div>
        <div class="customer-info-row"><strong>Sales Executive:</strong> ${t.salesExecutive?.name||"N/A"}</div>
      </div>
    </div>

    <!-- Received Amount Section -->
    <div class="payment-info-box">
      <div class="receipt-info">
        <div><strong>Receipt Amount (Rs):</strong> ₹${t.recentPaymentAmount.toFixed(2)}</div>
        <div><strong>Receipt Number:</strong> ${J}</div>
        <div><strong>Reference No:</strong> ${O}</div>
        <div><strong>Payment Mode:</strong> ${K}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>
      <div class="amount-in-words">
        <strong>(In Words):</strong> ${q} Only
      </div>
    </div>
    <!-- Price Breakdown Table -->
    <table>
      <tr>
        <th style="width:25%">Particulars</th>
        <th style="width:8%">HSN CODE</th>
        <th style="width:8%">Unit Cost</th>
        <th style="width:8%">Taxable</th>
        <th style="width:5%">CGST</th>
        <th style="width:8%">CGST AMOUNT</th>
        <th style="width:5%">SGST</th>
        <th style="width:8%">SGST AMOUNT</th>
        <th style="width:7%">DISCOUNT</th>
        <th style="width:10%">LINE TOTAL</th>
      </tr>

      ${je.map(z=>`
        <tr>
          <td>${z.header?.header_key||""}</td>
          <td>${z.header?.metadata?.hsn_code||""}</td>
          <td >${z.unitCost.toFixed(2)}</td>
          <td >${z.taxableValue.toFixed(2)}</td>
          <td >${(z.gstRatePercentage/2).toFixed(2)}%</td>
          <td >${z.cgstAmount.toFixed(2)}</td>
          <td >${(z.gstRatePercentage/2).toFixed(2)}%</td>
          <td >${z.sgstAmount.toFixed(2)}</td>
          <td >${z.discount.toFixed(2)}</td>
          <td >${z.lineTotal.toFixed(2)}</td>
        </tr>
      `).join("")}
    </table>

    <!-- Totals Section - No Borders -->
     <table class="totals-table">
      <tr>
        <td class="no-border" style="width:80%"><strong>Total(A)</strong></td>
        <td class="no-border text-right"><strong>${Ze.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td colspan="2" class="no-border"><div class="total-divider"></div></td>
      </tr>
      <tr>
        <td class="no-border"><strong>INSURANCE CHARGES</strong></td>
        <td class="no-border text-right"><strong>${Ke.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>RTO TAX,REGISTRATION SMART CARD CHARGES AGENT FEES</strong></td>
        <td class="no-border text-right"><strong>${Qe.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>HP CHARGES</strong></td>
        <td class="no-border text-right"><strong>${Xe.toFixed(2)}</strong></td>
      </tr>
        ${be&&Se>0?`
      <tr>
        <td class="no-border"><strong>SUBSIDY AMOUNT</strong></td>
        <td class="no-border text-right" style="color: green;"><strong>-${Se.toFixed(2)}</strong></td>
      </tr>
      `:""}
      <tr>
        <td colspan="2" class="no-border"><div class="total-divider"></div></td>
      </tr>
      <tr>
        <td class="no-border"><strong>TOTAL(B)</strong></td>
        <td class="no-border text-right"><strong>${et.toFixed(2)}</strong></td>
      </tr>
      <tr>
        <td class="no-border"><strong>GRAND TOTAL(A) + (B)</strong></td>
        <td class="no-border text-right"><strong>${tt.toFixed(2)}</strong></td>
      </tr>
    </table>
    <div class="broker-info">
      <div><strong>Ex. Broker/ Sub Dealer:</strong>${L}</div>
      <div><strong>Ex. Veh No:</strong>${T}</div>
    </div>
    <div class="note"><strong>Notes:Booking Awaiting approval as discount exceed</strong></div>
    <div class="divider"></div>
    <div style="margin-top:2mm;">
      <div><strong>Booking Status: </strong>
      </div>
      <div class="status-box">
        ${t.finalStatus||"Status: Not Available"}
      </div>
    </div>
    <div class="divider"></div>

    <!-- BIG QR Code at Bottom -->
    
    <div class="divider" style="margin-top: 5mm;"></div>

    <!-- Signature Section - Adjusted to fit properly -->
    <div class="signature-box">
      <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Customer's Signature</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Sales Executive</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Manager</div>
        </div>
        <div style="text-align:center; width: 22%;">
          <div class="signature-line"></div>
          <div>Accountant</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  `}else return`
<!DOCTYPE html>
<html>
<head>
  <title>Payment Receipt - ${J}</title>
  <style>
    body {
      font-family: "Courier New", Courier, monospace;
      margin: 0;
      padding: 10mm;
      font-size: 14px;
      color: #555555;
    }
    .page {
      width: 210mm;
      height: 297mm;
      margin: 0 auto;
    }
    .receipt-copy {
      height: 138mm; /* Half of A4 page */
      page-break-inside: avoid;
    }
    .header-container {
      display: flex;
      justify-content: space-between;
      margin-bottom: 2mm;
      align-items: flex-start;
    }
    .header-left {
      width: 60%;
    }
    .header-right {
      width: 40%;
      text-align: right;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    .logo-qr-container {
      display: flex;
      align-items: center;
      gap: 10px;
      justify-content: flex-end;
      margin-bottom: 5px;
      width: 100%;
    }
    .logo {
      height: 60px;
    }
    .qr-code-small {
      width: 100px;
      height: 100px;
      border: 1px solid #ccc;
    }
    .dealer-info {
      text-align: left;
      font-size: 12px;
      line-height: 1.1;
    }
    .customer-info-container {
      display: flex;
      font-size:12px;
    }
    .customer-info-left {
      width: 50%;
    }
    .customer-info-right {
      width: 50%;
    }
    .customer-info-row {
      margin: 0.5mm 0;
      line-height: 1.1;
    }
    .divider {
      border-top: 1px solid #AAAAAA;
      margin: 2mm 0;
    }
    .receipt-info {
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 4px;
      padding: 8px;
      margin: 8px 0;
      font-size: 12px;
    }
    .payment-info-box {
      margin: 5px 0;
    }
    .signature-box {
      margin-top: 3mm;
      font-size: 8pt;
    }
    .signature-line {
      border-top: 1px dashed #000;
      width: 35mm;
      display: inline-block;
      margin: 0 3mm;
    }
    .cutting-line {
      border-top: 2px dashed #333;
      margin: 10mm 0;
      text-align: center;
      position: relative;
    }
    .cutting-line::before {
      content: "✂ Cut Here ✂";
      position: absolute;
      top: -10px;
      left: 50%;
      transform: translateX(-50%);
      background: white;
      padding: 0 10px;
      font-size: 10px;
      color: #666;
    }
    .note{
      padding:1px;
      margin:2px;
      font-size: 11px;
    }
    
    @page {
      size: A4;
      margin: 0;
    }
    @media print {
      body {
        padding: 5mm;
      }
      .receipt-copy {
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- First Copy -->
    <div class="receipt-copy">
      <!-- Header Section with QR Code -->
      <div class="header-container">
        <div class="header-left">
          <h2 style="margin:2;font-size:12pt;">GANDHI MOTORS PVT LTD</h2>
          <div class="dealer-info">
            Authorized Main Dealer: TVS Motor Company Ltd.<br>
            Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
            Upnagar, Nashik Road, Nashik, 7498993672<br>
            GSTIN: ${t.branch?.gst_number||""}<br>
            GANDHI TVS PIMPALGAON
          </div>
        </div>
        <div class="header-right">
          <!-- Logo and QR code side by side -->
          <div class="logo-qr-container">
            <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
            ${ue?`<img src="${ue}" class="qr-code-small" alt="QR Code" />`:""}
          </div>
          
          <div style="margin-top: 3px; font-size: 11px;">Date: ${F}</div>
          <div style="margin-top: 3px; font-size: 11px;"><strong>Receipt No:</strong> ${J}</div>

          ${t.bookingType==="SUBDEALER"?`<div style="font-size: 10px;"><b>Subdealer:</b> ${t.subdealer?.name||""}</div>
          <div style="font-size: 9px;"><b>Address:</b> ${t.subdealer?.location||""}</div>`:""}
        </div>
      </div>
      <div class="divider"></div>

      <!-- Receipt Information -->
      <div class="receipt-info">
        <div><strong>Payment Receipt</strong></div>
        <div><strong>Booking Number:</strong> ${t.bookingNumber}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>

      <!-- Customer Information -->
      <div class="customer-info-container">
        <div class="customer-info-left">
          <div class="customer-info-row"><strong>Booking Number:</strong> ${t.bookingNumber}</div>
          <div class="customer-info-row"><strong>Customer Name:</strong> ${t.customerDetails.name}</div>
          <div class="customer-info-row"><strong>Address:</strong> ${t.customerDetails.address}, ${t.customerDetails.taluka}</div>
          <div class="customer-info-row"><strong>Mobile No.:</strong> ${t.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${t.hpa?"YES":"NO"}</div>
        </div>
        <div class="customer-info-right">
          <div class="customer-info-row"><strong>Model Name:</strong> ${t.model.model_name}</div>
          <div class="customer-info-row"><strong>Chassis No:</strong> ${t.chassisNumber}</div>
          <div class="customer-info-row"><strong>Payment Type:</strong> ${t.payment?.type||"CASH"}</div>
          <div class="customer-info-row"><strong>Financer:</strong> ${t.payment?.financer?.name||""}</div>
          <div class="customer-info-row"><strong>Sales Executive:</strong> ${t.salesExecutive?.name||"N/A"}</div>
        </div>
      </div>

      <!-- Received Amount Section -->
      <div class="payment-info-box">
        <div class="receipt-info">
          <div><strong>Receipt Amount (Rs):</strong> ₹${t.recentPaymentAmount.toFixed(2)}</div>
          <div><strong>Receipt Number:</strong> ${J}</div>
          <div><strong>Reference No:</strong> ${O}</div>
          <div><strong>Payment Mode:</strong> ${K}</div>
          <div><strong>Receipt Date:</strong> ${F}</div>
        </div>
      </div>

      <div class="note"><strong>Notes:</strong></div>
      <div class="divider"></div>

      <!-- Signature Section -->
      <div class="signature-box">
        <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Customer's Signature</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Sales Executive</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Manager</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Accountant</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Cutting Line -->
    <div class="cutting-line"></div>

    <!-- Second Copy (Duplicate) -->
    <div class="receipt-copy">
      <!-- Header Section with QR Code -->
      <div class="header-container">
        <div class="header-left">
          <h2 style="margin:2;font-size:12pt;">GANDHI MOTORS PVT LTD</h2>
          <div class="dealer-info">
            Authorized Main Dealer: TVS Motor Company Ltd.<br>
            Registered office: 'JOGPREET' Asher Estate, Near Ichhamani Lawns,<br>
            Upnagar, Nashik Road, Nashik, 7498993672<br>
            GSTIN: ${t.branch?.gst_number||""}<br>
            GANDHI TVS PIMPALGAON
          </div>
        </div>
        <div class="header-right">
          <!-- Logo and QR code side by side -->
          <div class="logo-qr-container">
            <img src="https://c.ndtvimg.com/2025-01/t7f4o1kg_tvs_625x300_17_January_25.jpg?im=FaceCrop,algorithm=dnn,width=545,height=307" class="logo" alt="TVS Logo">
            ${ue?`<img src="${ue}" class="qr-code-small" alt="QR Code" />`:""}
          </div>
          
          <div style="margin-top: 3px; font-size: 11px;">Date: ${F}</div>
          <div style="margin-top: 3px; font-size: 11px;"><strong>Receipt No:</strong> ${J}</div>

          ${t.bookingType==="SUBDEALER"?`<div style="font-size: 10px;"><b>Subdealer:</b> ${t.subdealer?.name||""}</div>
          <div style="font-size: 9px;"><b>Address:</b> ${t.subdealer?.location||""}</div>`:""}
        </div>
      </div>
      <div class="divider"></div>

      <!-- Receipt Information -->
      <div class="receipt-info">
        <div><strong>Payment Receipt (DUPLICATE)</strong></div>
        <div><strong>Booking Number:</strong> ${t.bookingNumber}</div>
        <div><strong>Receipt Date:</strong> ${F}</div>
      </div>

      <!-- Customer Information -->
      <div class="customer-info-container">
        <div class="customer-info-left">
          <div class="customer-info-row"><strong>Booking Number:</strong> ${t.bookingNumber}</div>
          <div class="customer-info-row"><strong>Customer Name:</strong> ${t.customerDetails.name}</div>
          <div class="customer-info-row"><strong>Address:</strong> ${t.customerDetails.address}, ${t.customerDetails.taluka}</div>
          <div class="customer-info-row"><strong>Mobile No.:</strong> ${t.customerDetails.mobile1}</div>
          <div class="customer-info-row"><strong>HPA:</strong> ${t.hpa?"YES":"NO"}</div>
        </div>
        <div class="customer-info-right">
          <div class="customer-info-row"><strong>Model Name:</strong> ${t.model.model_name}</div>
          <div class="customer-info-row"><strong>Chassis No:</strong> ${t.chassisNumber}</div>
          <div class="customer-info-row"><strong>Payment Type:</strong> ${t.payment?.type||"CASH"}</div>
          <div class="customer-info-row"><strong>Financer:</strong> ${t.payment?.financer?.name||""}</div>
          <div class="customer-info-row"><strong>Sales Executive:</strong> ${t.salesExecutive?.name||"N/A"}</div>
        </div>
      </div>

      <!-- Received Amount Section -->
      <div class="payment-info-box">
        <div class="receipt-info">
          <div><strong>Receipt Amount (Rs):</strong> ₹${t.recentPaymentAmount.toFixed(2)}</div>
          <div><strong>Receipt Number:</strong> ${J}</div>
          <div><strong>Reference No:</strong> ${O}</div>
          <div><strong>Payment Mode:</strong> ${K}</div>
          <div><strong>Receipt Date:</strong> ${F}</div>
        </div>
      </div>

      <div class="note"><strong>Notes:</strong></div>
      <div class="divider"></div>

      <!-- Signature Section -->
      <div class="signature-box">
        <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Customer's Signature</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Sales Executive</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Manager</div>
          </div>
          <div style="text-align:center; width: 22%;">
            <div class="signature-line"></div>
            <div>Accountant</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  `},cr=()=>{if(!Ee)return e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Customer tab."})});const t=ze||ht,y=ze,L=ht;return e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(at,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(ct,{children:e.jsxs(ee,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"}),e.jsx(D,{scope:"col",children:"Receipts"}),t&&e.jsx(D,{scope:"col",children:"Action"})]})}),e.jsx(lt,{children:Wt.length===0?e.jsx(ee,{children:e.jsx(R,{colSpan:t?"12":"11",style:{color:"red",textAlign:"center"},children:x?"No matching bookings found":"No booking available"})}):Wt.map((T,U)=>{const m=[...p[T._id]||[]].sort((O,q)=>{const K=new Date(O.receiptDate||O.createdAt||0),J=new Date(q.receiptDate||q.createdAt||0);return K-J});return e.jsxs(ee,{children:[e.jsx(R,{children:U+1}),e.jsx(R,{children:T.bookingNumber}),e.jsx(R,{children:T.model?.model_name||"N/A"}),e.jsx(R,{children:T.createdAt?new Date(T.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(R,{children:T.customerDetails?.name||"N/A"}),e.jsx(R,{children:T.customerDetails?.mobile1||"N/A"}),e.jsx(R,{children:T.chassisAllocationStatus==="ALLOCATED"&&T.status==="ALLOCATED"&&T.chassisNumber||""}),e.jsx(R,{children:Math.round(T.discountedAmount)||"0"}),e.jsx(R,{children:Math.round(T.receivedAmount)||"0"}),e.jsx(R,{children:Math.round(T.balanceAmount)||"0"}),e.jsx(R,{children:m.length>0?e.jsxs(on,{children:[e.jsxs(sn,{size:"sm",color:"info",variant:"outline",disabled:!L,children:[m.length," Receipt",m.length>1?"s":""]}),e.jsx(an,{children:m.map((O,q)=>e.jsx(cn,{onClick:()=>At(O.id,T._id,q),children:e.jsxs("div",{className:"d-flex align-items-center",children:[e.jsx(rt,{icon:dn,className:"me-2"}),e.jsxs("div",{children:[e.jsx("div",{children:e.jsxs("strong",{children:["Receipt #",q+1]})}),e.jsxs("small",{children:[O.display?.amount||`₹${O.amount}`," -",O.display?.date||new Date(O.receiptDate).toLocaleDateString("en-GB")]})]})]})},O.id))})]}):e.jsx("span",{className:"text-muted",children:"No receipts"})}),t&&e.jsxs(R,{children:[e.jsxs(De,{size:"sm",className:"option-button btn-sm",onClick:O=>tr(O,T._id),disabled:!y,children:[e.jsx(rt,{icon:Ar}),"Options"]}),e.jsx(Br,{id:`action-menu-${T._id}`,anchorEl:k,open:S===T._id,onClose:Ct,anchorOrigin:{vertical:"bottom",horizontal:"right"},transformOrigin:{vertical:"top",horizontal:"right"},children:y&&e.jsxs(Mr,{onClick:()=>{nr(T),Ct()},children:[e.jsx(rt,{icon:Lr,className:"me-2"}),"Add Payment"]})})]})]},U)})})]})})},lr=()=>Te?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(at,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(ct,{children:e.jsxs(ee,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Payment Mode"}),e.jsx(D,{scope:"col",children:"Amount"}),e.jsx(D,{scope:"col",children:"Transaction Reference"}),e.jsx(D,{scope:"col",children:"Date"}),e.jsx(D,{scope:"col",children:"Bank Receipts"}),e.jsx(D,{scope:"col",children:"Status"}),$e&&e.jsx(D,{scope:"col",children:"Action"})]})}),e.jsx(lt,{children:en.length===0?e.jsx(ee,{children:e.jsx(R,{colSpan:$e?"11":"10",style:{color:"red",textAlign:"center"},children:x?"No matching pending payments found":"No pending payments available"})}):en.map((t,y)=>{const L=t.bookingDetails?._id||t.booking,F=[...(p[L]||[]).filter(m=>m.paymentMode&&m.paymentMode.toUpperCase()==="BANK")].sort((m,O)=>{const q=new Date(m.receiptDate||m.createdAt||0),K=new Date(O.receiptDate||O.createdAt||0);return q-K});return e.jsxs(ee,{children:[e.jsx(R,{children:y+1}),e.jsx(R,{children:t.bookingDetails?.bookingNumber||t.booking||""}),e.jsx(R,{children:t.bookingDetails?.customerDetails?.name||""}),e.jsx(R,{children:t.paymentMode||""}),e.jsx(R,{children:t.amount||""}),e.jsx(R,{children:t.transactionReference||""}),e.jsx(R,{children:t.updatedAt?new Date(t.updatedAt).toLocaleDateString("en-GB"):" "}),e.jsx(R,{children:F.length>0?e.jsxs(on,{children:[e.jsxs(sn,{size:"sm",color:"info",variant:"outline",children:[F.length," Bank Receipt",F.length>1?"s":""]}),e.jsx(an,{children:F.map((m,O)=>e.jsx(cn,{onClick:()=>At(m.id,L,O),disabled:!ht,children:e.jsxs("div",{className:"d-flex align-items-center",children:[e.jsx(rt,{icon:dn,className:"me-2"}),e.jsxs("div",{children:[e.jsx("div",{children:e.jsxs("strong",{children:["Bank Receipt #",O+1]})}),e.jsxs("small",{children:[m.display?.amount||`₹${m.amount}`," -",m.display?.date||(m.receiptDate?new Date(m.receiptDate).toLocaleDateString("en-GB"):"N/A")]})]})]})},m.id))})]}):e.jsx("span",{className:"text-muted",children:"No bank receipts"})}),e.jsx(R,{children:e.jsx(Nr,{color:t.approvalStatus==="Pending"?"danger":"success",shape:"rounded-pill",children:t.approvalStatus==="Pending"?"PENDING":"VERIFIED"})}),$e&&e.jsx(R,{children:t.approvalStatus==="Pending"?e.jsxs(De,{size:"sm",className:"action-btn",onClick:()=>rr(t),children:[e.jsx(rt,{icon:kr,className:"me-1"}),"Verify"]}):e.jsx("span",{className:"text-muted",children:"Verified"})})]},y)})})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Payment Verification tab."})}),dr=()=>ke?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(at,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(ct,{children:e.jsxs(ee,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"})]})}),e.jsx(lt,{children:Xt.length===0?e.jsx(ee,{children:e.jsx(R,{colSpan:"10",style:{color:"red",textAlign:"center"},children:x?"No matching complete payments found":"No complete payments available"})}):Xt.map((t,y)=>e.jsxs(ee,{children:[e.jsx(R,{children:y+1}),e.jsx(R,{children:t.bookingNumber||""}),e.jsx(R,{children:t.model?.model_name||"N/A"}),e.jsx(R,{children:t.createdAt?new Date(t.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(R,{children:t.customerDetails?.name||"N/A"}),e.jsx(R,{children:t.customerDetails?.mobile1||"N/A"}),e.jsx(R,{children:t.chassisAllocationStatus==="ALLOCATED"&&t.status==="ALLOCATED"&&t.chassisNumber||""}),e.jsx(R,{children:Math.round(t.discountedAmount)||"0"}),e.jsx(R,{children:Math.round(t.receivedAmount)||"0"}),e.jsx(R,{style:{color:"green"},children:Math.round(t.balanceAmount)||"0"})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Complete Payment tab."})}),ur=()=>Fe?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(at,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(ct,{children:e.jsxs(ee,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Model Name"}),e.jsx(D,{scope:"col",children:"Booking Date"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Mobile Number"}),e.jsx(D,{scope:"col",children:"Chassis Number"}),e.jsx(D,{scope:"col",children:"Total"}),e.jsx(D,{scope:"col",children:"Received"}),e.jsx(D,{scope:"col",children:"Balance"})]})}),e.jsx(lt,{children:Zt.length===0?e.jsx(ee,{children:e.jsx(R,{colSpan:"10",style:{color:"red",textAlign:"center"},children:x?"No matching pending payments found":"No pending payments available"})}):Zt.map((t,y)=>e.jsxs(ee,{children:[e.jsx(R,{children:y+1}),e.jsx(R,{children:t.bookingNumber||""}),e.jsx(R,{children:t.model?.model_name||"N/A"}),e.jsx(R,{children:t.createdAt?new Date(t.createdAt).toLocaleDateString("en-GB"):" "}),e.jsx(R,{children:t.customerDetails?.name||"N/A"}),e.jsx(R,{children:t.customerDetails?.mobile1||"N/A"}),e.jsx(R,{children:t.chassisAllocationStatus==="ALLOCATED"&&t.status==="ALLOCATED"&&t.chassisNumber||""}),e.jsx(R,{children:Math.round(t.discountedAmount)||"0"}),e.jsx(R,{children:Math.round(t.receivedAmount)||"0"}),e.jsx(R,{style:{color:"red"},children:Math.round(t.balanceAmount)||"0"})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Pending List tab."})}),mr=()=>Re?e.jsx("div",{className:"responsive-table-wrapper",children:e.jsxs(at,{striped:!0,bordered:!0,hover:!0,className:"responsive-table",children:[e.jsx(ct,{children:e.jsxs(ee,{children:[e.jsx(D,{scope:"col",children:"Sr.no"}),e.jsx(D,{scope:"col",children:"Booking ID"}),e.jsx(D,{scope:"col",children:"Customer Name"}),e.jsx(D,{scope:"col",children:"Payment Mode"}),e.jsx(D,{scope:"col",children:"Amount"}),e.jsx(D,{scope:"col",children:"Transaction Reference"}),e.jsx(D,{scope:"col",children:"Date"}),e.jsx(D,{scope:"col",children:"Verified By"})]})}),e.jsx(lt,{children:tn.length===0?e.jsx(ee,{children:e.jsx(R,{colSpan:"8",style:{color:"red",textAlign:"center"},children:x?"No matching verified payments found":"No verified payments available"})}):tn.map((t,y)=>e.jsxs(ee,{children:[e.jsx(R,{children:y+1}),e.jsx(R,{children:t.bookingDetails?.bookingNumber||""}),e.jsx(R,{children:t.bookingDetails?.customerDetails?.name||""}),e.jsx(R,{children:t.paymentMode}),e.jsx(R,{children:t.amount}),e.jsx(R,{children:t.transactionReference}),e.jsx(R,{children:t.updatedAt?new Date(t.updatedAt).toLocaleDateString("en-GB"):" "}),e.jsx(R,{children:t.receivedByDetails?.name||""})]},y))})]})}):e.jsx("div",{className:"text-center py-4",children:e.jsx(xe,{color:"warning",children:"You do not have permission to view the Verified List tab."})});return ae?Ae?A?e.jsx("div",{className:"d-flex justify-content-center align-items-center",style:{height:"50vh"},children:e.jsx(nn,{color:"primary"})}):V?e.jsx("div",{className:"alert alert-danger",role:"alert",children:V}):e.jsxs("div",{children:[e.jsx("div",{className:"title",children:"Receipt Management"}),N&&e.jsx(xe,{color:"success",className:"mb-3",children:N}),e.jsx(Er,{className:"table-container mt-4",children:e.jsx(Tr,{children:Ae?e.jsxs(e.Fragment,{children:[de&&e.jsx("div",{className:"d-flex mb-3",children:e.jsxs(De,{size:"sm",className:"action-btn",onClick:or,title:"Export Excel",children:[e.jsx(rn,{icon:xr,className:"me-1"}),"Export Excel"]})}),e.jsxs(Rr,{variant:"tabs",className:"mb-3 border-bottom",children:[Ee&&e.jsx(ot,{children:e.jsxs(it,{active:i===0,onClick:()=>Ge(0),style:{cursor:"pointer",borderTop:i===0?"4px solid #2759a2":"3px solid transparent",color:"black",borderBottom:"none"},children:["Customer",!ze&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Te&&e.jsx(ot,{children:e.jsxs(it,{active:i===1,onClick:()=>Ge(1),style:{cursor:"pointer",borderTop:i===1?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Payment Verification",!$e&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),ke&&e.jsx(ot,{children:e.jsxs(it,{active:i===2,onClick:()=>Ge(2),style:{cursor:"pointer",borderTop:i===2?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Complete Payment",!Kn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Fe&&e.jsx(ot,{children:e.jsxs(it,{active:i===3,onClick:()=>Ge(3),style:{cursor:"pointer",borderTop:i===3?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Pending List",!Jn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})}),Re&&e.jsx(ot,{children:e.jsxs(it,{active:i===4,onClick:()=>Ge(4),style:{cursor:"pointer",borderTop:i===4?"4px solid #2759a2":"3px solid transparent",borderBottom:"none",color:"black"},children:["Verified List",!Qn&&e.jsx("span",{className:"ms-1 text-muted small",children:"(View Only)"})]})})]}),e.jsxs("div",{className:"d-flex justify-content-between mb-3",children:[e.jsx("div",{}),e.jsxs("div",{className:"d-flex",children:[e.jsx(Sr,{className:"mt-1 m-1",children:"Search:"}),e.jsx(fe,{type:"text",style:{maxWidth:"350px",height:"30px",borderRadius:"0"},className:"d-inline-block square-search",value:x,onChange:t=>v(t.target.value),disabled:!Ae})]})]}),e.jsxs(jr,{children:[Ee&&e.jsx(st,{visible:i===0,children:cr()}),Te&&e.jsx(st,{visible:i===1,children:lr()}),ke&&e.jsx(st,{visible:i===2,children:dr()}),Fe&&e.jsx(st,{visible:i===3,children:ur()}),Re&&e.jsx(st,{visible:i===4,children:mr()})]})]}):e.jsx(xe,{color:"warning",className:"text-center",children:"You don't have permission to view any tabs in Receipts."})})}),e.jsx(Fr,{show:c,onClose:()=>r(!1),bookingData:n,canCreateReceipts:ze,cashLocations:b,onPaymentSuccess:sr}),e.jsxs(_n,{alignment:"center",visible:w,onClose:yt,children:[e.jsx(Un,{children:e.jsxs(Vn,{children:[e.jsx(rn,{icon:br,className:"me-2"}),"Select Date Range for Receipts Export"]})}),e.jsxs(Hn,{children:[He&&e.jsx(xe,{color:"warning",className:"mb-3",children:He}),e.jsxs(Pr,{dateAdapter:Dr,adapterLocale:Ir,children:[e.jsx("div",{className:"mb-3",children:e.jsx(ln,{label:"Start Date",value:j,onChange:t=>{re(t),$("")},renderInput:t=>e.jsx(Nt,{...t,fullWidth:!0,size:"small"}),inputFormat:"dd/MM/yyyy",mask:"__/__/____",views:["day","month","year"],disabled:!de})}),e.jsx("div",{className:"mb-3",children:e.jsx(ln,{label:"End Date",value:Y,onChange:t=>{Ce(t),$("")},renderInput:t=>e.jsx(Nt,{...t,fullWidth:!0,size:"small"}),inputFormat:"dd/MM/yyyy",mask:"__/__/____",minDate:j,views:["day","month","year"],disabled:!de})})]}),e.jsxs(Nt,{select:!0,value:ye,onChange:t=>{ut(t.target.value),$("")},fullWidth:!0,size:"small",SelectProps:{native:!0},disabled:!de,children:[e.jsx("option",{value:"",children:"-- Select Branch --"}),le&&e.jsx("option",{value:"all",children:"All Branch"}),mt.map(t=>e.jsx("option",{value:t._id,children:t.name},t._id))]})]}),e.jsxs(qn,{children:[e.jsx(De,{color:"secondary",onClick:yt,children:"Cancel"}),e.jsx(De,{className:"submit-button",onClick:ir,disabled:!j||!Y||!ye||!de||Le,children:Le?e.jsxs(e.Fragment,{children:[e.jsx(nn,{size:"sm",className:"me-2"}),"Exporting..."]}):"Export"})]})]})]}):e.jsx("div",{className:"alert alert-danger m-3",role:"alert",children:"You do not have permission to view any tabs in Receipts."}):e.jsx("div",{className:"alert alert-danger m-3",role:"alert",children:"You do not have permission to view Receipts."})}export{Xo as default};
